# IIoT Smart Safety Cap - Airport Health Monitoring Dashboard

Real-time monitoring dashboard for airport ground crew safety using ESP32-based smart caps with multiple sensors.

## Project Structure

```
smart-cap-dashboard/
├── server/
│   └── index.js          # Node.js backend (WebSocket + Serial + Mock data)
├── public/
│   └── index.html        # Dashboard UI (HTML + CSS + JS)
├── package.json
└── README.md
```

## Quick Start (Live Firmware Mode)

```bash
# 1. Navigate to project folder
cd smart-cap-dashboard

# 2. Install dependencies
npm install

# 3. Start server in live mode
npm run dev

# 4. Open browser
# http://localhost:3000
```

The dashboard starts in live mode and waits for cap readings. Use the
Simulation toggle in the top-right corner when you want demo data; switch it
off to return to live firmware readings. Simulated readings update every eight
seconds. The demo waits 30 seconds before its first scenario, shows only one
worker hazard at a time, holds that condition for about 20 seconds, then allows
at least 45 seconds of green area status before another scenario. Simulated
incidents are not written to the persistent incident log.

## Running with Real ESP32 Gateway

Once your team has the ESP32 + sensors ready and the Gateway ESP32 is connected via USB:

```bash
# Find your COM port (Device Manager > Ports)
# Then run:
npm run start:serial COM3
```

Replace `COM3` with your actual port (e.g., COM4, COM5).

## Run Modes

| Command | Mode | Description |
|---------|------|-------------|
| `npm run dev` | Live | Waits for firmware readings; simulation starts only when toggled on |
| `npm start` | Live | Serves the dashboard and waits for readings |
| `npm run start:serial COM3` | Serial | Reads real ESP32 gateway data (USB) |
| `npm run start:ingest` | HTTP Ingest | Receives data from WiFi caps via HTTP POST |
| `node server/index.js --mock` | Simulation | Starts demo readings immediately |

## Running with WiFi Caps (Option B - POC)

For the proof-of-concept, each ESP32 cap connects to the same WiFi as the server PC
and POSTs its sensor JSON directly to the server. No gateway or USB cable is needed.

```
[ESP32 Cap + WiFi] --HTTP POST /api/ingest--> [Node Server] --WebSocket--> [Dashboard]
```

### Steps

1. Start the server in live ingest mode:

   ```bash
   npm run start:ingest
   ```

2. Find the server PC's LAN IP:

   ```powershell
   ipconfig
   ```
   Use the active adapter's IPv4 address (e.g. `192.168.1.50`).

3. Flash `fimwarePM/firmwareNewZero/firmwareNewZero.ino` to each ESP32. In its
   `CONFIG` block set:
   - `WIFI_SSID` / `WIFI_PASS` - your test WiFi
   - `SERVER_URL` - `http://<PC-IP>:3000/api/ingest`
   - `HAT_ID` / `WORKER` / `AREA` - unique per board (AREA must match a zone name below)

   The condition-aligned Addon2 copy is also available at
   `fimwarePM/addon2/firmwareNewZero/firmwareNewZero.ino`.

   The optional rear TF-LC02 uses the same UART request/frame protocol as the
   front unit, on GPIO 20 (RX) and GPIO 21 (TX). Connect sensor TX to ESP32 RX,
   sensor RX to ESP32 TX, and share ground. If serial debugging uses UART0 on
   your board setup, enable USB CDC for the debug console. An unavailable rear
   sensor reports 0 mm. UART LiDARs do not use I²C addresses such as `0x15`.

4. Power the caps. Each posts a reading every ~2 seconds and appears on the dashboard,
   keyed by its unique `hat_id`.

### Test the ingest endpoint without hardware

Simulate a cap with curl (high values trigger a critical alert):

```powershell
curl -Method POST http://localhost:3000/api/ingest -ContentType "application/json" -Body '{"hat_id":"HAT-01","worker":"Worker-01","area":"Cargo Area","temperature":41,"gyro_tilt":50,"shock_g":4,"gas_ppm":0,"noise_db":0,"battery":100}'
```

### Notes / limitations (POC)

- No authentication or TLS - use only on a private test network.
- All caps and the server PC must be on the same WiFi / subnet.
- The PC firewall may block inbound port 3000; allow it if caps can't connect.
- `gas_ppm`, `noise_db`, `battery` are sent as 0/100 (no sensor on the current board).

## How It Works

```
[Smart Caps (ESP32)] --ESP-NOW--> [Gateway ESP32] --USB Serial--> [This Server] --WebSocket--> [Dashboard]
```

1. **Smart Caps** send sensor data via ESP-NOW to the Gateway
2. **Gateway ESP32** receives data from all caps and forwards as JSON over Serial
3. **Node.js Server** reads Serial, checks thresholds, broadcasts via WebSocket
4. **Dashboard** receives live updates and displays zones, alerts, sensor bars

## Expected JSON from Gateway ESP32

The server expects one JSON object per line from Serial:

```json
{"hat_id":"HAT-07","worker":"Worker-07","area":"Cargo Area","temperature":38.5,"gyro_tilt":45.2,"shock_g":4.2,"gas_ppm":120,"noise_db":82,"battery":76}
```

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| hat_id | string | Unique cap identifier (e.g., "HAT-01") |
| worker | string | Worker name/ID |
| area | string | Airport zone name |
| temperature | float | Temperature in Celsius |
| humidity | float | Relative humidity from the DHT22 |
| climate_valid | boolean | Whether the current temperature and humidity sample is valid |
| gyro_tilt | float | Tilt angle in degrees |
| gyro_dps | float | MPU6050 angular rotation rate in degrees per second |
| shock_g | float | Impact force in G |
| vibration_detected | boolean | SW-420 vibration event |
| vibration_count | integer | SW-420 events in the current 10-second window |
| repeated_vibration | boolean | At least three SW-420 events in the current window |
| imu_still | boolean | IMU has remained still for at least 3 seconds |
| fall_suspected | boolean | Confirmed motion/tilt/stillness pattern from the cap |
| gas_ppm | int | Gas concentration in PPM |
| noise_db | int | Noise level in decibels |
| battery_pct | number | Optional battery percentage; requires an ADC battery-divider connection |
| distance_front_mm | number | Front LiDAR reading; legacy `distance_mm` is also accepted |
| distance_rear_mm | number | Rear LiDAR reading |
| distance_front_closing_mm_s | number | Optional front LiDAR closing speed |
| distance_rear_closing_mm_s | number | Optional rear LiDAR closing speed |
| pm25 | number | PM2.5 concentration in µg/m³ |

### Valid Area Names

- Runway Area
- Baggage Handling
- Fuel Service Area
- Cargo Area
- Maintenance Hangar
- Catering Area
- Passenger Boarding
- Ground Transport

## Alert Thresholds

| Sensor | Warning | Critical |
|--------|---------|----------|
| Temperature | > 30 °C early warning; ≥ 38 °C heat warning; ≤ 14 °C cold warning | ≥ 42 °C or ≤ 9 °C |
| Humidity | ≥ 71% or ≤ 29% RH | ≥ 85% or ≤ 19% RH |
| Shock (MPU-6050) | ≥ 2.5 g | ≥ 3.5 g |
| SW-420 | Single vibration event | At least 3 events in 10 seconds plus an IMU spike |
| PM2.5 dust | ≥ 36 µg/m³ | ≥ 150 µg/m³ |
| Accelerometer tilt | ≥ 45° | ≥ 65° |
| Gyro rotation rate | > 180°/s warning | — |
| LiDAR distance | 1–2 m | < 1 m |
| LiDAR closing speed | ≥ 500 mm/s while within 2 m | ≥ 1000 mm/s while within 2 m |
| Battery | ≤ 29% | ≤ 14% |

PM2.5 at or above 150 µg/m³ is a dust hazard. Combined with temperature above
30 °C it is labeled a toxic-air hazard; combined with temperature at or above
42 °C it is labeled a fire/smoke hazard. PM2.5 measures particles, not gases.
Battery alerts require a configured ADC battery-divider connection; the
firmware sends `-1` (unavailable) when no battery voltage tap is configured.
Set `BATTERY_ADC_PIN` and `BATTERY_DIVIDER_RATIO` in the firmware to match the
board's battery-sense wiring. The pin is disabled by default because the
current sketch does not identify an ADC connection.
If a cap stops reporting for 10 seconds, the server records a `Cap Offline`
warning so a lost connection appears in the incident panel.

A possible fall requires an impact or combined movement event, followed within
10 seconds by tilt above 60° for 2 seconds and stillness (gyro below 45°/s and
acceleration magnitude between 0.8 and 1.2 g) for at least 1 second. A severe
fall-from-height alert requires tilt at or above 65° after a SW-420-confirmed
impact of at least 3.5 g. A temperature reading at or above 42 °C together
with 3 seconds of IMU stillness raises a heat-collapse alert.

The firmware keeps a possible-fall warning until the cap returns upright and
remains quiet for 3 seconds. The dashboard reports the confirmed fall
immediately. Motion-warning buzzer tones wait for 25 seconds of sustained
motion; temperature, impact, particulate, humidity, battery, and proximity
warnings use their configured buzzer behavior. Critical impact, air-quality,
temperature, and proximity alarms are immediate. The buzzer stays silent
during startup and zero calibration.
The toxic-air label is this configured combined condition; PM2.5 is not a
toxic-gas measurement, and the current cap firmware has no gas sensor.
LiDAR thresholds are inverted because closer objects are more dangerous. A
distance of 0 means no valid reading. Thresholds can be modified in
`server/index.js` under the `THRESHOLDS` object.

The calibrated WiFi sketch calculates its tilt zero after startup, once the cap
has had time to be worn and a stable accelerometer sample window is available.
See the final **MPU6050 Tilt Reference** section for its timing and fallback
behavior.

## REST API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/mode` | Current data source mode (`live` or `simulation`) |
| `POST /api/mode` | Switch between live firmware data and simulation |
| `POST /api/ingest` | Receive a sensor reading from a WiFi cap (Option B) |
| `GET /api/workers` | All current worker data |
| `GET /api/alerts` | Alert history (last 50) |
| `GET /api/incidents` | Latest persisted incident and recent incident history |
| `GET /api/status` | System summary (areas, counts) |

Incidents and the sensor values that triggered them are stored locally as
JSON Lines in `logs/incidents.jsonl`. Each warning or hazard is written when it
starts or changes, so repeated sensor packets for the same ongoing condition
do not fill the log. The dashboard's right-side incident panel restores the
latest logged incident after a server restart.

## Dashboard Features

- **Airport Operations Map** — Clickable runway, terminal, hangar, cargo, fuel, and transport zones
- **Map Labels** — Hide or show the airport and zone labels with the map control
- **Map Tooltips** — Hover or focus a zone for its description, worker count, and status
- **Cap Markers** — Simulated caps move along taxiway and service routes; live caps are shown at their assigned area
- **Area Status** — Color-coded map markers with a compact list on small screens
- **Hazard Alert Panel** — Shows latest critical/warning details
- **Persistent Incident Panel** — Restores the latest logged incident after restart
- **Sensor Bar Graphs** — Real-time sensor readings for selected zone
- **Recent Alerts Log** — Scrollable alert history with timestamps
- **Area Summary Chart** — Donut chart showing Normal/Warning/Critical breakdown
- **System Info** — Active hats, areas, connection status, last update time
- **Live / Simulation Switch** — Live firmware data is the default; simulation starts only when selected
- **Theme Control** — Cycles between System, Light, and Dark themes
- **Auto-reconnect** — Dashboard reconnects automatically if server restarts

## Tech Stack

- **Frontend:** HTML5, CSS3, Vanilla JavaScript, Canvas API
- **Backend:** Node.js, Express, ws (WebSocket)
- **Serial:** serialport (npm package)
- **Communication:** ESP-NOW (cap to gateway), USB Serial (gateway to server), WebSocket (server to dashboard)

## For ESP32 Team

Your Gateway ESP32 code should:
1. Initialize ESP-NOW and register as receiver
2. On receiving data from any cap, convert the struct to JSON
3. Print the JSON line to Serial at 115200 baud
4. Each JSON must be on its own line (terminated with `\n`)

Example Gateway output on Serial Monitor:
```
{"hat_id":"HAT-01","worker":"Worker-01","area":"Runway Area","temperature":32.1,"gyro_tilt":5.3,"shock_g":0.4,"gas_ppm":45,"noise_db":62,"battery":88}
{"hat_id":"HAT-07","worker":"Worker-07","area":"Cargo Area","temperature":41.2,"gyro_tilt":52.1,"shock_g":4.1,"gas_ppm":180,"noise_db":78,"battery":71}
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Dashboard shows "Disconnected" | Make sure server is running (`npm run dev`) |
| No data on Serial mode | Check COM port number in Device Manager |
| Alerts not appearing | Verify JSON format matches expected structure |
| Port 3000 in use | Set `PORT=3001` environment variable |
| Port 8080 in use | Set `WS_PORT=8081` environment variable |

## MPU6050 Tilt Reference

At startup, the firmware waits 25 seconds, then samples all three
accelerometer axes while the cap is still. It accepts the new zero only when
the readings are stable (axis variation no greater than 0.04 g). If movement
continues, it retries up to eight times, then falls back to the configured
gravity axis.

Put the cap on before powering it and keep it still during the countdown and
calibration. `ACCEL_VERTICAL_AXIS = 2` selects Z by default;
`ACCEL_VERTICAL_SIGN = 1` sets its direction (use `-1` if that axis points
down). These settings are used for the fallback if no stable sample window is
found.

There is no runtime recalibration button or command. To make a new zero,
power-cycle the cap while it is being worn and held still during calibration.
