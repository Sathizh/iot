# Smart Cap Dashboard Versions

The workspace contains two runnable copies. Both use the conditions in
`HAZARD_ANALYSIS.html` and the same active firmware sketch. Their frontend
layouts differ.

## Current UI

Run from the workspace root:

```powershell
npm install
npm run dev
```

Open `http://localhost:3000`. The dashboard starts in live firmware mode and
waits for readings. The top-right Simulation switch starts and stops demo
readings. Simulated readings update every 8 seconds; only one worker receives
a hazard scenario at a time. The demo starts with 30 seconds of green status,
holds each scenario for about 20 seconds, and leaves at least 45 seconds of
green status before the next one. Simulated incidents are not written to the
persistent incident log.

The current frontend is `public/index.html`; the server is `server/index.js`;
the active cap sketch is
`fimwarePM/firmwareNewZero/firmwareNewZero.ino`.

## Addon2 UI Copy

The separate `smartcap_ds_old/` project starts from commit `0229ad6` (`addon
2`). Its original frontend layout and styling are preserved. Its server,
frontend alert thresholds, and `firmwareNewZero.ino` copy use the current
hazard conditions.

Run from `smartcap_ds_old/`:

```powershell
npm install
npm run dev
```

The old UI has no Simulation switch. To launch it directly in demo mode, use
`npm run start:mock`. Both modes serve the dashboard at `http://localhost:3000`.
Only run one project copy at a time because both use ports 3000 and 8080.

## Shared Hazard Conditions

| Sensor or condition | Warning | Critical / hazard |
|---|---|---|
| Temperature rise | >30 °C; heat stress at ≥38 °C | ≥42 °C; cold stress warning at ≤14 °C and critical at ≤9 °C |
| Humidity | ≥71% or ≤29% RH | ≥85% or ≤19% RH |
| PM2.5 | ≥36 µg/m³ | ≥150 µg/m³ |
| MPU6050 impact | ≥2.5 g | ≥3.5 g |
| SW-420 | Single vibration event | At least 3 events in 10 seconds plus an IMU spike |
| Tilt | ≥45° | ≥65° |
| Gyro rotation | >180°/s warning | — |
| LiDAR distance | 1–2 m | <1 m |
| LiDAR closing speed | ≥500 mm/s within 2 m | ≥1000 mm/s within 2 m |
| Battery | ≤29% | ≤14%, when a battery ADC is configured |
| Cap connection | No reading for 10 seconds | — |

PM2.5 at or above 150 µg/m³ is a dust hazard. With temperature above 30 °C it
uses the combined toxic-air label; with temperature at or above 42 °C it is
labeled a fire/smoke hazard. PM2.5 measures particles, not gases.

A possible-fall warning requires a recent impact or combined movement event,
followed within 10 seconds by tilt above 60° for 2 seconds and stillness for at
least 1 second. A fall-from-height hazard requires critical tilt following a
SW-420 confirmed impact of at least 3.5 g. Temperature at or above 42 °C with
3 seconds of IMU stillness is labeled a heat-collapse hazard.

The firmware waits 25 seconds before zero calibration, then accepts a stable
three-axis sample window. The battery ADC is disabled by default because the
firmware does not identify a battery-sense pin; set `BATTERY_ADC_PIN` and
`BATTERY_DIVIDER_RATIO` when the circuit's divider wiring is known.

The main sketch reads a DFRobot Gravity PM2.5 sensor over I²C. The hazard
reference names an AQS V2.0 analog/UART model, so verify the installed sensor
matches the firmware driver before flashing.
