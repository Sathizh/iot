// ============================================================================
// ESP32-C6 SMART SAFETY CAP - WiFi POC FIRMWARE (Option B)
//
// Reads DHT22 (temp/humidity), MPU6050 (motion), SW-420 (vibration),
// TF-LC02 LiDAR (distance), then POSTs a JSON reading to the dashboard
// server every REPORT_INTERVAL ms over WiFi.
//
// Dashboard JSON contract (one object per POST):
//   {"hat_id","worker","area","temperature","humidity","climate_valid",
//    "gyro_tilt","gyro_dps","shock_g","vibration_detected","vibration_count",
//    "repeated_vibration","imu_still","fall_suspected","battery_pct",
//    "distance_front_mm","distance_rear_mm","distance_*_closing_mm_s","pm25"}
//
// gas_ppm / noise_db are sent as 0 (no sensor mapped yet).
// battery_pct is -1 until BATTERY_ADC_PIN is connected to a voltage divider.
//
// SETUP: edit the CONFIG block below for each board, then flash.
// ============================================================================
#include <WiFi.h>
#include <HTTPClient.h>
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DHTesp.h>
#include <DFRobot_AirQualitySensor.h>
#include <math.h>

// =================================================================
// 0. CONFIG  --  CHANGE THESE PER BOARD / NETWORK
// =================================================================
const char* WIFI_SSID = "A6663900 4157";       // <-- set your WiFi name
const char* WIFI_PASS = "7>0624Pw";   // <-- set your WiFi password

// PC (server) LAN IP + port. Find it with `ipconfig` on the server PC.
const char* SERVER_URL = "http://10.205.178.129:3000/api/ingest";

// Per-cap identity. Give each board a UNIQUE hat_id.
const char* HAT_ID = "HAT-13";
const char* WORKER = "Worker-2234676";
const char* AREA   = "Runway Area";   // must match a dashboard zone name

// How often to report (ms)
const unsigned long REPORT_INTERVAL = 2000;

// Buzzer alert thresholds -- MUST match server THRESHOLDS in server/index.js
// warning = intermittent beep, critical = fast continuous beep
const float TEMP_WARN = 30.0;                      // early temperature-rise warning
const float TEMP_HEAT_WARN = 38.0, TEMP_CRIT = 42.0;
const float TEMP_COLD_WARN = 14.0, TEMP_COLD_CRIT = 9.0;
const float HUMIDITY_WARN_HIGH = 71.0, HUMIDITY_WARN_LOW = 29.0;
const float HUMIDITY_CRIT_HIGH = 85.0, HUMIDITY_CRIT_LOW = 19.0;
const float SHOCK_WARN = 2.5,  SHOCK_CRIT = 3.5;   // g; match hazard analysis
const float TILT_WARN = 45.0, TILT_CRIT = 65.0;    // degrees
const float GYRO_RATE_WARN_DPS = 180.0;            // degrees/second; warning only
const float GYRO_LSB_PER_DPS = 131.0;              // MPU6050 default ±250°/s range
const uint16_t PM25_WARN = 36, PM25_CRIT = 150;    // PM2.5 ug/m3
const uint16_t DIST_WARN = 2000, DIST_CRIT = 1000;  // LiDAR mm (2 m / 1 m)
const float DIST_CLOSING_WARN_MM_S = 500.0f;
const float DIST_CLOSING_CRIT_MM_S = 1000.0f;
const uint8_t VIBRATION_REPEAT_COUNT = 3;
const unsigned long VIBRATION_REPEAT_WINDOW_MS = 10000;
const float IMU_STILL_GYRO_DPS = 15.0f;
const float IMU_STILL_ACCEL_MIN_G = 0.8f, IMU_STILL_ACCEL_MAX_G = 1.2f;
const unsigned long IMU_STILL_CONFIRM_MS = 3000;

// Set this to the actual ESP32-C6 ADC pin wired to the battery divider.
// Leave -1 when the board has no battery-voltage tap; unavailable is sent as -1%.
const int BATTERY_ADC_PIN = -1;
const float BATTERY_DIVIDER_RATIO = 2.0f;
const float BATTERY_EMPTY_VOLTS = 3.3f, BATTERY_FULL_VOLTS = 4.2f;

// MPU6050 mounting configuration: 0 = X, 1 = Y, 2 = Z.
// Keep Z if the board is mounted as assumed by the original circuit.
const uint8_t ACCEL_VERTICAL_AXIS = 2;
const int8_t ACCEL_VERTICAL_SIGN = 1;  // use -1 if the selected vertical axis points down
const unsigned long ZERO_CALIBRATION_SETTLE_MS = 25000;
const uint8_t ZERO_CALIBRATION_SAMPLES = 40;
const uint8_t ZERO_CALIBRATION_MAX_ATTEMPTS = 8;
const float ZERO_CALIBRATION_MAX_STDDEV_G = 0.04f;
const unsigned long MOTION_WARNING_SOUND_DELAY_MS = 25000;
const unsigned long FALL_EVENT_WINDOW_MS = 10000;
const unsigned long FALL_TILT_CONFIRM_MS = 2000;
const unsigned long FALL_STILL_CONFIRM_MS = 1000;
const unsigned long FALL_RECOVERY_CONFIRM_MS = 3000;
const float FALL_TILT_DEG = 60.0f;
const float FALL_STILL_GYRO_DPS = 45.0f;
const float FALL_STILL_SHOCK_G = 1.5f;
// Set to true for an active buzzer (drive HIGH = sound).
// Set to false for a passive buzzer (needs a tone signal).
const bool BUZZER_ACTIVE_TYPE = true;

// I2C address of the air-quality (PM2.5) sensor (found via scan).
const uint8_t AQ_ADDR = 0x19;
// Run the one-time diagnostics (I2C scan + register dump) at boot.
const bool RUN_I2C_DIAG = true;

// =================================================================
// 1. HARDWARE PIN DEFINITIONS
// =================================================================
const int VIBRATION_PIN = 15; // SW-420 Output -> GPIO 15
// Buzzer + -> GPIO 10 (buzzer - -> GND).
// NOTE: do NOT use GPIO 4/5/8/9/15 on the ESP32-C6 -- they are strapping/boot
// pins and can sit HIGH during reset, making an active buzzer sound at boot.
const int BUZZER_PIN    = 10;
#define DHTPIN 5              // DHT22 Data -> GPIO 5

#define RX_PIN 7              // LiDAR TX -> GPIO 7 (Green Wire)
#define TX_PIN 6              // LiDAR RX -> GPIO 6 (White Wire)
// Optional rear TF-LC02 using the same UART protocol on a second serial port.
// Wire rear sensor TX -> GPIO 20 and RX -> GPIO 21 (and share GND).
// Enable USB CDC for Serial debugging because UART0 is assigned to the rear unit.
const int REAR_LIDAR_RX_PIN = 20;
const int REAR_LIDAR_TX_PIN = 21;

#define I2C_SDA 19            // MPU6050 + PM2.5 SDA
#define I2C_SCL 18            // MPU6050 + PM2.5 SCL
#define MPU6050_I2C_ADDR 0x68

// =================================================================
// 2. INSTANCES
// =================================================================
DHTesp dht;
HardwareSerial LidarSerial(1);
HardwareSerial RearLidarSerial(0);
MPU6050 mpu;
DFRobot_AirQualitySensor airSensor(&Wire, AQ_ADDR);  // DFRobot Gravity PM2.5 (I2C @ 0x19)
bool aqReady = false;   // set true once the sensor is detected at boot

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// LiDAR "invalid / out of range" sentinel value to ignore.
const uint16_t LIDAR_INVALID = 8888;

// =================================================================
// 3. TIMING / STATE
// =================================================================
unsigned long lastReportTime = 0;

unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;
unsigned long lidarTimeoutStart = 0;
bool waitingForLidar = false;
uint8_t lidarBuffer[10];
int lidarIdx = 0;
uint16_t lastLidarDist = 0;   // most recent GOOD distance (mm)

unsigned long lastRearLidarPollTime = 25; // stagger requests from the front unit
unsigned long rearLidarTimeoutStart = 0;
bool waitingForRearLidar = false;
uint8_t rearLidarBuffer[10];
int rearLidarIdx = 0;
uint16_t lastRearLidarDist = 0;
unsigned long lastFrontDistanceAt = 0;
unsigned long lastRearDistanceAt = 0;
float frontClosingRateMmS = 0.0f;
float rearClosingRateMmS = 0.0f;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;
int lastSensorState = LOW;
volatile bool vibrationLatched = false; // set when vibration seen, cleared each report
unsigned long vibrationWindowStart = 0;
uint8_t vibrationEventsInWindow = 0;
bool repeatedVibration = false;
unsigned long imuStillSince = 0;
bool g_imuStill = false;

// Latest sensor snapshot (updated continuously, sent on report tick)
float g_temperature = 0.0;
float g_humidity = 0.0;
bool g_climateValid = false;
float g_tilt = 0.0;
float g_shock = 0.0;
float g_gyroDps = 0.0;
int g_batteryPct = -1;
float g_accelZeroX = 0.0;
float g_accelZeroY = 0.0;
float g_accelZeroZ = 1.0;
bool g_accelZeroValid = false;
bool g_fallSuspected = false;
unsigned long lastFallMotionAt = 0;
unsigned long fallTiltSince = 0;
unsigned long fallStillSince = 0;
unsigned long fallRecoverySince = 0;
unsigned long motionWarningSince = 0;

// Air-quality sensor: DFRobot Gravity PM2.5 (I2C @ AQ_ADDR). Values in ug/m3.
uint16_t g_pm25 = 0;   // PM2.5 concentration (ug/m3)
uint16_t g_pm1_0 = 0;  // PM1.0 concentration (ug/m3)
uint16_t g_pm10 = 0;   // PM10 concentration (ug/m3)

// Buzzer / alert state
// severity: 0 = normal, 1 = warning, 2 = critical
int g_severity = 0;
bool g_buzzerOn = false;
unsigned long lastBuzzerToggle = 0;

// =================================================================
// WiFi
// =================================================================
void connectWiFi() {
  Serial.print(F("[WiFi] Connecting to "));
  Serial.print(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < 15000) {
    delay(300);
    Serial.print(F("."));
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(F("\n[WiFi] Connected. IP: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("\n[WiFi] FAILED to connect (will retry in loop)."));
  }
}

// =================================================================
// I2C diagnostics (one-time, at boot)
// =================================================================
void i2cDiagnostics() {
  Serial.println(F("[I2C SCAN] scanning bus..."));
  int found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print(F("[I2C SCAN] device at 0x"));
      if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      found++;
    }
  }
  if (found == 0) { Serial.println(F("[I2C SCAN] NO devices found - check SDA/SCL wiring & power")); return; }
  Serial.print(F("[I2C SCAN] total devices: ")); Serial.println(found);

  // Dump first 32 registers of the AQ sensor to identify the chip.
  Serial.print(F("[AQ DUMP] 0x00-0x1F @0x"));
  Serial.print(AQ_ADDR, HEX); Serial.print(F(":"));
  for (uint8_t reg = 0x00; reg <= 0x1F; reg++) {
    Wire.beginTransmission(AQ_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) == 0 && Wire.requestFrom((int)AQ_ADDR, 1) == 1) {
      uint8_t val = Wire.read();
      Serial.print(F(" "));
      if (val < 16) Serial.print('0');
      Serial.print(val, HEX);
    } else {
      Serial.print(F(" --"));
    }
  }
  Serial.println();
}

// =================================================================
// Derived sensor math
// =================================================================
bool calibrateAccelZero() {
  Serial.println(F("[+] Put the cap on and keep it still; zero calibration starts in 25 s."));
  delay(ZERO_CALIBRATION_SETTLE_MS);

  for (uint8_t attempt = 1; attempt <= ZERO_CALIBRATION_MAX_ATTEMPTS; attempt++) {
    float sum[3] = { 0, 0, 0 };
    float sumSquares[3] = { 0, 0, 0 };

    for (uint8_t sample = 0; sample < ZERO_CALIBRATION_SAMPLES; sample++) {
      int16_t ax, ay, az, gx, gy, gz;
      mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
      const float axes[3] = {
        (float)ax / 16384.0f,
        (float)ay / 16384.0f,
        (float)az / 16384.0f
      };
      for (uint8_t axis = 0; axis < 3; axis++) {
        sum[axis] += axes[axis];
        sumSquares[axis] += axes[axis] * axes[axis];
      }
      delay(25);
    }

    float average[3];
    float maxStdDev = 0;
    for (uint8_t axis = 0; axis < 3; axis++) {
      average[axis] = sum[axis] / ZERO_CALIBRATION_SAMPLES;
      float variance = sumSquares[axis] / ZERO_CALIBRATION_SAMPLES
          - average[axis] * average[axis];
      if (variance < 0) variance = 0;
      float stdDev = sqrtf(variance);
      if (stdDev > maxStdDev) maxStdDev = stdDev;
    }

    const float averageMagnitude = sqrtf(
        average[0] * average[0] +
        average[1] * average[1] +
        average[2] * average[2]);
    if (maxStdDev <= ZERO_CALIBRATION_MAX_STDDEV_G && averageMagnitude > 0.5f) {
      g_accelZeroX = average[0];
      g_accelZeroY = average[1];
      g_accelZeroZ = average[2];
      g_accelZeroValid = true;
      Serial.print(F("[+] Stable zero calibrated. Axis variation: "));
      Serial.print(maxStdDev, 3);
      Serial.println(F(" g."));
      return true;
    }

    Serial.print(F("[CAL] Movement detected; retry "));
    Serial.print(attempt);
    Serial.print('/');
    Serial.println(ZERO_CALIBRATION_MAX_ATTEMPTS);
    delay(250);
  }

  // Keep monitoring if a stable calibration window wasn't available.
  // Use the configured vertical axis as an absolute-gravity reference.
  g_accelZeroX = 0;
  g_accelZeroY = 0;
  g_accelZeroZ = 0;
  const uint8_t verticalAxis = ACCEL_VERTICAL_AXIS < 3 ? ACCEL_VERTICAL_AXIS : 2;
  if (verticalAxis == 0) g_accelZeroX = ACCEL_VERTICAL_SIGN;
  else if (verticalAxis == 1) g_accelZeroY = ACCEL_VERTICAL_SIGN;
  else g_accelZeroZ = ACCEL_VERTICAL_SIGN;
  g_accelZeroValid = true;
  Serial.println(F("[CAL] No stable window; using configured gravity axis."));
  return false;
}

void readMotion() {
  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  // Acceleration magnitude in g (MPU6050 default range +/-2g -> 16384 LSB/g)
  float axg = (float)ax / 16384.0f;
  float ayg = (float)ay / 16384.0f;
  float azg = (float)az / 16384.0f;
  g_shock = sqrtf(axg * axg + ayg * ayg + azg * azg);

  // Measure the angle from the stable startup zero vector.
  const float accelAxes[] = { axg, ayg, azg };
  const float currentMagnitude = g_shock;
  const float zeroMagnitude = sqrtf(
      g_accelZeroX * g_accelZeroX +
      g_accelZeroY * g_accelZeroY +
      g_accelZeroZ * g_accelZeroZ);
  if (g_accelZeroValid && currentMagnitude > 0.01f && zeroMagnitude > 0.01f) {
    float cosAngle = (
        accelAxes[0] * g_accelZeroX +
        accelAxes[1] * g_accelZeroY +
        accelAxes[2] * g_accelZeroZ) / (currentMagnitude * zeroMagnitude);
    if (cosAngle > 1.0f) cosAngle = 1.0f;
    if (cosAngle < -1.0f) cosAngle = -1.0f;
    g_tilt = acosf(cosAngle) * 180.0f / PI;
  }

  // The MPU6050 library defaults to ±250°/s, or 131 LSB per degree/second.
  const float gxDps = (float)gx / GYRO_LSB_PER_DPS;
  const float gyDps = (float)gy / GYRO_LSB_PER_DPS;
  const float gzDps = (float)gz / GYRO_LSB_PER_DPS;
  g_gyroDps = sqrtf(gxDps * gxDps + gyDps * gyDps + gzDps * gzDps);
}

// A possible fall needs a recent impact/rotation event, a large tilt, then
// sustained stillness. This filters ordinary head turns and cap handling.
void updateFallDetection(unsigned long now, bool vibrationDetected) {
  const bool impactEvent = g_shock > SHOCK_CRIT;
  const bool combinedMotionEvent = g_shock > SHOCK_WARN
      && (g_gyroDps > GYRO_RATE_WARN_DPS || vibrationDetected);
  const bool fallMotionEvent = impactEvent || combinedMotionEvent;
  if (fallMotionEvent) lastFallMotionAt = now;

  const bool recentMotionEvent = lastFallMotionAt > 0
      && now - lastFallMotionAt <= FALL_EVENT_WINDOW_MS;

  if (!g_fallSuspected) {
    if (recentMotionEvent && g_tilt > FALL_TILT_DEG) {
      if (fallTiltSince == 0) fallTiltSince = now;

      const bool still = g_gyroDps < FALL_STILL_GYRO_DPS
          && g_shock < FALL_STILL_SHOCK_G;
      if (still) {
        if (fallStillSince == 0) fallStillSince = now;
      } else {
        fallStillSince = 0;
      }

      if (now - fallTiltSince >= FALL_TILT_CONFIRM_MS
          && fallStillSince > 0
          && now - fallStillSince >= FALL_STILL_CONFIRM_MS) {
        g_fallSuspected = true;
        fallRecoverySince = 0;
      }
    } else {
      fallTiltSince = 0;
      fallStillSince = 0;
    }
    return;
  }

  // Keep the fall warning latched until the cap returns upright and stays
  // quiet, so a brief sensor fluctuation cannot clear it.
  if (g_tilt < 35.0f && g_gyroDps < FALL_STILL_GYRO_DPS) {
    if (fallRecoverySince == 0) fallRecoverySince = now;
    if (now - fallRecoverySince >= FALL_RECOVERY_CONFIRM_MS) {
      g_fallSuspected = false;
      fallTiltSince = 0;
      fallStillSince = 0;
      fallRecoverySince = 0;
      lastFallMotionAt = 0;
    }
  } else {
    fallRecoverySince = 0;
  }
}

void readClimate() {
  float t = dht.getTemperature();
  float h = dht.getHumidity();
  if (dht.getStatus() == DHTesp::ERROR_NONE && !isnan(t) && !isnan(h)) {
    g_temperature = t;
    g_humidity = h;
    g_climateValid = true;
  } else {
    g_climateValid = false;
  }
}

void updateImuStill(unsigned long now) {
  const bool still = g_gyroDps < IMU_STILL_GYRO_DPS
      && g_shock >= IMU_STILL_ACCEL_MIN_G
      && g_shock <= IMU_STILL_ACCEL_MAX_G;
  if (still) {
    if (imuStillSince == 0) imuStillSince = now;
    g_imuStill = now - imuStillSince >= IMU_STILL_CONFIRM_MS;
  } else {
    imuStillSince = 0;
    g_imuStill = false;
  }
}

int readBatteryPercent() {
  if (BATTERY_ADC_PIN < 0) {
    g_batteryPct = -1;
    return g_batteryPct;
  }

  const float pinVolts = analogReadMilliVolts(BATTERY_ADC_PIN) / 1000.0f;
  const float batteryVolts = pinVolts * BATTERY_DIVIDER_RATIO;
  const float percent = (batteryVolts - BATTERY_EMPTY_VOLTS)
      * 100.0f / (BATTERY_FULL_VOLTS - BATTERY_EMPTY_VOLTS);
  if (percent < 0.0f) g_batteryPct = 0;
  else if (percent > 100.0f) g_batteryPct = 100;
  else g_batteryPct = (int)lroundf(percent);
  return g_batteryPct;
}

// Read the DFRobot Gravity PM2.5 air-quality sensor (I2C @ AQ_ADDR).
// Returns PM1.0 / PM2.5 / PM10 concentration in ug/m3. Keeps last good values
// if the sensor isn't ready or a read fails.
void readAirQuality() {
  if (!aqReady) return;
  uint16_t pm25 = airSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
  uint16_t pm10 = airSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
  uint16_t pm1  = airSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
  // Library returns 0 on a failed read; only accept plausible frames.
  if (pm25 != 0 || pm10 != 0 || pm1 != 0) {
    g_pm25 = pm25;
    g_pm10 = pm10;
    g_pm1_0 = pm1;
  }
}

// Poll one TF-LC02 over its UART protocol. Separate state lets front and rear
// units use the same frame format on independent serial ports.
void pollLidar(
    HardwareSerial& serial,
    unsigned long currentMillis,
    unsigned long& lastPollTime,
    unsigned long& timeoutStart,
    bool& waiting,
    uint8_t* buffer,
    int& bufferIndex,
    uint16_t& lastGoodDistance,
    unsigned long& lastValidAt,
    float& closingRateMmS) {
  if (!waiting && currentMillis - lastPollTime >= lidarInterval) {
    lastPollTime = currentMillis;
    serial.write(GET_DIST, sizeof(GET_DIST));
    timeoutStart = currentMillis;
    waiting = true;
    bufferIndex = 0;
  }

  if (!waiting) return;

  while (serial.available() > 0) {
    uint8_t inByte = serial.read();
    if (bufferIndex == 0 && inByte == 0x55) buffer[bufferIndex++] = inByte;
    else if (bufferIndex == 1 && inByte == 0xAA) buffer[bufferIndex++] = inByte;
    else if (bufferIndex >= 2 && bufferIndex < 10) buffer[bufferIndex++] = inByte;
    else bufferIndex = 0;

    if (bufferIndex == 8) {
      waiting = false;
      if (buffer[0] == 0x55 && buffer[1] == 0xAA && buffer[7] == 0xFA) {
        uint16_t distance = (buffer[4] << 8) | buffer[5];
        if (distance != LIDAR_INVALID && buffer[6] == 0x00) {
          if (lastGoodDistance > distance && lastValidAt > 0
              && currentMillis > lastValidAt) {
            const float elapsedMs = (float)(currentMillis - lastValidAt);
            const float instantaneousRate =
                ((float)(lastGoodDistance - distance) * 1000.0f) / elapsedMs;
            closingRateMmS = closingRateMmS * 0.6f + instantaneousRate * 0.4f;
          } else if (distance >= lastGoodDistance) {
            closingRateMmS *= 0.6f;
            if (closingRateMmS < 50.0f) closingRateMmS = 0.0f;
          }
          lastGoodDistance = distance;
          lastValidAt = currentMillis;
        }
      }
      break;
    }
  }

  if (waiting && currentMillis - timeoutStart > 45) {
    waiting = false;
  }
  if (lastValidAt > 0 && currentMillis - lastValidAt > 500) {
    closingRateMmS = 0.0f;
  }
}

// =================================================================
// Buzzer / alert logic
// =================================================================
int computeSeverity(
    float shockToCheck,
    bool vibrationDetected,
    bool vibrationRepeated,
    unsigned long now) {
  int sev = 0;
  const bool fallFromHeight = g_tilt >= TILT_CRIT
      && shockToCheck >= SHOCK_CRIT && vibrationDetected;
  const bool repeatedImpact = vibrationRepeated
      && (shockToCheck >= SHOCK_WARN || g_gyroDps > GYRO_RATE_WARN_DPS);
  const bool highTemperature = g_climateValid
      && (g_temperature >= TEMP_CRIT || g_temperature <= TEMP_COLD_CRIT);
  const bool humidityCritical = g_climateValid
      && (g_humidity >= HUMIDITY_CRIT_HIGH || g_humidity <= HUMIDITY_CRIT_LOW);
  const bool frontNear = lastLidarDist > 0 && lastLidarDist < DIST_CRIT;
  const bool rearNear = lastRearLidarDist > 0 && lastRearLidarDist < DIST_CRIT;
  const bool frontFastClose = lastLidarDist > 0 && lastLidarDist <= DIST_WARN
      && frontClosingRateMmS >= DIST_CLOSING_CRIT_MM_S;
  const bool rearFastClose = lastRearLidarDist > 0 && lastRearLidarDist <= DIST_WARN
      && rearClosingRateMmS >= DIST_CLOSING_CRIT_MM_S;

  if (shockToCheck >= SHOCK_CRIT || g_pm25 >= PM25_CRIT
      || highTemperature || humidityCritical || g_tilt >= TILT_CRIT
      || fallFromHeight || repeatedImpact || frontNear || rearNear
      || frontFastClose || rearFastClose
      || (g_batteryPct >= 0 && g_batteryPct <= 14)) {
    sev = 2;
  } else {
    const bool highTemperatureWarning = g_climateValid
        && (g_temperature > TEMP_WARN || g_temperature >= TEMP_HEAT_WARN
            || g_temperature <= TEMP_COLD_WARN);
    const bool humidityWarning = g_climateValid
        && (g_humidity >= HUMIDITY_WARN_HIGH || g_humidity <= HUMIDITY_WARN_LOW);
    const bool frontClose = lastLidarDist > 0 && lastLidarDist <= DIST_WARN;
    const bool rearClose = lastRearLidarDist > 0 && lastRearLidarDist <= DIST_WARN;
    const bool fastClosing = (frontClose && frontClosingRateMmS >= DIST_CLOSING_WARN_MM_S)
        || (rearClose && rearClosingRateMmS >= DIST_CLOSING_WARN_MM_S);
    const bool motionWarning = g_gyroDps > GYRO_RATE_WARN_DPS
        || vibrationDetected || g_fallSuspected;
    if (motionWarning) {
      if (motionWarningSince == 0) motionWarningSince = now;
    } else {
      motionWarningSince = 0;
    }

    const bool sustainedMotionWarning = motionWarningSince > 0
        && now - motionWarningSince >= MOTION_WARNING_SOUND_DELAY_MS;
    if (highTemperatureWarning || humidityWarning || shockToCheck >= SHOCK_WARN
             || g_tilt >= TILT_WARN || g_pm25 >= PM25_WARN
             || frontClose || rearClose || fastClosing
             || vibrationRepeated
             || (g_batteryPct >= 0 && g_batteryPct <= 29)
             || sustainedMotionWarning) {
      sev = 1;
    }
  }
  return sev;
}

void buzzerOutput(bool on) {
  if (BUZZER_ACTIVE_TYPE) {
    digitalWrite(BUZZER_PIN, on ? HIGH : LOW);
  } else {
    if (on) tone(BUZZER_PIN, 2500); else noTone(BUZZER_PIN);
  }
  g_buzzerOn = on;
}

// Non-blocking buzzer driver -- call every loop.
//   normal   -> silent
//   warning  -> slow intermittent beep (on 150ms / off 850ms)
//   critical -> fast urgent beep (on 120ms / off 120ms)
void updateBuzzer() {
  unsigned long now = millis();

  if (g_severity == 0) {
    if (g_buzzerOn) buzzerOutput(false);
    return;
  }

  unsigned long onTime  = (g_severity == 2) ? 120 : 150;
  unsigned long offTime = (g_severity == 2) ? 120 : 850;

  unsigned long interval = g_buzzerOn ? onTime : offTime;
  if (now - lastBuzzerToggle >= interval) {
    lastBuzzerToggle = now;
    buzzerOutput(!g_buzzerOn);
  }
}

// =================================================================
// POST reading to server
// =================================================================
void postReading() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println(F("[POST] Skipped - WiFi down"));
    return;
  }

  // Keep the SW-420 event separate from measured accelerometer impact.
  const float shockToSend = g_shock;
  readBatteryPercent();

  // Keep severity (and buzzer) in sync with the exact value we report
  g_severity = computeSeverity(shockToSend, vibrationLatched, repeatedVibration, millis());

  char body[640];
  snprintf(body, sizeof(body),
    "{\"hat_id\":\"%s\",\"worker\":\"%s\",\"area\":\"%s\","
    "\"temperature\":%.1f,\"humidity\":%.1f,\"climate_valid\":%s,"
    "\"gyro_tilt\":%.1f,\"gyro_dps\":%.1f,\"shock_g\":%.2f,"
    "\"vibration_detected\":%s,\"vibration_count\":%u,\"repeated_vibration\":%s,"
    "\"imu_still\":%s,\"fall_suspected\":%s,"
    "\"gas_ppm\":0,\"noise_db\":0,\"battery\":%d,\"battery_pct\":%d,"
    "\"distance_mm\":%u,\"distance_front_mm\":%u,\"distance_rear_mm\":%u,"
    "\"distance_front_closing_mm_s\":%.1f,\"distance_rear_closing_mm_s\":%.1f,"
    "\"pm25\":%u,\"pm1_0\":%u,\"pm10\":%u}",
    HAT_ID, WORKER, AREA, g_temperature, g_humidity,
    g_climateValid ? "true" : "false",
    g_tilt, g_gyroDps, shockToSend,
    vibrationLatched ? "true" : "false", vibrationEventsInWindow,
    repeatedVibration ? "true" : "false", g_imuStill ? "true" : "false",
    g_fallSuspected ? "true" : "false",
    g_batteryPct, g_batteryPct,
    lastLidarDist, lastLidarDist, lastRearLidarDist,
    frontClosingRateMmS, rearClosingRateMmS,
    g_pm25, g_pm1_0, g_pm10);

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(2000);

  int code = http.POST((uint8_t*)body, strlen(body));
  if (code > 0) {
    Serial.print(F("[POST] "));
    Serial.print(code);
    Serial.print(F(" <- "));
    Serial.println(body);
  } else {
    Serial.print(F("[POST] ERROR "));
    Serial.println(http.errorToString(code));
  }
  http.end();

  vibrationLatched = false; // clear latch after each report
}

// =================================================================
// SETUP
// =================================================================
void setup() {
  // Silence the buzzer FIRST so it can't be left sounding from a boot transient.
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  g_buzzerOn = false;

  Serial.begin(115200);
  unsigned long s = millis();
  while (!Serial && (millis() - s) < 2000) { delay(10); }

  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);
  RearLidarSerial.begin(115200, SERIAL_8N1, REAR_LIDAR_RX_PIN, REAR_LIDAR_TX_PIN);

  Serial.println(F("\n============================================="));
  Serial.println(F("ESP32-C6 SMART CAP - WiFi POC FIRMWARE ONLINE"));
  Serial.println(F("============================================="));

  Serial.print(F("[+] I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) Serial.println(F(" OK.")); else { Serial.println(F(" FAILED!")); }
  Wire.setClock(100000);

  Serial.print(F("[+] MPU6050..."));
  mpu.initialize();
  delay(150);
  Serial.println(F(" INIT."));

  if (BATTERY_ADC_PIN >= 0) {
    analogReadResolution(12);
    pinMode(BATTERY_ADC_PIN, INPUT);
    Serial.print(F("[+] Battery ADC enabled on GPIO "));
    Serial.println(BATTERY_ADC_PIN);
  } else {
    Serial.println(F("[+] Battery ADC not configured; battery alerts unavailable."));
  }

  // Calibrate early so the settle window is measured from power-up rather
  // than being extended by later air-sensor or WiFi initialization.
  calibrateAccelZero();
  Serial.print(F("[+] Fallback axis configuration: "));
  Serial.print(ACCEL_VERTICAL_AXIS);
  Serial.print(F(", sign: "));
  Serial.println(ACCEL_VERTICAL_SIGN);

  if (RUN_I2C_DIAG) i2cDiagnostics();

  Serial.print(F("[+] Air Quality (DFRobot PM2.5)..."));
  {
    // On a COLD power-up the sensor's fan + laser need several seconds to
    // stabilize before it answers on I2C. Retry for up to ~8 s here; if it
    // still isn't ready, the loop() keeps retrying (self-heals).
    const int bootTries = 16;          // 16 x 500ms = up to 8 s
    for (int i = 0; i < bootTries && !aqReady; i++) {
      if (airSensor.begin()) aqReady = true; else delay(500);
    }
    if (aqReady) {
      uint8_t ver = airSensor.gainVersion();
      Serial.print(F(" OK (fw v")); Serial.print(ver); Serial.println(F(")."));
    } else {
      Serial.println(F(" not ready yet - will keep retrying in loop."));
    }
  }

  pinMode(VIBRATION_PIN, INPUT);
  dht.setup(DHTPIN, DHTesp::DHT22);
  Serial.println(F("[+] DHT22 profile loaded."));

  // Keep the buzzer silent during startup; alerts begin after calibration.
  Serial.println(F("[+] Buzzer ready."));

  connectWiFi();

  lastReportTime = millis();
  Serial.println(F("[+] Monitoring active.\n"));
}

// =================================================================
// LOOP
// =================================================================
void loop() {
  unsigned long currentMillis = millis();

  // Keep WiFi alive
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastRetry = 0;
    if (currentMillis - lastRetry > 5000) {
      lastRetry = currentMillis;
      connectWiFi();
    }
  }

  // ---- Vibration (SW-420), edge detect with debounce ----
  int currentRead = digitalRead(VIBRATION_PIN);
  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((currentMillis - lastDebounceTime) > debounceDelay) {
      if (vibrationWindowStart == 0
          || currentMillis - vibrationWindowStart > VIBRATION_REPEAT_WINDOW_MS) {
        vibrationWindowStart = currentMillis;
        vibrationEventsInWindow = 0;
      }
      if (vibrationEventsInWindow < 255) vibrationEventsInWindow++;
      repeatedVibration = vibrationEventsInWindow >= VIBRATION_REPEAT_COUNT;
      vibrationLatched = true;
      lastDebounceTime = currentMillis;
    }
  }
  lastSensorState = currentRead;
  if (vibrationWindowStart > 0
      && currentMillis - vibrationWindowStart > VIBRATION_REPEAT_WINDOW_MS) {
    vibrationWindowStart = 0;
    vibrationEventsInWindow = 0;
    repeatedVibration = false;
  }

  // ---- Front/rear TF-LC02 units, same UART protocol on separate ports ----
  pollLidar(LidarSerial, currentMillis, lastLidarPollTime, lidarTimeoutStart,
      waitingForLidar, lidarBuffer, lidarIdx, lastLidarDist,
      lastFrontDistanceAt, frontClosingRateMmS);
  pollLidar(RearLidarSerial, currentMillis, lastRearLidarPollTime,
      rearLidarTimeoutStart, waitingForRearLidar, rearLidarBuffer,
      rearLidarIdx, lastRearLidarDist, lastRearDistanceAt,
      rearClosingRateMmS);

  // ---- Continuously refresh motion snapshot ----
  readMotion();
  updateImuStill(currentMillis);
  updateFallDetection(currentMillis, vibrationLatched);

  // ---- Live severity: react to boundary crossings immediately (not just every 2s) ----
  {
    g_severity = computeSeverity(g_shock, vibrationLatched, repeatedVibration, currentMillis);
  }

  // ---- Drive the buzzer every loop (non-blocking) ----
  updateBuzzer();

  // ---- If the PM2.5 sensor wasn't ready at boot, keep retrying (self-heal
  //      after a cold power-up once the fan/laser have stabilized). ----
  if (!aqReady) {
    static unsigned long lastAqRetry = 0;
    if (currentMillis - lastAqRetry > 3000) {   // retry every 3 s, non-blocking
      lastAqRetry = currentMillis;
      if (airSensor.begin()) {
        aqReady = true;
        Serial.println(F("[AQ] sensor now ready."));
      }
    }
  }

  // ---- Report tick: refresh climate + POST ----
  if (currentMillis - lastReportTime >= REPORT_INTERVAL) {
    lastReportTime = currentMillis;
    readClimate();
    readAirQuality();
    Serial.print(F("[AQ] PM1.0=")); Serial.print(g_pm1_0);
    Serial.print(F("  PM2.5=")); Serial.print(g_pm25);
    Serial.print(F("  PM10=")); Serial.println(g_pm10);
    postReading();
  }

  delay(1);
}
