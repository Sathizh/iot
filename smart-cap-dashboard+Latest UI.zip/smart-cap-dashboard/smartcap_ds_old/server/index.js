/**
 * IIoT Smart Safety Cap - Backend Server
 * 
 * Modes:
 *   --mock     : Simulates ESP32 sensor data (for development/demo)
 *   --serial   : Reads real data from Gateway ESP32 via USB Serial
 * 
 * Usage:
 *   node server/index.js --mock          (mock data for dashboard testing)
 *   node server/index.js --serial COM3   (real ESP32 gateway on COM3)
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');

// Parse command line args
const args = process.argv.slice(2);
const useMock = args.includes('--mock');
// --ingest: starts in live HTTP mode for WiFi caps; simulation remains user-toggleable.
const useIngestOnly = args.includes('--ingest');
const serialIndex = args.indexOf('--serial');
const serialPort = serialIndex !== -1 ? args[serialIndex + 1] : null;

// Configuration
const PORT = process.env.PORT || 3000;
const WS_PORT = process.env.WS_PORT || 8080;
let dataMode = 'live';

// Server alert thresholds; keep the firmware buzzer thresholds in sync.
const THRESHOLDS = {
    temperature: {
        warning: 30,
        heatWarning: 38,
        critical: 42,
        coldWarning: 14,
        coldCritical: 9
    },
    humidity: { warningLow: 29, warningHigh: 71, criticalLow: 19, criticalHigh: 85 },
    shock_g: { warning: 2.5, critical: 3.5 },
    gyro_tilt: { warning: 45, critical: 65 },
    gyro_dps: { warning: 180 },
    pm25: { warning: 36, critical: 150 },
    distance_mm: { warning: 2000, critical: 1000 }, // proximity: CLOSER = worse (inverted)
    distance_closing_mm_s: { warning: 500, critical: 1000 },
    battery_pct: { warning: 29, critical: 14 },
    vibration: { repeatCount: 3, windowMs: 10000 }
};

// All tracked workers/hats
const workers = new Map();

// Persistent incident history. JSON Lines keeps each incident append-only and
// makes the log easy to inspect without adding a database dependency.
const LOG_DIR = path.join(__dirname, '..', 'logs');
const INCIDENT_LOG_PATH = path.join(LOG_DIR, 'incidents.jsonl');
fs.mkdirSync(LOG_DIR, { recursive: true });
fs.closeSync(fs.openSync(INCIDENT_LOG_PATH, 'a'));

const alertHistory = [];
const simulationAlertHistory = [];
const MAX_ALERTS = 50;
const persistedIncidentHistory = [];
let latestIncident = null;
let persistedLatestIncident = null;
let simulationIntervals = [];
let simulationTimeouts = [];
const recentImpacts = new Map();

try {
    const storedIncidents = fs.readFileSync(INCIDENT_LOG_PATH, 'utf8')
        .split(/\r?\n/)
        .filter(Boolean)
        .flatMap((line) => {
            try {
                return [JSON.parse(line)];
            } catch (error) {
                console.warn('[LOG] Skipping malformed incident log line');
                return [];
            }
        });
    persistedIncidentHistory.push(...storedIncidents.slice(-MAX_ALERTS));
    alertHistory.push(...persistedIncidentHistory);
    latestIncident = storedIncidents.length
        ? storedIncidents[storedIncidents.length - 1]
        : null;
    persistedLatestIncident = latestIncident;
} catch (error) {
    if (error.code !== 'ENOENT') {
        console.error(`[LOG] Could not read incident history: ${error.message}`);
    }
}

// ============================================
// Express Server (serves dashboard HTML)
// ============================================
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const server = http.createServer(app);
server.listen(PORT, () => {
    console.log(`[SERVER] Dashboard running at http://localhost:${PORT}`);
});

function alertsForCurrentMode() {
    return dataMode === 'simulation' ? simulationAlertHistory : alertHistory;
}

function currentInitPayload() {
    return {
        type: 'init',
        workers: Object.fromEntries(workers),
        alerts: alertsForCurrentMode().slice(-20),
        latestIncident,
        thresholds: THRESHOLDS,
        mode: dataMode
    };
}

// ============================================
// WebSocket Server (pushes live data to dashboard)
// ============================================
const wss = new WebSocket.Server({ port: WS_PORT });

wss.on('connection', (ws) => {
    console.log('[WS] Dashboard client connected');

    // Send current state to new client
    ws.send(JSON.stringify(currentInitPayload()));

    ws.on('close', () => {
        console.log('[WS] Dashboard client disconnected');
    });
});

function broadcastToClients(data) {
    const payload = JSON.stringify(data);
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(payload);
        }
    });
}

// ============================================
// Stale worker cleanup — remove caps that stopped sending
// ============================================
const STALE_TIMEOUT_MS = 10000; // 10 seconds (caps POST every 2s, so 5 missed = offline)

setInterval(() => {
    const now = Date.now();
    let removed = false;
    workers.forEach((w, hatId) => {
        if (now - w.timestamp > STALE_TIMEOUT_MS) {
            console.log(`[CLEANUP] ${hatId} offline (no data for ${Math.round((now - w.timestamp) / 1000)}s) — removed`);
            if (w.data_source !== 'simulation') {
                const offlineIncident = {
                    hat_id: hatId,
                    worker: w.worker,
                    area: w.area,
                    issue: 'Cap Offline',
                    severity: 'warning',
                    source: 'live',
                    triggers: [`No sensor data for ${Math.round((now - w.timestamp) / 1000)} seconds`],
                    timestamp: now,
                    time: new Date(now).toLocaleTimeString('en-US', {
                        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
                    })
                };
                try {
                    fs.appendFileSync(INCIDENT_LOG_PATH, `${JSON.stringify(offlineIncident)}\n`, 'utf8');
                    persistedIncidentHistory.push(offlineIncident);
                    if (persistedIncidentHistory.length > MAX_ALERTS) persistedIncidentHistory.shift();
                    persistedLatestIncident = offlineIncident;
                } catch (error) {
                    console.error(`[LOG] Could not persist offline incident: ${error.message}`);
                }
                latestIncident = offlineIncident;
                alertHistory.push(offlineIncident);
                if (alertHistory.length > MAX_ALERTS) alertHistory.shift();
                broadcastToClients({ type: 'alert', data: offlineIncident });
            }
            workers.delete(hatId);
            removed = true;
        }
    });
    if (removed) {
        // Broadcast the updated (smaller) worker list so dashboard resets
        broadcastToClients(currentInitPayload());
    }
}, 5000); // check every 5 seconds

// ============================================
// Process incoming sensor data (from any source)
// ============================================
function processSensorData(data, source = 'live') {
    if ((source === 'simulation') !== (dataMode === 'simulation')) {
        return;
    }

    const now = Date.now();
    const previous = workers.get(data.hat_id);
    const temperature = data.climate_valid === false
        ? null
        : Number.isFinite(data.temperature) ? data.temperature : null;
    const humidity = data.climate_valid === false
        ? null
        : Number.isFinite(data.humidity) ? data.humidity : null;
    const shock = Number.isFinite(data.shock_g) ? data.shock_g : null;
    const tilt = Number.isFinite(data.gyro_tilt) ? data.gyro_tilt : null;
    const gyroDps = Number.isFinite(data.gyro_dps) ? data.gyro_dps : null;
    const pm25 = Number.isFinite(data.pm25) ? data.pm25 : null;
    const batteryValue = Number.isFinite(data.battery_pct)
        ? data.battery_pct
        : Number.isFinite(data.battery) ? data.battery : null;
    const batteryPct = batteryValue !== null && batteryValue >= 0 ? batteryValue : null;
    const vibrationDetected = data.vibration_detected === true;
    const vibrationCount = Number(data.vibration_count) || 0;
    const repeatedVibration = data.repeated_vibration === true
        || vibrationCount >= THRESHOLDS.vibration.repeatCount;
    const frontDistance = Number.isFinite(data.distance_front_mm)
        ? data.distance_front_mm
        : Number.isFinite(data.distance_mm) ? data.distance_mm : 0;
    const rearDistance = Number.isFinite(data.distance_rear_mm) ? data.distance_rear_mm : 0;
    const elapsedSeconds = previous && now > previous.timestamp
        ? (now - previous.timestamp) / 1000
        : 0;
    const inferredFrontClosing = elapsedSeconds > 0
        && previous.distance_front_mm > frontDistance
        && frontDistance > 0
        ? (previous.distance_front_mm - frontDistance) / elapsedSeconds
        : 0;
    const inferredRearClosing = elapsedSeconds > 0
        && previous.distance_rear_mm > rearDistance
        && rearDistance > 0
        ? (previous.distance_rear_mm - rearDistance) / elapsedSeconds
        : 0;
    const frontClosingRate = Math.max(
        Number(data.distance_front_closing_mm_s) || 0,
        inferredFrontClosing
    );
    const rearClosingRate = Math.max(
        Number(data.distance_rear_closing_mm_s) || 0,
        inferredRearClosing
    );
    const closingRate = Math.max(frontClosingRate, rearClosingRate);

    // Determine severity based on thresholds
    let severity = 'normal';
    let issue = 'All Clear';
    const triggers = [];

    if (shock !== null && shock >= THRESHOLDS.shock_g.critical) {
        severity = 'critical';
        issue = 'High Impact Detected';
        triggers.push(`Impact: ${shock.toFixed(1)}g`);
    } else if (shock !== null && shock >= THRESHOLDS.shock_g.warning) {
        severity = 'warning';
        issue = 'Impact Warning';
        triggers.push(`Impact: ${shock.toFixed(1)}g`);
    }

    if (repeatedVibration && shock !== null
        && (shock >= THRESHOLDS.shock_g.warning
            || (gyroDps !== null && gyroDps > THRESHOLDS.gyro_dps.warning))) {
        severity = 'critical';
        issue = 'Repeated Impact / Struck-By Hazard';
        triggers.push(`Repeated SW-420 events: ${vibrationCount}`);
    } else if (vibrationDetected) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Vibration Warning'; }
        triggers.push('Vibration: detected');
    }

    if (temperature !== null) {
        if (temperature <= THRESHOLDS.temperature.coldCritical) {
            severity = 'critical';
            issue = 'Hypothermia Risk';
            triggers.push(`Cold stress: ${temperature.toFixed(1)}°C`);
        } else if (temperature >= THRESHOLDS.temperature.critical) {
            severity = 'critical';
            issue = data.imu_still === true ? 'Heat Collapse Suspected' : 'Heat Stroke Risk';
            triggers.push(`Heat stress: ${temperature.toFixed(1)}°C`);
        } else if (temperature >= THRESHOLDS.temperature.heatWarning) {
            if (severity !== 'critical') { severity = 'warning'; issue = 'Heat Stress Warning'; }
            triggers.push(`Heat stress: ${temperature.toFixed(1)}°C`);
        } else if (temperature > THRESHOLDS.temperature.warning) {
            if (severity !== 'critical') { severity = 'warning'; issue = 'Temperature Rise'; }
            triggers.push(`Temperature rise: ${temperature.toFixed(1)}°C`);
        } else if (temperature <= THRESHOLDS.temperature.coldWarning) {
            if (severity !== 'critical') { severity = 'warning'; issue = 'Cold Stress Warning'; }
            triggers.push(`Cold stress: ${temperature.toFixed(1)}°C`);
        }
    }

    if (humidity !== null) {
        if (humidity >= THRESHOLDS.humidity.criticalHigh
            || humidity <= THRESHOLDS.humidity.criticalLow) {
            severity = 'critical';
            issue = humidity >= THRESHOLDS.humidity.criticalHigh
                && temperature !== null
                && temperature >= THRESHOLDS.temperature.heatWarning
                ? 'Heat Index Hazard'
                : 'Humidity Hazard';
            triggers.push(`Humidity: ${humidity.toFixed(1)}% RH`);
        } else if (humidity >= THRESHOLDS.humidity.warningHigh
            || humidity <= THRESHOLDS.humidity.warningLow) {
            if (severity !== 'critical') { severity = 'warning'; issue = 'Humidity Stress'; }
            triggers.push(`Humidity: ${humidity.toFixed(1)}% RH`);
        }
    }

    if (tilt !== null && tilt >= THRESHOLDS.gyro_tilt.critical) {
        severity = 'critical';
        issue = 'Fall Detected';
        triggers.push(`Tilt: ${tilt.toFixed(1)}°`);
    } else if (tilt !== null && tilt >= THRESHOLDS.gyro_tilt.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Unusual Tilt'; }
        triggers.push(`Tilt: ${tilt.toFixed(1)}°`);
    }

    if (gyroDps !== null && gyroDps > THRESHOLDS.gyro_dps.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Rapid Rotation'; }
        triggers.push(`Rotation: ${gyroDps.toFixed(1)}°/s`);
    }

    // PM2.5 above 150 is always a dust hazard. If temperature is also high,
    // label that combined condition as a toxic-air hazard.
    if (pm25 !== null && pm25 >= THRESHOLDS.pm25.critical) {
        severity = 'critical';
        issue = temperature !== null && temperature >= THRESHOLDS.temperature.critical
            ? 'Fire / Smoke Hazard'
            : temperature !== null && temperature > THRESHOLDS.temperature.warning
                ? 'Toxic Air Hazard'
                : 'Dust Hazard';
        triggers.push(`PM2.5 dust: ${pm25} µg/m³`);
        if (temperature !== null && temperature >= THRESHOLDS.temperature.critical) {
            triggers.push(`Fire temperature: ${temperature.toFixed(1)}°C`);
        }
    } else if (pm25 !== null && pm25 >= THRESHOLDS.pm25.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Poor Air Quality'; }
        triggers.push(`PM2.5: ${pm25} µg/m³`);
    }

    const severeImpactWithVibration = shock !== null
        && shock >= THRESHOLDS.shock_g.critical
        && vibrationDetected;
    if (severeImpactWithVibration) {
        recentImpacts.set(data.hat_id, now);
    }
    const previousSevereImpact = recentImpacts.get(data.hat_id);
    const impactFollowedByCriticalTilt = tilt !== null
        && tilt >= THRESHOLDS.gyro_tilt.critical
        && previousSevereImpact !== undefined
        && now - previousSevereImpact <= 10000;
    if (previousSevereImpact !== undefined && now - previousSevereImpact > 10000) {
        recentImpacts.delete(data.hat_id);
    }
    const fallFromHeight = impactFollowedByCriticalTilt;
    if (fallFromHeight) {
        severity = 'critical';
        issue = 'Fall From Height';
        triggers.push('Critical tilt with a SW-420 confirmed impact');
    }

    // Motion combinations raise a fall warning unless the impact/tilt
    // combination above qualifies as a critical fall.
    const inferredFall = tilt !== null && tilt >= THRESHOLDS.gyro_tilt.warning
        && ((gyroDps !== null && gyroDps > THRESHOLDS.gyro_dps.warning)
            || (shock !== null && shock >= THRESHOLDS.shock_g.warning)
            || vibrationDetected);
    const possibleFall = data.fall_suspected === true
        || (data.fall_suspected == null && inferredFall);
    if (possibleFall && !fallFromHeight) {
        triggers.push('Fall pattern: sudden motion followed by sustained tilt and stillness');
        if (severity !== 'critical') {
            severity = 'warning';
            issue = 'Possible Fall';
        }
    }

    if (batteryPct !== null && batteryPct <= THRESHOLDS.battery_pct.critical) {
        severity = 'critical';
        issue = 'Cap Battery Critical';
        triggers.push(`Battery: ${batteryPct}%`);
    } else if (batteryPct !== null && batteryPct <= THRESHOLDS.battery_pct.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Cap Battery Low'; }
        triggers.push(`Battery: ${batteryPct}%`);
    }

    // Either LiDAR can trigger proximity alerts. CLOSER = worse. A fast
    // approach escalates the warning while the object is still outside 1 m.
    const lidarReadings = [
        ['Front', frontDistance, frontClosingRate],
        ['Rear', rearDistance, rearClosingRate]
    ];
    lidarReadings.forEach(([position, distance, rate]) => {
        if (distance > 0 && distance < THRESHOLDS.distance_mm.critical) {
            severity = 'critical';
            issue = `${position} LiDAR Object Too Close`;
            triggers.push(`${position} Dist: ${distance}mm`);
        } else if (distance > 0 && distance <= THRESHOLDS.distance_mm.warning) {
            if (severity !== 'critical') {
                severity = 'warning';
                issue = `${position} LiDAR Proximity Warning`;
            }
            triggers.push(`${position} Dist: ${distance}mm`);
        }
        if (distance > 0 && distance <= THRESHOLDS.distance_mm.warning
            && rate >= THRESHOLDS.distance_closing_mm_s.warning) {
            if (rate >= THRESHOLDS.distance_closing_mm_s.critical) {
                severity = 'critical';
                issue = `${position} Rapid Collision Approach`;
            } else if (severity !== 'critical') {
                severity = 'warning';
                issue = `${position} Object Closing Quickly`;
            }
            triggers.push(`${position} Closing: ${Math.round(rate)}mm/s`);
        }
    });

    // Build processed result
    const processed = {
        ...data,
        data_source: source,
        distance_front_mm: frontDistance,
        distance_rear_mm: rearDistance,
        distance_front_closing_mm_s: frontClosingRate,
        distance_rear_closing_mm_s: rearClosingRate,
        distance_closing_mm_s: closingRate,
        severity,
        issue,
        triggers,
        timestamp: now
    };

    // Persist a new incident when its severity or triggering sensor set
    // changes. Repeated packets for the same ongoing incident are deduplicated.
    if (severity !== 'normal') {
        const signature = `${severity}:${triggers.map((trigger) => trigger.split(':')[0]).sort().join(',')}`;
        if (!previous || previous.severity === 'normal' || previous.incidentSignature !== signature) {
            const alert = {
                hat_id: data.hat_id,
                worker: data.worker,
                area: data.area,
                issue,
                severity,
                source,
                triggers,
                sensors: {
                    temperature: data.temperature,
                    humidity: data.humidity,
                    shock_g: data.shock_g,
                    vibration_detected: data.vibration_detected,
                    vibration_count: data.vibration_count,
                    imu_still: data.imu_still,
                    fall_suspected: data.fall_suspected,
                    gyro_tilt: data.gyro_tilt,
                    gyro_dps: data.gyro_dps,
                    battery_pct: data.battery_pct,
                    pm25: data.pm25,
                    distance_front_mm: frontDistance,
                    distance_rear_mm: rearDistance,
                    distance_closing_mm_s: closingRate
                },
                timestamp: processed.timestamp,
                time: new Date(processed.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
            };
            if (source !== 'simulation') {
                try {
                    fs.appendFileSync(INCIDENT_LOG_PATH, `${JSON.stringify(alert)}\n`, 'utf8');
                    persistedIncidentHistory.push(alert);
                    if (persistedIncidentHistory.length > MAX_ALERTS) persistedIncidentHistory.shift();
                    persistedLatestIncident = alert;
                } catch (error) {
                    console.error(`[LOG] Could not persist incident: ${error.message}`);
                }
            }
            latestIncident = alert;
            const history = source === 'simulation' ? simulationAlertHistory : alertHistory;
            history.push(alert);
            if (history.length > MAX_ALERTS) history.shift();
            broadcastToClients({ type: 'alert', data: alert });
        }
        processed.incidentSignature = signature;
    }

    workers.set(data.hat_id, processed);

    // Broadcast sensor update
    broadcastToClients({ type: 'sensor_update', data: processed });
}

const MOCK_WORKERS = [
    { hat_id: 'SIM-01', worker: 'Demo Worker 01', area: 'Runway Area' },
    { hat_id: 'SIM-02', worker: 'Demo Worker 02', area: 'Runway Area' },
    { hat_id: 'SIM-03', worker: 'Demo Worker 03', area: 'Baggage Handling' },
    { hat_id: 'SIM-04', worker: 'Demo Worker 04', area: 'Baggage Handling' },
    { hat_id: 'SIM-05', worker: 'Demo Worker 05', area: 'Cargo Area' },
    { hat_id: 'SIM-06', worker: 'Demo Worker 06', area: 'Fuel Service Area' },
    { hat_id: 'SIM-07', worker: 'Demo Worker 07', area: 'Maintenance Hangar' },
    { hat_id: 'SIM-08', worker: 'Demo Worker 08', area: 'Maintenance Hangar' },
    { hat_id: 'SIM-09', worker: 'Demo Worker 09', area: 'Passenger Boarding' },
    { hat_id: 'SIM-10', worker: 'Demo Worker 10', area: 'Ground Transport' },
    { hat_id: 'SIM-11', worker: 'Demo Worker 11', area: 'Catering Area' },
    { hat_id: 'SIM-12', worker: 'Demo Worker 12', area: 'Cargo Area' }
];

const SIMULATION_UPDATE_MS = 8000;
const SIMULATION_HAZARD_DURATION_MS = 20000;
const SIMULATION_GREEN_INTERVAL_MS = 45000;
const SIMULATION_INITIAL_GREEN_MS = 30000;
const simulationRouteSteps = new Map();
let activeSimulationHazard = null;
let nextSimulationHazardAt = 0;
const SIMULATION_ROUTES = {
    'Runway Area': [[19, 22], [31, 21], [44, 20], [57, 18], [70, 17], [80, 16], [70, 17], [57, 18], [44, 20], [31, 21]],
    'Baggage Handling': [[35, 53], [41, 52], [48, 51], [55, 50], [63, 50], [70, 49], [63, 50], [55, 50], [48, 51], [41, 52]],
    'Cargo Area': [[73, 49], [77, 47], [82, 46], [87, 47], [87, 52], [82, 54], [77, 52]],
    'Fuel Service Area': [[7, 46], [10, 46], [14, 46], [18, 46], [18, 50], [14, 50], [10, 50]],
    'Maintenance Hangar': [[34, 54], [29, 56], [24, 59], [20, 62], [16, 67], [13, 73], [19, 73], [24, 68]],
    'Passenger Boarding': [[39, 67], [46, 66], [54, 65], [62, 64], [69, 64], [69, 70], [61, 71], [52, 72], [44, 72]],
    'Ground Transport': [[79, 88], [85, 88], [92, 88], [95, 88], [95, 83], [91, 82], [85, 82], [79, 82]],
    'Catering Area': [[29, 77], [33, 77], [37, 77], [38, 82], [34, 84], [29, 83]]
};
function getActiveSimulationHazard(now) {
    if (activeSimulationHazard && activeSimulationHazard.until <= now) {
        console.log(`[SIMULATION] ${activeSimulationHazard.type} scenario ended; areas returning to normal`);
        activeSimulationHazard = null;
        nextSimulationHazardAt = now + SIMULATION_GREEN_INTERVAL_MS;
    }

    if (!activeSimulationHazard && now >= nextSimulationHazardAt) {
        const hazardTypes = [
            'heat', 'heat-collapse', 'cold', 'humidity', 'dust', 'toxic-air',
            'fire-smoke', 'impact', 'repeated-impact', 'possible-fall', 'proximity', 'battery'
        ];
        const worker = MOCK_WORKERS[Math.floor(Math.random() * MOCK_WORKERS.length)];
        const type = hazardTypes[Math.floor(Math.random() * hazardTypes.length)];
        activeSimulationHazard = {
            hatId: worker.hat_id,
            type,
            until: now + SIMULATION_HAZARD_DURATION_MS
        };
        console.log(`[SIMULATION] ${type} scenario for ${worker.hat_id} (${worker.area})`);
    }
    return activeSimulationHazard;
}

function generateMockData(worker) {
    const now = Date.now();
    const activeHazard = getActiveSimulationHazard(now);
    const hazard = activeHazard && activeHazard.hatId === worker.hat_id
        ? activeHazard
        : null;
    const route = SIMULATION_ROUTES[worker.area] || [[50, 50]];
    const routeStep = simulationRouteSteps.get(worker.hat_id) || 0;
    const mapPoint = route[routeStep % route.length];
    simulationRouteSteps.set(worker.hat_id, (routeStep + 1) % route.length);

    let temperature = 24 + Math.random() * 5;
    let humidity = 40 + Math.random() * 25;
    let pm25 = 8 + Math.floor(Math.random() * 27);
    let shock = 0.8 + Math.random() * 0.5;
    let tilt = 2 + Math.random() * 18;
    let gyroDps = 5 + Math.random() * 55;
    let vibrationCount = 0;
    let distanceFront = 2500 + Math.floor(Math.random() * 2000);
    let distanceRear = 2700 + Math.floor(Math.random() * 2000);
    let distanceClosing = 0;
    let batteryPct = 60 + Math.floor(Math.random() * 41);
    let fall = false;
    let imuStill = false;

    switch (hazard && hazard.type) {
        case 'heat':
            temperature = 39 + Math.random() * 2;
            break;
        case 'heat-collapse':
            temperature = 42 + Math.random() * 3;
            imuStill = true;
            break;
        case 'cold':
            temperature = Math.random() < 0.5 ? 12 : 8;
            break;
        case 'humidity':
            temperature = 38 + Math.random() * 4;
            humidity = 85 + Math.random() * 10;
            break;
        case 'dust':
            pm25 = 150 + Math.floor(Math.random() * 45);
            break;
        case 'toxic-air':
            temperature = 35 + Math.random() * 5;
            pm25 = 150 + Math.floor(Math.random() * 45);
            break;
        case 'fire-smoke':
            temperature = 42 + Math.random() * 3;
            pm25 = 150 + Math.floor(Math.random() * 45);
            break;
        case 'impact':
            shock = 3.5 + Math.random() * 1.5;
            vibrationCount = 1;
            break;
        case 'repeated-impact':
            shock = 2.6 + Math.random() * 0.5;
            vibrationCount = THRESHOLDS.vibration.repeatCount;
            break;
        case 'possible-fall':
            shock = 2.6 + Math.random() * 0.5;
            tilt = 66 + Math.random() * 18;
            gyroDps = 190 + Math.random() * 90;
            vibrationCount = 1;
            fall = true;
            break;
        case 'proximity':
            distanceFront = 700 + Math.floor(Math.random() * 250);
            distanceClosing = 1200;
            break;
        case 'battery':
            batteryPct = Math.random() < 0.5 ? 25 : 10;
            break;
    }

    return {
        ...worker,
        temperature,
        humidity,
        climate_valid: true,
        gyro_tilt: tilt,
        gyro_dps: gyroDps,
        shock_g: shock,
        vibration_detected: vibrationCount > 0,
        vibration_count: vibrationCount,
        repeated_vibration: vibrationCount >= THRESHOLDS.vibration.repeatCount,
        fall_suspected: fall,
        imu_still: imuStill,
        distance_front_mm: distanceFront,
        distance_rear_mm: distanceRear,
        pm25,
        pm1_0: 0,
        pm10: 0,
        gas_ppm: 0,
        noise_db: 0,
        battery: batteryPct,
        battery_pct: batteryPct,
        map_x: mapPoint[0],
        map_y: mapPoint[1],
        simulation_hazard: Boolean(hazard),
        distance_front_closing_mm_s: distanceClosing,
        distance_rear_closing_mm_s: 0
    };
}

function stopSimulation() {
    simulationTimeouts.forEach(clearTimeout);
    simulationIntervals.forEach(clearInterval);
    simulationTimeouts = [];
    simulationIntervals = [];
    activeSimulationHazard = null;
    nextSimulationHazardAt = 0;
    simulationRouteSteps.clear();
}

function startSimulation() {
    if (simulationTimeouts.length || simulationIntervals.length) return;
    nextSimulationHazardAt = Date.now() + SIMULATION_INITIAL_GREEN_MS;

    MOCK_WORKERS.forEach((worker, index) => {
        const timeout = setTimeout(() => {
            processSensorData(generateMockData(worker), 'simulation');
            const interval = setInterval(() => {
                processSensorData(generateMockData(worker), 'simulation');
            }, SIMULATION_UPDATE_MS);
            simulationIntervals.push(interval);
        }, index * 120);
        simulationTimeouts.push(timeout);
    });
    console.log(`[SIMULATION] Started demo readings for ${MOCK_WORKERS.length} workers`);
}

function setDataMode(mode) {
    if (mode !== 'live' && mode !== 'simulation') {
        throw new Error(`Unknown data mode: ${mode}`);
    }
    if (mode === dataMode) return;

    stopSimulation();
    dataMode = mode;
    workers.clear();

    if (mode === 'simulation') {
        simulationAlertHistory.length = 0;
        latestIncident = null;
        startSimulation();
    } else {
        simulationAlertHistory.length = 0;
        latestIncident = persistedLatestIncident;
        console.log('[MODE] Live firmware data selected');
    }

    broadcastToClients(currentInitPayload());
}

// ============================================
// DATA SOURCE: Real Serial from Gateway ESP32
// ============================================
if (serialPort) {
    console.log(`[MODE] Reading real data from serial port: ${serialPort}`);

    try {
        const { SerialPort } = require('serialport');
        const { ReadlineParser } = require('@serialport/parser-readline');

        const port = new SerialPort({ path: serialPort, baudRate: 115200 });
        const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

        port.on('open', () => {
            console.log(`[SERIAL] Connected to ${serialPort} at 115200 baud`);
        });

        parser.on('data', (line) => {
            try {
                const data = JSON.parse(line.trim());
                processSensorData(data);
            } catch (e) {
                // Skip non-JSON lines (debug prints from ESP32)
                if (line.trim()) {
                    console.log(`[SERIAL RAW] ${line.trim()}`);
                }
            }
        });

        port.on('error', (err) => {
            console.error(`[SERIAL ERROR] ${err.message}`);
            console.log('[INFO] Simulation stays off; use the dashboard toggle to start demo data.');
        });

    } catch (e) {
        console.error('[ERROR] serialport package not found. Run: npm install serialport');
        console.log('[INFO] Simulation stays off; use the dashboard toggle to start demo data.');
    }
}

// ============================================
// DATA SOURCE: HTTP Ingest from WiFi Caps (Option B - POC)
// Each ESP32 cap POSTs its sensor JSON here every few seconds.
// Reuses the same processSensorData() logic as mock/serial.
// ============================================
function optionalNumber(value) {
    if (value == null || value === '') return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
}

function coerceReading(body) {
    const climateValid = body.climate_valid == null
        ? null
        : body.climate_valid === true
            || body.climate_valid === 1
            || body.climate_valid === 'true';
    return {
        hat_id: String(body.hat_id),
        worker: body.worker != null ? String(body.worker) : String(body.hat_id),
        area: body.area != null ? String(body.area) : 'Unknown',
        climate_valid: climateValid,
        temperature: climateValid === false ? null : optionalNumber(body.temperature),
        humidity: climateValid === false ? null : optionalNumber(body.humidity),
        gyro_tilt: optionalNumber(body.gyro_tilt),
        shock_g: optionalNumber(body.shock_g),
        vibration_detected: body.vibration_detected === true
            || body.vibration_detected === 1
            || body.vibration_detected === 'true',
        vibration_count: Number(body.vibration_count) || 0,
        repeated_vibration: body.repeated_vibration === true
            || body.repeated_vibration === 1
            || body.repeated_vibration === 'true',
        fall_suspected: body.fall_suspected == null
            ? null
            : body.fall_suspected === true
                || body.fall_suspected === 1
                || body.fall_suspected === 'true',
        imu_still: body.imu_still == null
            ? null
            : body.imu_still === true || body.imu_still === 1 || body.imu_still === 'true',
        gyro_dps: optionalNumber(body.gyro_dps),
        gas_ppm: Number(body.gas_ppm) || 0,
        noise_db: Number(body.noise_db) || 0,
        battery: optionalNumber(body.battery),
        battery_pct: optionalNumber(body.battery_pct ?? body.battery),
        distance_mm: Number(body.distance_mm) || 0,
        distance_front_mm: Number(body.distance_front_mm ?? body.distance_mm) || 0,
        distance_rear_mm: Number(body.distance_rear_mm) || 0,
        distance_front_closing_mm_s: Number(body.distance_front_closing_mm_s) || 0,
        distance_rear_closing_mm_s: Number(body.distance_rear_closing_mm_s) || 0,
        pm25: optionalNumber(body.pm25),
        pm1_0: Number(body.pm1_0) || 0,
        pm10: Number(body.pm10) || 0
    };
}

app.post('/api/ingest', (req, res) => {
    const body = req.body;
    if (!body || body.hat_id == null || String(body.hat_id).trim() === '') {
        return res.status(400).json({ ok: false, error: 'missing hat_id' });
    }
    if (dataMode !== 'live') {
        return res.json({ ok: true, ignored: true, mode: dataMode });
    }
    const reading = coerceReading(body);
    processSensorData(reading);
    const formatReading = (value, precision) => (
        Number.isFinite(value) ? value.toFixed(precision) : 'n/a'
    );
    console.log(`[INGEST] ${reading.hat_id} (${reading.area}) -> temp ${formatReading(reading.temperature, 1)}C, tilt ${formatReading(reading.gyro_tilt, 1)}, shock ${formatReading(reading.shock_g, 2)}g, dist ${reading.distance_mm}mm, pm25 ${reading.pm25 ?? 'n/a'}`);
    res.json({ ok: true, hat_id: reading.hat_id });
});

// ============================================
// API Endpoints (optional REST access)
// ============================================
app.get('/api/mode', (req, res) => {
    res.json({ mode: dataMode });
});

app.post('/api/mode', (req, res) => {
    const requestedMode = req.body && req.body.mode;
    if (requestedMode !== 'live' && requestedMode !== 'simulation') {
        return res.status(400).json({
            ok: false,
            error: 'mode must be "live" or "simulation"'
        });
    }
    setDataMode(requestedMode);
    res.json({ ok: true, mode: dataMode });
});

app.get('/api/workers', (req, res) => {
    res.json(Object.fromEntries(workers));
});

app.get('/api/alerts', (req, res) => {
    res.json(alertsForCurrentMode());
});

app.get('/api/incidents', (req, res) => {
    res.json({
        latest: persistedLatestIncident,
        incidents: persistedIncidentHistory
    });
});

app.get('/api/status', (req, res) => {
    const areas = {};
    workers.forEach((w) => {
        if (!areas[w.area]) areas[w.area] = { workers: 0, severity: 'normal' };
        areas[w.area].workers++;
        if (w.severity === 'critical') areas[w.area].severity = 'critical';
        else if (w.severity === 'warning' && areas[w.area].severity !== 'critical') areas[w.area].severity = 'warning';
    });
    res.json({
        totalHats: workers.size,
        totalAreas: Object.keys(areas).length,
        activeAlerts: alertHistory.filter(a => Date.now() - new Date(a.time).getTime() < 60000).length,
        areas
    });
});

if (useIngestOnly) {
    console.log('[MODE] Live HTTP mode - waiting for WiFi caps to POST /api/ingest');
    console.log('[INFO] Caps should POST to http://<PC-IP>:' + PORT + '/api/ingest');
} else if (useMock && !serialPort) {
    setDataMode('simulation');
} else if (serialPort) {
    console.log(`[MODE] LIVE SERIAL mode - reading ${serialPort}`);
} else {
    console.log('[MODE] LIVE firmware data mode - simulation is off');
}

console.log(`[WS] WebSocket server on ws://localhost:${WS_PORT}`);
console.log('-------------------------------------------');
console.log('  Smart Cap Dashboard Server Ready');
console.log('-------------------------------------------');
