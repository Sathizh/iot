# Smart Cap Dashboard — Addon2 UI Copy

This project copy preserves the frontend layout and styling from repository
commit `0229ad6` (`addon 2`). Its backend conditions and active firmware sketch
are updated to the current `HAZARD_ANALYSIS.html` thresholds.

For the full threshold list and instructions for both UI versions, see
[`../README_VERSIONS.md`](../README_VERSIONS.md).

## Run Live Firmware Mode

From this directory:

```powershell
npm install
npm run dev
```

Open `http://localhost:3000`. The old UI starts in live mode and waits for
firmware readings. Flash
`fimwarePM/firmwareNewZero/firmwareNewZero.ino` for the matching cap behavior.
The sibling `firmwarePM.ino` and `firmwarePM-Backup.ino` sketches are legacy.

## Run Demo Mode

The Addon2 UI has no in-page simulation switch. To start mock readings, stop
the live server and run:

```powershell
npm run start:mock
```

Mock incidents are temporary and are not written to `logs/incidents.jsonl`.
