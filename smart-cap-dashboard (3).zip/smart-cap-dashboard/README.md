# IIoT Smart Safety Cap - Airport Health Monitoring Dashboard

Real-time monitoring dashboard for airport ground crew safety using ESP32-based smart caps with multiple sensors.

## Project Structure

```
smart-cap-dashboard/
├── server/
│   └── index.js          # Node.js backend (WebSocket + Serial + Mock data)
├── public/
│   └── index.html        # Dashboard UI (HTML + CSS + JS)
├── package.json
└── README.md
```

## Quick Start (Mock Mode - No Hardware Needed)

```bash
# 1. Navigate to project folder
cd smart-cap-dashboard

# 2. Install dependencies
npm install

# 3. Start server with mock data
npm run dev

# 4. Open browser
# http://localhost:3000
```

The dashboard will show simulated data from 12 workers across 8 airport zones. Alerts will appear randomly to demonstrate the system.

## Running with Real ESP32 Gateway

Once your team has the ESP32 + sensors ready and the Gateway ESP32 is connected via USB:

```bash
# Find your COM port (Device Manager > Ports)
# Then run:
npm run start:serial COM3
```

Replace `COM3` with your actual port (e.g., COM4, COM5).

## Run Modes

| Command | Mode | Description |
|---------|------|-------------|
| `npm run dev` | Mock | Simulates 12 workers, random alerts |
| `npm start` | Mock | Same as dev (default fallback) |
| `npm run start:serial COM3` | Serial | Reads real ESP32 gateway data (USB) |
| `npm run start:ingest` | HTTP Ingest | Receives data from WiFi caps via HTTP POST (mock disabled) |

## Running with WiFi Caps (Option B - POC)

For the proof-of-concept, each ESP32 cap connects to the same WiFi as the server PC
and POSTs its sensor JSON directly to the server. No gateway or USB cable is needed.

```
[ESP32 Cap + WiFi] --HTTP POST /api/ingest--> [Node Server] --WebSocket--> [Dashboard]
```

### Steps

1. Start the server in ingest mode (disables the mock simulator so only real caps show):

   ```bash
   npm run start:ingest
   ```

2. Find the server PC's LAN IP:

   ```powershell
   ipconfig
   ```
   Use the active adapter's IPv4 address (e.g. `192.168.1.50`).

3. Flash `firmware/cap_wifi.ino` to each ESP32. In its `CONFIG` block set:
   - `WIFI_SSID` / `WIFI_PASS` - your test WiFi
   - `SERVER_URL` - `http://<PC-IP>:3000/api/ingest`
   - `HAT_ID` / `WORKER` / `AREA` - unique per board (AREA must match a zone name below)

4. Power the caps. Each posts a reading every ~2 seconds and appears on the dashboard,
   keyed by its unique `hat_id`.

### Test the ingest endpoint without hardware

Simulate a cap with curl (high values trigger a critical alert):

```powershell
curl -Method POST http://localhost:3000/api/ingest -ContentType "application/json" -Body '{"hat_id":"HAT-01","worker":"Worker-01","area":"Cargo Area","temperature":41,"gyro_tilt":50,"shock_g":4,"gas_ppm":0,"noise_db":0,"battery":100}'
```

### Notes / limitations (POC)

- No authentication or TLS - use only on a private test network.
- All caps and the server PC must be on the same WiFi / subnet.
- The PC firewall may block inbound port 3000; allow it if caps can't connect.
- `gas_ppm`, `noise_db`, `battery` are sent as 0/100 (no sensor on the current board).

## How It Works

```
[Smart Caps (ESP32)] --ESP-NOW--> [Gateway ESP32] --USB Serial--> [This Server] --WebSocket--> [Dashboard]
```

1. **Smart Caps** send sensor data via ESP-NOW to the Gateway
2. **Gateway ESP32** receives data from all caps and forwards as JSON over Serial
3. **Node.js Server** reads Serial, checks thresholds, broadcasts via WebSocket
4. **Dashboard** receives live updates and displays zones, alerts, sensor bars

## Expected JSON from Gateway ESP32

The server expects one JSON object per line from Serial:

```json
{"hat_id":"HAT-07","worker":"Worker-07","area":"Cargo Area","temperature":38.5,"gyro_tilt":45.2,"shock_g":4.2,"gas_ppm":120,"noise_db":82,"battery":76}
```

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| hat_id | string | Unique cap identifier (e.g., "HAT-01") |
| worker | string | Worker name/ID |
| area | string | Airport zone name |
| temperature | float | Temperature in Celsius |
| gyro_tilt | float | Tilt angle in degrees |
| shock_g | float | Impact force in G |
| gas_ppm | int | Gas concentration in PPM |
| noise_db | int | Noise level in decibels |
| battery | int | Battery percentage (0-100) |

### Valid Area Names

- Runway Area
- Baggage Handling
- Fuel Service Area
- Cargo Area
- Maintenance Hangar
- Catering Area
- Passenger Boarding
- Ground Transport

## Alert Thresholds

| Sensor | Warning | Critical |
|--------|---------|----------|
| Temperature | > 38 C | > 42 C |
| Shock (G-Force) | > 2.5g | > 3.5g |
| Gas Level | > 150 ppm | > 250 ppm |
| Noise Level | > 80 dB | > 90 dB |
| Gyro Tilt | > 45 deg | > 65 deg |

Thresholds can be modified in `server/index.js` under the `THRESHOLDS` object.

## REST API Endpoints

| Endpoint | Description |
|----------|-------------|
| `POST /api/ingest` | Receive a sensor reading from a WiFi cap (Option B) |
| `GET /api/workers` | All current worker data |
| `GET /api/alerts` | Alert history (last 50) |
| `GET /api/status` | System summary (areas, counts) |

## Dashboard Features

- **Live Airport Map** — Clickable zone markers showing worker count and status
- **Area Status Sidebar** — Color-coded list of all zones
- **Hazard Alert Panel** — Shows latest critical/warning details
- **Sensor Bar Graphs** — Real-time sensor readings for selected zone
- **Recent Alerts Log** — Scrollable alert history with timestamps
- **Area Summary Chart** — Donut chart showing Normal/Warning/Critical breakdown
- **System Info** — Active hats, areas, connection status, last update time
- **Auto-reconnect** — Dashboard reconnects automatically if server restarts

## Tech Stack

- **Frontend:** HTML5, CSS3, Vanilla JavaScript, Canvas API
- **Backend:** Node.js, Express, ws (WebSocket)
- **Serial:** serialport (npm package)
- **Communication:** ESP-NOW (cap to gateway), USB Serial (gateway to server), WebSocket (server to dashboard)

## For ESP32 Team

Your Gateway ESP32 code should:
1. Initialize ESP-NOW and register as receiver
2. On receiving data from any cap, convert the struct to JSON
3. Print the JSON line to Serial at 115200 baud
4. Each JSON must be on its own line (terminated with `\n`)

Example Gateway output on Serial Monitor:
```
{"hat_id":"HAT-01","worker":"Worker-01","area":"Runway Area","temperature":32.1,"gyro_tilt":5.3,"shock_g":0.4,"gas_ppm":45,"noise_db":62,"battery":88}
{"hat_id":"HAT-07","worker":"Worker-07","area":"Cargo Area","temperature":41.2,"gyro_tilt":52.1,"shock_g":4.1,"gas_ppm":180,"noise_db":78,"battery":71}
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Dashboard shows "Disconnected" | Make sure server is running (`npm run dev`) |
| No data on Serial mode | Check COM port number in Device Manager |
| Alerts not appearing | Verify JSON format matches expected structure |
| Port 3000 in use | Set `PORT=3001` environment variable |
| Port 8080 in use | Set `WS_PORT=8081` environment variable |
