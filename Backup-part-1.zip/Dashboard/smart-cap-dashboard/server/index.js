/**
 * IIoT Smart Safety Cap - Backend Server
 * 
 * Modes:
 *   --mock     : Simulates ESP32 sensor data (for development/demo)
 *   --serial   : Reads real data from Gateway ESP32 via USB Serial
 * 
 * Usage:
 *   node server/index.js --mock          (mock data for dashboard testing)
 *   node server/index.js --serial COM3   (real ESP32 gateway on COM3)
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

// Parse command line args
const args = process.argv.slice(2);
const useMock = args.includes('--mock');
const serialIndex = args.indexOf('--serial');
const serialPort = serialIndex !== -1 ? args[serialIndex + 1] : null;

// Configuration
const PORT = process.env.PORT || 3000;
const WS_PORT = process.env.WS_PORT || 8080;

// Thresholds for alert detection
const THRESHOLDS = {
    temperature: { warning: 38, critical: 42 },
    shock_g: { warning: 2.5, critical: 3.5 },
    gas_ppm: { warning: 150, critical: 250 },
    noise_db: { warning: 80, critical: 90 },
    gyro_tilt: { warning: 45, critical: 65 }
};

// All tracked workers/hats
const workers = new Map();

// Alert history
const alertHistory = [];
const MAX_ALERTS = 50;

// ============================================
// Express Server (serves dashboard HTML)
// ============================================
const app = express();
app.use(express.static(path.join(__dirname, '..', 'public')));

const server = http.createServer(app);
server.listen(PORT, () => {
    console.log(`[SERVER] Dashboard running at http://localhost:${PORT}`);
});

// ============================================
// WebSocket Server (pushes live data to dashboard)
// ============================================
const wss = new WebSocket.Server({ port: WS_PORT });

wss.on('connection', (ws) => {
    console.log('[WS] Dashboard client connected');

    // Send current state to new client
    const initPayload = {
        type: 'init',
        workers: Object.fromEntries(workers),
        alerts: alertHistory.slice(-20),
        thresholds: THRESHOLDS
    };
    ws.send(JSON.stringify(initPayload));

    ws.on('close', () => {
        console.log('[WS] Dashboard client disconnected');
    });
});

function broadcastToClients(data) {
    const payload = JSON.stringify(data);
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(payload);
        }
    });
}

// ============================================
// Process incoming sensor data (from any source)
// ============================================
function processSensorData(data) {
    // Determine severity based on thresholds
    let severity = 'normal';
    let issue = 'All Clear';
    const triggers = [];

    if (data.shock_g > THRESHOLDS.shock_g.critical) {
        severity = 'critical';
        issue = 'High Impact Detected';
        triggers.push(`Shock: ${data.shock_g.toFixed(1)}g`);
    } else if (data.shock_g > THRESHOLDS.shock_g.warning) {
        severity = 'warning';
        issue = 'Impact Warning';
        triggers.push(`Shock: ${data.shock_g.toFixed(1)}g`);
    }

    if (data.temperature > THRESHOLDS.temperature.critical) {
        severity = 'critical';
        issue = 'Extreme Heat Exposure';
        triggers.push(`Temp: ${data.temperature.toFixed(1)}°C`);
    } else if (data.temperature > THRESHOLDS.temperature.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Heat Exposure'; }
        triggers.push(`Temp: ${data.temperature.toFixed(1)}°C`);
    }

    if (data.gas_ppm > THRESHOLDS.gas_ppm.critical) {
        severity = 'critical';
        issue = 'Gas Leak Detected';
        triggers.push(`Gas: ${data.gas_ppm} ppm`);
    } else if (data.gas_ppm > THRESHOLDS.gas_ppm.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Gas Level Elevated'; }
        triggers.push(`Gas: ${data.gas_ppm} ppm`);
    }

    if (data.noise_db > THRESHOLDS.noise_db.critical) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Noise Level Dangerous'; }
        triggers.push(`Noise: ${data.noise_db} dB`);
    } else if (data.noise_db > THRESHOLDS.noise_db.warning) {
        if (severity === 'normal') { severity = 'warning'; issue = 'Noise Level High'; }
        triggers.push(`Noise: ${data.noise_db} dB`);
    }

    if (data.gyro_tilt > THRESHOLDS.gyro_tilt.critical) {
        severity = 'critical';
        issue = 'Fall Detected';
        triggers.push(`Tilt: ${data.gyro_tilt.toFixed(1)}°`);
    } else if (data.gyro_tilt > THRESHOLDS.gyro_tilt.warning) {
        if (severity !== 'critical') { severity = 'warning'; issue = 'Unusual Tilt'; }
        triggers.push(`Tilt: ${data.gyro_tilt.toFixed(1)}°`);
    }

    // Build processed result
    const processed = {
        ...data,
        severity,
        issue,
        triggers,
        timestamp: Date.now()
    };

    // Update worker state
    workers.set(data.hat_id, processed);

    // Add to alert history if not normal
    if (severity !== 'normal') {
        const alert = {
            hat_id: data.hat_id,
            worker: data.worker,
            area: data.area,
            issue,
            severity,
            triggers,
            time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
        };
        alertHistory.push(alert);
        if (alertHistory.length > MAX_ALERTS) alertHistory.shift();

        // Broadcast alert
        broadcastToClients({ type: 'alert', data: alert });
    }

    // Broadcast sensor update
    broadcastToClients({ type: 'sensor_update', data: processed });
}

// ============================================
// DATA SOURCE: Mock Simulator
// ============================================
if (useMock || (!serialPort)) {
    console.log('[MODE] Running with MOCK data simulator');
    console.log('[INFO] Use --serial COM3 to switch to real ESP32 data');

    const MOCK_WORKERS = [
        { hat_id: 'HAT-01', worker: 'Worker-01', area: 'Runway Area' },
        { hat_id: 'HAT-02', worker: 'Worker-02', area: 'Runway Area' },
        { hat_id: 'HAT-03', worker: 'Worker-03', area: 'Baggage Handling' },
        { hat_id: 'HAT-04', worker: 'Worker-04', area: 'Baggage Handling' },
        { hat_id: 'HAT-05', worker: 'Worker-05', area: 'Baggage Handling' },
        { hat_id: 'HAT-06', worker: 'Worker-06', area: 'Fuel Service Area' },
        { hat_id: 'HAT-07', worker: 'Worker-07', area: 'Cargo Area' },
        { hat_id: 'HAT-08', worker: 'Worker-08', area: 'Cargo Area' },
        { hat_id: 'HAT-09', worker: 'Worker-09', area: 'Maintenance Hangar' },
        { hat_id: 'HAT-10', worker: 'Worker-10', area: 'Maintenance Hangar' },
        { hat_id: 'HAT-11', worker: 'Worker-11', area: 'Passenger Boarding' },
        { hat_id: 'HAT-12', worker: 'Worker-12', area: 'Ground Transport' },
    ];

    function generateMockData(worker) {
        // Most of the time, data is normal. Occasionally spike for demo.
        const spike = Math.random() < 0.08; // 8% chance of abnormal reading

        return {
            hat_id: worker.hat_id,
            worker: worker.worker,
            area: worker.area,
            temperature: spike ? 35 + Math.random() * 12 : 28 + Math.random() * 8,
            gyro_tilt: spike ? 40 + Math.random() * 40 : 2 + Math.random() * 15,
            shock_g: spike ? 2 + Math.random() * 3 : 0.2 + Math.random() * 1.5,
            gas_ppm: spike ? 100 + Math.random() * 200 : 20 + Math.random() * 80,
            noise_db: spike ? 75 + Math.random() * 20 : 50 + Math.random() * 25,
            battery: 60 + Math.floor(Math.random() * 40)
        };
    }

    // Send mock data for each worker every 2 seconds (staggered)
    MOCK_WORKERS.forEach((worker, index) => {
        setTimeout(() => {
            setInterval(() => {
                const data = generateMockData(worker);
                processSensorData(data);
            }, 2000);
        }, index * 150); // Stagger start so they don't all arrive at once
    });

    console.log(`[MOCK] Simulating ${MOCK_WORKERS.length} workers across all zones`);
}

// ============================================
// DATA SOURCE: Real Serial from Gateway ESP32
// ============================================
if (serialPort) {
    console.log(`[MODE] Reading real data from serial port: ${serialPort}`);

    try {
        const { SerialPort } = require('serialport');
        const { ReadlineParser } = require('@serialport/parser-readline');

        const port = new SerialPort({ path: serialPort, baudRate: 115200 });
        const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

        port.on('open', () => {
            console.log(`[SERIAL] Connected to ${serialPort} at 115200 baud`);
        });

        parser.on('data', (line) => {
            try {
                const data = JSON.parse(line.trim());
                processSensorData(data);
            } catch (e) {
                // Skip non-JSON lines (debug prints from ESP32)
                if (line.trim()) {
                    console.log(`[SERIAL RAW] ${line.trim()}`);
                }
            }
        });

        port.on('error', (err) => {
            console.error(`[SERIAL ERROR] ${err.message}`);
            console.log('[FALLBACK] Switching to mock mode...');
        });

    } catch (e) {
        console.error('[ERROR] serialport package not found. Run: npm install serialport');
        console.log('[FALLBACK] Running in mock mode instead.');
    }
}

// ============================================
// API Endpoints (optional REST access)
// ============================================
app.get('/api/workers', (req, res) => {
    res.json(Object.fromEntries(workers));
});

app.get('/api/alerts', (req, res) => {
    res.json(alertHistory);
});

app.get('/api/status', (req, res) => {
    const areas = {};
    workers.forEach((w) => {
        if (!areas[w.area]) areas[w.area] = { workers: 0, severity: 'normal' };
        areas[w.area].workers++;
        if (w.severity === 'critical') areas[w.area].severity = 'critical';
        else if (w.severity === 'warning' && areas[w.area].severity !== 'critical') areas[w.area].severity = 'warning';
    });
    res.json({
        totalHats: workers.size,
        totalAreas: Object.keys(areas).length,
        activeAlerts: alertHistory.filter(a => Date.now() - new Date(a.time).getTime() < 60000).length,
        areas
    });
});

console.log(`[WS] WebSocket server on ws://localhost:${WS_PORT}`);
console.log('-------------------------------------------');
console.log('  Smart Cap Dashboard Server Ready');
console.log('-------------------------------------------');