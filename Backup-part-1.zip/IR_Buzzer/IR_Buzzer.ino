#include <Wire.h>
#include "I2Cdev.h"
#include "MPU6050.h"

// Explicitly define your ESP32-C6 I2C pins
#define I2C_SDA 8
#define I2C_SCL 9

MPU6050 mpu; // Instantiates the sensor object using default address 0x68

void setup() {
  Serial.begin(115200);
  delay(1000); // Allow native USB stabilization time

  Serial.println("\n--- Initializing ESP32-C6 I2C Hardware ---");
  Wire.begin(I2C_SDA, I2C_SCL);

  Serial.println("--- Initializing MPU6050 Sensor via MPU6050.h ---");
  mpu.initialize();

  // Robust device verification block
  if (!mpu.testConnection()) {
    Serial.println("❌ ERROR: MPU6050 connection test failed!");
    Serial.println("👉 Continuing anyway in fallback broadcast loop...");
  } else {
    Serial.println("✅ SUCCESS: MPU6050 connection verified!");
  }

  // Optional: Set manual sensor offsets if your plate tilts slightly when flat
  // mpu.setXAccelOffset(0);
  // mpu.setYAccelOffset(0);
  // mpu.setZAccelOffset(0);
}

void loop() {
  // Raw container integers required by the MPU6050.h library api
  int16_t ax, ay, az;
  int16_t gx, gy, gz;

  // Retrieve raw counts directly from sensor registers
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  // Convert raw 16-bit accelerometer counts to standard Earth G forces
  // Default range for Electronic Cats library is +/-2G (Sensitivity: 16384 LSB/g)
  float ax_g = (float)ax / 16384.0;
  float ay_g = (float)ay / 16384.0;
  float az_g = (float)az / 16384.0;

  // Convert raw gyroscope metrics to Degrees Per Second (DPS)
  // Default range is +/-250 DPS (Sensitivity: 131 LSB/dps)
  float gz_dps = (float)gz / 131.0;

  // Calculate Roll & Pitch using standard trigonometry
  float roll  = atan2(ay_g, az_g) * 180.0 / M_PI;
  float pitch = atan2(-ax_g, sqrt(ay_g * ay_g + az_g * az_g)) * 180.0 / M_PI;

  // Approximate relative Yaw using integration over time (dt)
  static unsigned long lastTime = 0;
  unsigned long currentTime = millis();
  if (lastTime == 0) lastTime = currentTime;
  float dt = (currentTime - lastTime) / 1000.0;
  lastTime = currentTime;

  static float yaw = 0.0;
  yaw += gz_dps * dt; // Integrate gyro z-axis angular speed

  // Keep Yaw normalized between -180 and 180 degrees
  if (yaw > 180.0)  yaw -= 360.0;
  if (yaw < -180.0) yaw += 360.0;

  // Output structured format precisely: roll,pitch,yaw
  Serial.print(roll, 2);
  Serial.print(",");
  Serial.print(pitch, 2);
  Serial.print(",");
  Serial.println(yaw, 2);

  delay(15); // Perfectly paces the data output stream
}
