#include <esp_now.h>
#include <WiFi.h>
#include <esp_wifi.h>

const int irSensorPin = 2;
const int buzzerPin = 1;
uint8_t masterAddress[] = {0x10, 0x51, 0xDB, 0x03, 0x8F, 0xA4}; 

struct DataPacket {
  char packetType; 
  bool active;     
};

void setup() {
  Serial.begin(115200);
  pinMode(irSensorPin, INPUT);
  pinMode(buzzerPin, OUTPUT);
  digitalWrite(buzzerPin, LOW);
  
  WiFi.mode(WIFI_STA);
  esp_wifi_set_channel(1, WIFI_SECOND_CHAN_NONE);

  if (esp_now_init() != ESP_OK) return;

  esp_now_peer_info_t peerInfo;
  memcpy(peerInfo.peer_addr, masterAddress, 6);
  peerInfo.channel = 1;  
  peerInfo.encrypt = false;
  esp_now_add_peer(&peerInfo);

  // Send Initial Connection Notification
  DataPacket bootPacket = {'B', false};
  esp_now_send(masterAddress, (uint8_t *) &bootPacket, sizeof(bootPacket));
  Serial.println("Boot check-in sent to Master.");
}

void loop() {
  bool obstacle = (digitalRead(irSensorPin) == LOW);
  DataPacket alarmPacket = {'A', obstacle};
  
  esp_now_send(masterAddress, (uint8_t *) &alarmPacket, sizeof(alarmPacket));
  
  if (obstacle) {
    digitalWrite(buzzerPin, HIGH); delay(150);
    digitalWrite(buzzerPin, LOW);  delay(150);
    digitalWrite(buzzerPin, HIGH); delay(150);
    digitalWrite(buzzerPin, LOW);  delay(500); 
  } else {
    digitalWrite(buzzerPin, LOW);
    delay(100); 
  }
}
