#include <esp_now.h>
#include <WiFi.h>
#include <esp_wifi.h>

// Extended data packet to handle packet type
struct DataPacket {
  char packetType; // 'B' = Boot/Init Ping, 'A' = Alarm Data
  bool active;     // Sensor state
};

void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingData, int len) {
  DataPacket packet;
  memcpy(&packet, incomingData, sizeof(packet));
  
  const uint8_t* srcMac = info->src_addr;

  // FIXED: Proper index-by-index array comparison
  if (srcMac[0] == 0x20 && srcMac[1] == 0x6E && srcMac[2] == 0xF1 && srcMac[3] == 0x19 && srcMac[4] == 0x8B && srcMac[5] == 0x88) {
    if (packet.packetType == 'B') {
      Serial.println("-> [SYSTEM] Slave 1 (IR/Buzzer) has CONNECTED and checked in successfully!");
    } else if (packet.packetType == 'A') {
      if (packet.active) {
        Serial.println("[ALERT] Slave 1: IR Obstacle Detected! Local Buzzer is ringing.");
      } else {
        Serial.println("[INFO] Slave 1: Area clear.");
      }
    }
  }
  else if (srcMac[0] == 0x98 && srcMac[1] == 0xA3 && srcMac[2] == 0x16 && srcMac[3] == 0xB1 && srcMac[4] == 0xDF && srcMac[5] == 0xEC) {
    if (packet.packetType == 'B') {
      Serial.println("-> [SYSTEM] Slave 2 (Shock Sensor) has CONNECTED and checked in successfully!");
    } else if (packet.packetType == 'A' && packet.active) {
      Serial.println("[CRITICAL ALERT] Slave 2: Impact / Shock Detected!");
    }
  } 
  else {
    Serial.printf("[UNKNOWN] Packet from: %02X:%02X:%02X:%02X:%02X:%02X\n", 
                  srcMac[0], srcMac[1], srcMac[2], srcMac[3], srcMac[4], srcMac[5]);
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000); // Give serial monitor time to open
  
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(); 
  esp_wifi_set_channel(1, WIFI_SECOND_CHAN_NONE); // Force identical frequency channel

  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  esp_now_register_recv_cb(OnDataRecv);
  Serial.println("======================================");
  Serial.println("  MASTER MONITORING STATION ONLINE    ");
  Serial.println("======================================");
  Serial.println("Awaiting Slave boot up check-ins...");
}

void loop() {
  delay(10); 
}
