// ============================================================================
// ESP32-C6 MULTI-SENSOR MASTER PRODUCTION FIRMWARE (AIR QUALITY SENSOR REMOVED)
// ============================================================================
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DHTesp.h>  

// =================================================================
// 1. HARDWARE PIN DEFINITIONS
// =================================================================
const int VIBRATION_PIN = 15; // SW-420 Output -> GPIO 15
#define DHTPIN 5              // DHT22 Data Layout -> GPIO 5

#define RX_PIN 7              // LiDAR TX -> GPIO 7 (Green Wire)
#define TX_PIN 6              // LiDAR RX -> GPIO 6 (White Wire)

// Shared Hardware I2C Pins for MPU6050
#define I2C_SDA 19            // MPU6050 SDA Pin
#define I2C_SCL 18            // MPU6050 SCL Pin
#define MPU6050_I2C_ADDR 0x68

// =================================================================
// 2. INSTANCE & PROTOCOL DECLARATIONS
// =================================================================
DHTesp dht; 
HardwareSerial LidarSerial(1);
MPU6050 mpu; 

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// =================================================================
// 3. SYNCHRONOUS STATE MACHINE VARIABLES
// =================================================================
unsigned long lastStateExecutionTime = 0;
const unsigned long stepInterval = 500; // Transition execution steps every 500ms
uint8_t currentStep = 0;                // Sequencer steps: 0 to 2

unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;    // Poll LiDAR every 50ms (20Hz loop)
unsigned long lidarTimeoutStart = 0;
bool waitingForLidar = false;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;    // Filter layout noise on vibration sensor

// =================================================================
// 4. SENSOR PARSING STATE VARIABLES
// =================================================================
int lastSensorState = LOW;
uint8_t lidarBuffer[10]; // Sized safely to protect memory from array out-of-bounds corruption
int lidarIdx = 0;

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }
  
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("\n============================================="));
  Serial.println(F("ESP32-C6 MULTI-SENSOR MASTER SYSTEM ONLINE"));
  Serial.println(F("============================================="));

  // 1. Core Hardware I2C Initialization for MPU6050
  Serial.print(F("[+] Launching Hardware I2C Wire Bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(F(" SUCCESS."));
  } else {
    Serial.println(F(" FAILED! System halted."));
    while(1);
  }
  
  // Set to standard 100kHz for complete bus stability
  Wire.setClock(100000);

  // 2. Initialize MPU6050
  Serial.print(F("[+] Connecting to MPU6050 Motion Engine..."));
  mpu.initialize();
  delay(150); // Critical line settling pause
  Serial.println(F(" INITIALIZED."));

  // 3. Initialize Remaining Discrete Sensors
  pinMode(VIBRATION_PIN, INPUT);
  
  // Load specialized ESP32-C6 single-wire timing configuration for the DHT22
  dht.setup(DHTPIN, DHTesp::DHT22);
  Serial.println(F("[+] DHT22 Internal Timing Profile Loaded."));
  
  lastStateExecutionTime = millis();
  Serial.println(F("[+] Production Engine Booted! Monitoring Active...\n"));
}

void loop() {
  unsigned long currentMillis = millis();

  // =================================================================
  // LOOP 1: REAL-TIME SW-420 VIBRATION TRACKING (Instantaneous)
  // =================================================================
  int currentRead = digitalRead(VIBRATION_PIN);

  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((currentMillis - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[ALERT] Motion / Vibration Detected!"));
      lastDebounceTime = currentMillis;
    }
  } 
  else if (currentRead == LOW && lastSensorState == HIGH) {
    if ((currentMillis - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[INFO] Vibration stabilized."));
      lastDebounceTime = currentMillis;
    }
  }
  lastSensorState = currentRead;

  // =================================================================
  // LOOP 2: NON-BLOCKING TF-LC02 LIDAR PROCESSING (20Hz Loop)
  // =================================================================
  if (!waitingForLidar && (currentMillis - lastLidarPollTime >= lidarInterval)) {
    lastLidarPollTime = currentMillis;
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    lidarTimeoutStart = currentMillis;
    waitingForLidar = true;
    lidarIdx = 0;
  }

  if (waitingForLidar) {
    while (LidarSerial.available() > 0) {
      uint8_t inByte = LidarSerial.read();

      if (lidarIdx == 0 && inByte == 0x55) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else if (lidarIdx == 1 && inByte == 0xAA) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else if (lidarIdx >= 2 && lidarIdx < 10) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else {
        lidarIdx = 0; 
      }

      if (lidarIdx == 8) {
        waitingForLidar = false; 

        // Validate structure array mapping criteria
        if (lidarBuffer[0] == 0x55 && lidarBuffer[1] == 0xAA && lidarBuffer[7] == 0xFA) { 
          uint16_t dist = (lidarBuffer[4] << 8) | lidarBuffer[5]; 
          Serial.print(F("[LIDAR] Dist: "));
          Serial.print(dist);
          Serial.println(F("mm"));
        } else {
          Serial.println(F("[LIDAR] Frame Error: Corrupt Footer alignment."));
        }
        break;
      }
    }

    if (waitingForLidar && (currentMillis - lidarTimeoutStart > 45)) {
      waitingForLidar = false;
      Serial.println(F("[LIDAR] TIMEOUT: No packet received."));
    }
  }

  // =================================================================
  // SEQUENTIAL TASK STEP ENGINE (Executes a distinct task every 500ms)
  // =================================================================
  if (currentMillis - lastStateExecutionTime >= stepInterval) {
    lastStateExecutionTime = currentMillis;

    switch (currentStep) {
      case 0: {
        // STEP 0: Read DHT22 Climate metrics
        yield(); 
        float humidity = dht.getHumidity();
        float temperature_C = dht.getTemperature();

        if (dht.getStatus() != DHTesp::ERROR_NONE) {
          Serial.print(F("[CLIMATE ERROR] Code: "));
          Serial.println(dht.getStatusString());
        } else {
          Serial.print(F("[CLIMATE] Humidity: "));
          Serial.print(humidity, 1);
          Serial.print(F("%  |  Temperature: "));
          Serial.print(temperature_C, 1);
          Serial.println(F("°C"));
        }
        currentStep = 1;
        break;
      }

      case 1: {
        // STEP 1: Read MPU6050 Motion Vectors (First 500ms segment)
        int16_t ax, ay, az, gx, gy, gz;
        mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

        Serial.print(F("[IMU] Accel -> X:")); Serial.print(ax);
        Serial.print(F(" | Y: ")); Serial.print(ay);
        Serial.print(F(" | Z: ")); Serial.print(az);
        Serial.print(F("\t || Gyro -> X:")); Serial.print(gx);
        Serial.print(F(" | Y:")); Serial.print(gy);
        Serial.print(F(" | Z: ")); Serial.println(gz);
        
        currentStep = 2;
        break;
      }

      case 2: {
        // STEP 2: Read MPU6050 Motion Vectors (Second 500ms segment)
        // Maintains the required 500ms frequency profile for the IMU tracking loop
        int16_t ax, ay, az, gx, gy, gz;
        mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

        Serial.print(F("[IMU] Accel -> X:")); Serial.print(ax);
        Serial.print(F(" | Y: ")); Serial.print(ay);
        Serial.print(F(" | Z: ")); Serial.print(az);
        Serial.print(F("\t || Gyro -> X:")); Serial.print(gx);
        Serial.print(F(" | Y:")); Serial.print(gy);
        Serial.print(F(" | Z: ")); Serial.println(gz);
        
        currentStep = 0; // Loop pipeline back to Step 0
        break;
      }
    }
  }

  delay(1); 
}
