#include <esp_now.h>
#include <WiFi.h>

// Global structure to map incoming payloads cleanly
typedef struct struct_message {
    int boardId;          // 1 = DHT22 (Slave 1), 2 = SW-420 (Slave 2)
    int shockDetected;    // 0 = Still, 1 = Shocked!
    float temperature;    // Celsius
    float humidity;       // %
} struct_message;

struct_message incomingData;

// Automatic callback executed whenever any slave sends fresh data
void OnDataRecv(const esp_now_recv_info *info, const uint8_t *incomingDataPtr, int len) {
    memcpy(&incomingData, incomingDataPtr, sizeof(incomingData));
    
    Serial.print(">>> Data Packet From Board ID [");
    Serial.print(incomingData.boardId);
    Serial.println("]");

    // Route processing based on the designated Board ID
    if (incomingData.boardId == 1) {
        Serial.print("[Slave 1 - DHT22] Temp: ");
        Serial.print(incomingData.temperature);
        Serial.print(" °C | Humidity: ");
        Serial.print(incomingData.humidity);
        Serial.println(" %");
    } 
    else if (incomingData.boardId == 2) {
        Serial.print("[Slave 2 - SW-420] Status: ");
        Serial.println(incomingData.shockDetected == 1 ? "⚠️ SHOCK/VIBRATION DETECTED!" : "✔ System Stable");
    }
    Serial.println("------------------------------------");
}

void setup() {
    Serial.begin(115200);
    WiFi.mode(WIFI_STA);

    if (esp_now_init() != ESP_OK) {
        Serial.println("CRITICAL: Failed to initialize ESP-NOW");
        return;
    }
    
    esp_now_register_recv_cb(OnDataRecv);
    Serial.println("Master Hub Initialized. Listening for 20:6E:F1:19:8B:88 & 98:A3:16:B1:DF:EC...");
}

void loop() {
    // Keep empty. Callbacks automatically execute on core interrupts.
}
