#include <esp_now.h>
#include <WiFi.h>
#include <DHT.h>

// Hardcoded Master MAC Address (10:51:DB:03:8F:A4)
uint8_t masterMacAddress[] = {0x10, 0x51, 0xDB, 0x03, 0x8F, 0xA4};

#define DHTPIN 5        // Pin connected to DHT22 data line
#define DHTTYPE DHT22
#define BUZZER_PIN 21   // 🟢 Remapped to clean GPIO 21 on ESP32-C6 to fix constant blowing

DHT dht(DHTPIN, DHTTYPE);

typedef struct struct_message {
    int boardId;
    int shockDetected;
    float temperature;
    float humidity;
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

void setup() {
    Serial.begin(115200);
    dht.begin();
    
    // Explicitly clamp the pin LOW before assigning it as an output
    digitalWrite(BUZZER_PIN, LOW); 
    pinMode(BUZZER_PIN, OUTPUT);
    digitalWrite(BUZZER_PIN, LOW); // Double check it stays dead silent

    WiFi.mode(WIFI_STA);
    if (esp_now_init() != ESP_OK) {
        Serial.println("Failed to init ESP-NOW");
        return;
    }

    memcpy(peerInfo.peer_addr, masterMacAddress, 6);
    peerInfo.channel = 0;  
    peerInfo.encrypt = false;
    esp_now_add_peer(&peerInfo);

    myData.boardId = 1; 
    myData.shockDetected = 0;
}

void loop() {
    float h = dht.readHumidity();
    float t = dht.readTemperature();

    if (!isnan(h) && !isnan(t)) {
        myData.temperature = t;
        myData.humidity = h;
        
        // 🚨 OVER-TEMPERATURE LOGIC (More than 30°C)
        if (t > 30.0) {
            Serial.print("⚠️ CRITICAL TEMP! ");
            Serial.print(t);
            Serial.println(" °C. Sounding alarm tune and sending data.");

            // Instantly transmit the packet to the Master Hub
            esp_now_send(masterMacAddress, (uint8_t *) &myData, sizeof(myData));
            
            // Play a rhythmic 3-pulse alarm tune
            for(int i = 0; i < 3; i++) {
                digitalWrite(BUZZER_PIN, HIGH);
                delay(150); // Beep on
                digitalWrite(BUZZER_PIN, LOW);
                delay(150); // Beep off
            }
            
            delay(500); 
        } 
        // ✔ NORMAL TEMPERATURE LOGIC (30°C or below)
        else {
            digitalWrite(BUZZER_PIN, LOW); // Hard shutoff for the buzzer
            
            esp_now_send(masterMacAddress, (uint8_t *) &myData, sizeof(myData));
            Serial.println("Sent standard DHT22 update to Master Hub");
            
            delay(2500); // Standard cycle delay to respect sensor readout limits
        }
    } else {
        Serial.println("Failed to parse DHT22 sensor readings!");
        delay(2000);
    }
}
