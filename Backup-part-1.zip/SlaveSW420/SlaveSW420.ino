#include <esp_now.h>
#include <WiFi.h>

// Hardcoded Master MAC Address (10:51:DB:03:8F:A4)
uint8_t masterMacAddress[] = {0x10, 0x51, 0xDB, 0x03, 0x8F, 0xA4};

#define SHOCK_PIN 4 // SW-420 Digital Out Pin

typedef struct struct_message {
    int boardId;
    int shockDetected;
    float temperature;
    float humidity;
} struct_message;

struct_message myData;
esp_now_peer_info_t peerInfo;

void setup() {
    Serial.begin(115200);
    pinMode(SHOCK_PIN, INPUT); 

    WiFi.mode(WIFI_STA);
    if (esp_now_init() != ESP_OK) {
        Serial.println("Failed to init ESP-NOW");
        return;
    }

    memcpy(peerInfo.peer_addr, masterMacAddress, 6);
    peerInfo.channel = 0;  
    peerInfo.encrypt = false;
    esp_now_add_peer(&peerInfo);

    myData.boardId = 2; // Explicitly set as Board 2
    myData.temperature = 0.0;
    myData.humidity = 0.0;
}

void loop() {
    // Reads 1 if vibration breaks the circuit, 0 if perfectly stable
    myData.shockDetected = digitalRead(SHOCK_PIN); 

    esp_now_send(masterMacAddress, (uint8_t *) &myData, sizeof(myData));
    
    delay(200); // 5Hz sampling rate for low-latency transmission
}
