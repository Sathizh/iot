#include "DHT.h"

// Define the digital pin connected to the DHT22 data layout
#define DHTPIN 4     

// Define the exact type of sensor being read
#define DHTTYPE DHT22   

// Initialize the sensor instance
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  // Initialize serial communication at 115200 baud rate for the ESP32-C6
  Serial.begin(115200);
  Serial.println(F("Initializing DHT22 Test on ESP32-C6..."));

  // Start the DHT sensor internal clock and data bus
  dht.begin();
}

void loop() {
  // Wait 2 seconds between measurements (DHT22 samples slowly)
  delay(2000);

  // Read relative humidity (%)
  float humidity = dht.readHumidity();
  
  // Read temperature as Celsius (the default metric unit)
  float temperature_C = dht.readTemperature();

  // Check if any reads failed and exit early to try again.
  if (isnan(humidity) || isnan(temperature_C)) {
    Serial.println(F("Failed to read from DHT22 sensor! Check your wiring wires."));
    return;
  }

  // Print results directly to the Arduino Serial Monitor
  Serial.print(F("Humidity: "));
  Serial.print(humidity, 1);
  Serial.print(F("%  |  Temperature: "));
  Serial.print(temperature_C, 1);
  Serial.println(F("°C"));
}