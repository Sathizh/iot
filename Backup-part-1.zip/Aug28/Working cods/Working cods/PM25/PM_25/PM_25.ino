// #include <Wire.h>
// #include <MPU6050.h>
// #include <DFRobot_AirQualitySensor.h>

// // Explicit I2C Hardware Pins for ESP32-C6
// #define I2C_SDA 18
// #define I2C_SCL 19

// // Instantiations
// MPU6050 mpu;
// // DFRobot Sensor I2C Address is 0x19 by default
// DFRobot_AirQualitySensor particleSensor(&Wire, 0x19); 

// void setup() {
//   Serial.begin(115200);
//   while(!Serial); // Wait for serial monitor connection

//   Serial.println("\n--- ESP32-C6 Dual Sensor System Init ---");

//   // Initialize Hardware I2C bus on the correct C6 layout
//   Wire.begin(I2C_SDA, I2C_SCL);

//   // 1. Initialize MPU6050
//   mpu.initialize();
//   if (mpu.testConnection()) {
//     Serial.println("[SUCCESS] MPU6050 Connected.");
//   } else {
//     Serial.println("[WARNING] MPU6050 Connection Verification Failed!");
//   }

//   // 2. Initialize DFRobot PM2.5 Sensor
//   Serial.println("Initializing DFRobot PM2.5 Sensor...");
//   while (!particleSensor.begin()) {
//     Serial.println("[ERROR] PM2.5 Sensor not found! Retrying in 2 seconds...");
//     delay(2000);
//   }
//   Serial.println("[SUCCESS] DFRobot PM2.5 Sensor Connected!");
// }

// void loop() {
//   Serial.println("\n--- Reading Sensors ---");

//   // ================= MPU6050 READING =================
//   int16_t ax, ay, az, gx, gy, gz;
//   mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

//   Serial.print("Accel -> X: "); Serial.print(ax);
//   Serial.print(" | Y: "); Serial.print(ay);
//   Serial.print(" | Z: "); Serial.println(az);

//   Serial.print("Gyro  -> X: "); Serial.print(gx);
//   Serial.print(" | Y: "); Serial.print(gy);
//   Serial.print(" | Z: "); Serial.println(gz);

//   // ================= DFROBOT PM2.5 READING =================
//   // Corrected function syntax using proper library macros
//   uint16_t pm1_0 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_ATMOSPHERE);
//   uint16_t pm2_5 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_ATMOSPHERE);
//   uint16_t pm10  = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_ATMOSPHERE);

//   Serial.print("Air Q -> PM1.0: "); Serial.print(pm1_0);
//   Serial.print(" ug/m3 | PM2.5: "); Serial.print(pm2_5);
//   Serial.print(" ug/m3 | PM10: "); Serial.print(pm10);
//   Serial.println(" ug/m3");

//   delay(2000); // 2-second polling loop
// }


// --------------------------------------------gyro is not working

// #include <Wire.h>
// #include <MPU6050.h>
// #include <DFRobot_AirQualitySensor.h>

// // Explicit I2C Hardware Pins for your current working setup
// #define I2C_SDA 18
// #define I2C_SCL 19

// // Instantiations
// MPU6050 mpu;
// // DFRobot Sensor I2C Address is 0x19 by default
// DFRobot_AirQualitySensor particleSensor(&Wire, 0x19); 

// void setup() {
//   Serial.begin(115200);
//   while(!Serial); // Wait for serial monitor connection

//   Serial.println("\n--- ESP32-C6 Dual Sensor System Init ---");

//   // Initialize Hardware I2C bus
//   Wire.begin(I2C_SDA, I2C_SCL);
  
//   // CRITICAL: Give the air sensor's internal fan and laser diode 
//   // 5 seconds to spin up and draw stable current before pinging it.
//   Serial.println("Waiting for sensor power rails to stabilize...");
//   delay(5000); 

//   // 1. Initialize MPU6050
//   mpu.initialize();
//   if (mpu.testConnection()) {
//     Serial.println("[SUCCESS] MPU6050 Connected.");
//   } else {
//     Serial.println("[WARNING] MPU6050 Connection Verification Failed! (Data may still stream)");
//   }

//   // 2. Initialize DFRobot PM2.5 Sensor
//   Serial.println("Initializing DFRobot PM2.5 Sensor...");
//   while (!particleSensor.begin()) {
//     Serial.println("[ERROR] PM2.5 Sensor not found! Retrying in 2 seconds...");
//     delay(2000);
//   }
//   Serial.println("[SUCCESS] DFRobot PM2.5 Sensor Connected!");
// }

// void loop() {
//   Serial.println("\n========================================================");

//   // ================= MPU6050 READING =================
//   int16_t ax, ay, az, gx, gy, gz;
//   mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

//   Serial.println("[ MOTION DATA ]");
//   Serial.print("  Accel -> X: "); Serial.print(ax);
//   Serial.print(" | Y: "); Serial.print(ay);
//   Serial.print(" | Z: "); Serial.println(az);

//   Serial.print("  Gyro  -> X: "); Serial.print(gx);
//   Serial.print(" | Y: "); Serial.print(gy);
//   Serial.print(" | Z: "); Serial.println(gz);

//   // ================= DFROBOT PM2.5 READING =================
//   // CHANGED: Shifted from _ATMOSPHERE to _STANDARD macros to prevent the 0 ug/m3 lockup
//   uint16_t pm1_0 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
//   uint16_t pm2_5 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
//   uint16_t pm10  = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

//   Serial.println("\n[ AIR QUALITY DATA ]");
//   Serial.print("  PM1.0 : "); Serial.print(pm1_0); Serial.println(" ug/m3");
//   Serial.print("  PM2.5 : "); Serial.print(pm2_5); Serial.println(" ug/m3");
//   Serial.print("  PM10  : "); Serial.print(pm10);  Serial.println(" ug/m3");
//   Serial.println("========================================================");

//   delay(2000); // 2-second polling loop
// }

/*
 * DFRobot PM2.5 Air Quality Sensor V2.0 (SEN0460) - Isolated Test
 * Board: ESP32-C6 DevKit
 * Mode: I2C (Pins: SDA=18, SCL=19)
 */

// #include <Wire.h>
// #include <DFRobot_AirQualitySensor.h>

// // Explicit I2C Hardware Pins for your ESP32-C6
// #define I2C_SDA 18
// #define I2C_SCL 19

// // Create the sensor object using the standard 0x19 I2C address
// DFRobot_AirQualitySensor particleSensor(&Wire, 0x19); 

// void setup() {
//   Serial.begin(115200);
//   while(!Serial); // Wait for serial monitor connection

//   Serial.println("\n====================================");
//   Serial.println("Starting Isolated PM2.5 Hardware Test...");
//   Serial.println("====================================");

//   // Initialize Hardware I2C bus
//   Wire.begin(I2C_SDA, I2C_SCL);
  
//   // Power stabilization window for the sensor fan/laser core
//   Serial.println("Waiting 5 seconds for sensor power to stabilize...");
//   delay(5000); 

//   Serial.println("Connecting to DFRobot PM2.5 Sensor...");
//   while (!particleSensor.begin()) {
//     Serial.println("[ERROR] Sensor not found! Check wiring. Retrying in 2 seconds...");
//     delay(2000);
//   }
  
//   Serial.println("[SUCCESS] Sensor connected successfully!");
// }

// void loop() {
//   // Read mass concentrations using verified standard library macros
//   uint16_t pm1_0 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
//   uint16_t pm2_5 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
//   uint16_t pm10  = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

//   // Output data blocks to the Serial Monitor
//   Serial.println("\n------------------------------------");
//   Serial.print("PM1.0 Concentration : "); Serial.print(pm1_0); Serial.println(" ug/m3");
//   Serial.print("PM2.5 Concentration : "); Serial.print(pm2_5); Serial.println(" ug/m3");
//   Serial.print("PM10  Concentration : "); Serial.print(pm10);  Serial.println(" ug/m3");
//   Serial.println("------------------------------------");

//   delay(2000); // 2-second update loop
// }


// -----------------------------------------------------------------------------------------------------


/*
 * Combined Sensor System: MPU6050 Gyro + DFRobot PM2.5 (SEN0460)
 * Board: ESP32-C6 DevKit
 * Fixed Initialization Sequence (SDA=18, SCL=19)
 */

// #include <Wire.h>
// #include <MPU6050.h>
// #include <DFRobot_AirQualitySensor.h>

// #define I2C_SDA 18
// #define I2C_SCL 19

// MPU6050 mpu;
// DFRobot_AirQualitySensor particleSensor(&Wire, 0x19); 

// void setup() {
//   Serial.begin(115200);
//   while(!Serial); 

//   Serial.println("\n--- ESP32-C6 Dual Sensor System Init ---");

//   // 1. Fire up the master I2C hardware line
//   Wire.begin(I2C_SDA, I2C_SCL);
  
//   Serial.println("Stabilizing voltage lines (5 seconds)...");
//   delay(5000); 

//   // 2. Initialize DFRobot PM2.5 Sensor FIRST
//   // This allows the library to run its background I2C configuration checks without breaking the gyro
//   Serial.println("Initializing DFRobot PM2.5 Sensor...");
//   while (!particleSensor.begin()) {
//     Serial.println("[ERROR] PM2.5 Sensor not found! Retrying...");
//     delay(2000);
//   }
//   Serial.println("[SUCCESS] DFRobot PM2.5 Sensor Connected!");

//   // 3. RE-BIND and Initialize MPU6050 SECOND
//   // Forcing Wire.begin() here cleans up any register modifications left behind by the DFRobot library
//   Serial.println("Re-aligning I2C Bus for MPU6050...");
//   Wire.begin(I2C_SDA, I2C_SCL);
//   delay(100);

//   mpu.initialize();
  
//   // Explicitly clear the MPU6050 power/sleep management register to prevent freeze-outs
//   Wire.beginTransmission(0x68); 
//   Wire.write(0x6B); // PWR_MGMT_1 register
//   Wire.write(0x00); // Wake up command (set to 0)
//   Wire.endTransmission(true);

//   if (mpu.testConnection()) {
//     Serial.println("[SUCCESS] MPU6050 Detected and Awake.");
//   } else {
//     Serial.println("[WARNING] MPU6050 Handshake failed, forcing stream activation...");
//   }
  
//   Serial.println("--- System Online ---\n");
// }

// void loop() {
//   Serial.println("\n========================================================");

//   // ================= 1. MPU6050 DATA ACQUISITION =================
//   int16_t ax, ay, az, gx, gy, gz;
//   mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

//   Serial.println("[ MOTION DATA ]");
//   Serial.print("  Accel -> X: "); Serial.print(ax);
//   Serial.print(" | Y: "); Serial.print(ay);
//   Serial.print(" | Z: "); Serial.println(az);

//   Serial.print("  Gyro  -> X: "); Serial.print(gx);
//   Serial.print(" | Y: "); Serial.print(gy);
//   Serial.print(" | Z: "); Serial.println(gz);

//   // ================= 2. DFROBOT PM2.5 DATA ACQUISITION =================
//   uint16_t pm1_0 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
//   uint16_t pm2_5 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
//   uint16_t pm10  = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

//   Serial.println("\n[ AIR QUALITY DATA ]");
//   Serial.print("  PM1.0 : "); Serial.print(pm1_0); Serial.println(" ug/m3");
//   Serial.print("  PM2.5 : "); Serial.print(pm2_5); Serial.println(" ug/m3");
//   Serial.print("  PM10  : "); Serial.print(pm10);  Serial.println(" ug/m3");
//   Serial.println("========================================================");

//   delay(2000); 
// }






// #include <Wire.h>
// #include <MPU6050.h>
// #include <DFRobot_AirQualitySensor.h>

// Shared I2C pins
// #define I2C_SDA 21
// #define I2C_SCL 22

// MPU6050 mpu;
// DFRobot_AirQualitySensor particleSensor(&Wire, 0x19);

// void setup() {
//   Serial.begin(115200);
//   while (!Serial);

//   Serial.println("\n====================================");
//   Serial.println("ESP32-C6: MPU6050 + PM2.5 Combined");
//   Serial.println("====================================");

//   // Initialize shared I2C bus
//   Wire.begin(I2C_SDA, I2C_SCL);

//   // Initialize MPU6050
//   mpu.initialize();
//   if (mpu.testConnection()) {
//     Serial.println("[MPU6050] Connected successfully!");
//   } else {
//     Serial.println("[MPU6050] Connection FAILED! Check wiring.");
//   }

//   // Give PM2.5 sensor time to power up (fan + laser)
//   Serial.println("[PM2.5] Waiting 5 seconds for sensor stabilization...");
//   delay(5000);

//   // Initialize PM2.5 sensor
//   while (!particleSensor.begin()) {
//     Serial.println("[PM2.5] Sensor not found! Check wiring. Retrying...");
//     delay(2000);
//   }
//   Serial.println("[PM2.5] Connected successfully!");
//   Serial.println("====================================\n");
// }

// void loop() {
//   // --- MPU6050 Readings ---
//   int16_t ax, ay, az, gx, gy, gz;
//   mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

//   Serial.println("--- MPU6050 ---");
//   Serial.print("Accel -> X: "); Serial.print(ax);
//   Serial.print(" | Y: "); Serial.print(ay);
//   Serial.print(" | Z: "); Serial.println(az);
//   Serial.print("Gyro  -> X: "); Serial.print(gx);
//   Serial.print(" | Y: "); Serial.print(gy);
//   Serial.print(" | Z: "); Serial.println(gz);

//   // --- PM2.5 Readings ---
//   uint16_t pm1_0 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
//   uint16_t pm2_5 = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
//   uint16_t pm10  = particleSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

//   Serial.println("--- PM2.5 Sensor ---");
//   Serial.print("PM1.0: "); Serial.print(pm1_0); Serial.println(" ug/m3");
//   Serial.print("PM2.5: "); Serial.print(pm2_5); Serial.println(" ug/m3");
//   Serial.print("PM10 : "); Serial.print(pm10);  Serial.println(" ug/m3");

//   Serial.println("------------------------------------\n");
//   delay(2000);
// }
#include <Wire.h>
#include <MPU6050.h>
#include <DFRobot_AirQualitySensor.h>

// Explicitly define standard High-Power I2C pins for ESP32-C6
#define I2C_SDA 19
#define I2C_SCL 18

// DFRobot PM2.5 Default I2C Address is 0x19
#define PM25_I2C_ADDRESS 0x19

// Create hardware sensor instances
MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10); // Wait for Windows terminal window to bind

  Serial.println("\n================================================");
  Serial.println("ESP32-C6: MPU6050 + DFRobot Air Quality Sensor");
  Serial.println("================================================");

  // 1. Core I2C Initialization
  Serial.print("Initializing I2C Bus on GPIO 6 (SDA) and GPIO 7 (SCL)...");
  if (Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(" SUCCESS.");
  } else {
    Serial.println(" FAILED! System halted.");
    while(1);
  }

  // 2. Initialize MPU6050
  Serial.print("Connecting to MPU6050...");
  mpu.initialize();
  if (mpu.testConnection()) {
    Serial.println(" FOUND.");
  } else {
    Serial.println(" FAILED! Check connections.");
  }

  // 3. Initialize DFRobot PM2.5 Sensor
  Serial.println("Waiting 3 seconds for Air Quality Sensor to warm up...");
  delay(3000); 
  
  Serial.print("Connecting to DFRobot PM2.5 Sensor...");
  while (!particle.begin()) {
    Serial.println(" NOT FOUND! Retrying in 1s...");
    delay(1000);
  }
  Serial.println(" FOUND.");
}

void loop() {
  Serial.println("\n--- Sensor Matrix Update ---");

  // Read MPU6050 Data
  int16_t ax, ay, az;
  int16_t gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
  
  Serial.print("IMU -> Accel X:"); Serial.print(ax);
  Serial.print(" Y:"); Serial.print(ay);
  Serial.print(" Z:"); Serial.print(az);
  Serial.print(" | Gyro X:"); Serial.print(gx);
  Serial.print(" Y:"); Serial.println(gy);

  // Read DFRobot PM2.5 Data (Standardized Lab Micrograms/m³)
  uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
  uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
  uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

  Serial.print("Air -> PM1.0: "); Serial.print(pm1_0);
  Serial.print(" ug/m3 | PM2.5: "); Serial.print(pm2_5);
  Serial.print(" ug/m3 | PM10: "); Serial.print(pm10);
  Serial.println(" ug/m3");

  delay(2000); // 2-second telemetry loop pacing
}
