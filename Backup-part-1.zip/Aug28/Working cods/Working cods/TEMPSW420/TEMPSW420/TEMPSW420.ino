#include "DHT.h"

// --- Hardware Pin Definitions ---
const int VIBRATION_PIN = 15; // SW-420 Digital Output connected to GPIO 4
#define DHTPIN 5            // DHT22 Data layout connected to GPIO 5

// --- Sensor Class Declarations ---
#define DHTTYPE DHT22   
DHT dht(DHTPIN, DHTTYPE);

// --- Non-Blocking Timing Variables ---
unsigned long lastDHTReadTime = 0;
const unsigned long dhtInterval = 2000; // Sample DHT22 every 2 seconds

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50; // Filter noise on vibration sensor

// --- Sensor State Variables ---
int lastSensorState = LOW;

void setup() {
  // Initialize Serial Communication for ESP32-C6
  Serial.begin(115200);
  while(!Serial) {
    ; // Wait for hardware serial line initialization
  }
  
  Serial.println(F("============================================="));
  Serial.println(F("Initializing Unified SW-420 & DHT22 Environment"));
  Serial.println(F("============================================="));

  // Initialize Input Pin for SW-420
  pinMode(VIBRATION_PIN, INPUT);

  // Start DHT22 environment sensor tracking
  dht.begin();
  
  Serial.println(F("System Online! Monitoring active..."));
}

void loop() {
  // =================================================================
  // 1. SW-420 VIBRATION SENSOR TRACKING (Real-Time Monitoring)
  // =================================================================
  int currentRead = digitalRead(VIBRATION_PIN);

  // Check if vibration triggers or stabilizes
  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[ALERT] Motion / Vibration Detected!"));
      lastDebounceTime = millis();
    }
  } 
  else if (currentRead == LOW && lastSensorState == HIGH) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[INFO] Vibration stabilized."));
      lastDebounceTime = millis();
    }
  }
  lastSensorState = currentRead;

  // =================================================================
  // 2. DHT22 CLIMATE ENVIRONMENT MONITORING (Non-Blocking 2s Window)
  // =================================================================
  if (millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis(); // Refresh timestamp marker

    float humidity = dht.readHumidity();
    float temperature_C = dht.readTemperature();

    // Verify received values are valid floats
    if (isnan(humidity) || isnan(temperature_C)) {
      Serial.println(F("[ERROR] Failed to read from DHT22 sensor! Check data connection."));
    } else {
      // Print local climate logs to console window
      Serial.print(F("[CLIMATE] Humidity: "));
      Serial.print(humidity, 1);
      Serial.print(F("%  |  Temperature: "));
      Serial.print(temperature_C, 1);
      Serial.println(F("°C"));
    }
  }

  // Small delay yield to prevent hardware watchdog starvation spikes
  delay(1); 
}
