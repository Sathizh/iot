#include <HardwareSerial.h>
#include "DHT.h"

// =================================================================
// 1. HARDWARE PIN DEFINITIONS (Kept exactly as your working codes)
// =================================================================
const int VIBRATION_PIN = 15; // SW-420 Output -> GPIO 15
#define DHTPIN 5              // DHT22 Data Layout -> GPIO 5

#define RX_PIN 7              // LiDAR TX -> GPIO 7 (Green)
#define TX_PIN 6              // LiDAR RX -> GPIO 6 (White)

// =================================================================
// 2. INSTANCE & PROTOCOL DECLARATIONS
// =================================================================
#define DHTTYPE DHT22   
DHT dht(DHTPIN, DHTTYPE);
HardwareSerial LidarSerial(1);

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// =================================================================
// 3. NON-BLOCKING TIMING VARIABLES
// =================================================================
unsigned long lastDHTReadTime = 0;
const unsigned long dhtInterval = 2000;    // Sample DHT22 every 2 seconds

unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;    // Poll LiDAR every 50ms (20Hz)
unsigned long lidarTimeoutStart = 0;
bool waitingForLidar = false;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;    // Filter noise on vibration sensor

// =================================================================
// 4. SENSOR PARSING STATE VARIABLES
// =================================================================
int lastSensorState = LOW;
uint8_t lidarBuffer[8];
int lidarIdx = 0;

void setup() {
  // Initialize Main Hardware Serial
  Serial.begin(115200);
  while(!Serial) { ; }
  
  // Initialize Working UART1 Layout
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("============================================="));
  Serial.println(F("MASTER MERGE: ALL THREE SENSORS WORKING"));
  Serial.println(F("Vibration: GPIO 15 | DHT22: GPIO 5"));
  Serial.println(F("LiDAR RX:  GPIO 7  | LiDAR TX: GPIO 6"));
  Serial.println(F("============================================="));

  pinMode(VIBRATION_PIN, INPUT);

  // Start DHT22 environment sensor tracking
  dht.begin();
  
  Serial.println(F("System Online! Monitoring active..."));
  delay(1000);
}

void loop() {
  // =================================================================
  // LOOP 1: REAL-TIME SW-420 VIBRATION TRACKING (Instantaneous)
  // =================================================================
  int currentRead = digitalRead(VIBRATION_PIN);

  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[ALERT] Motion / Vibration Detected!"));
      lastDebounceTime = millis();
    }
  } 
  else if (currentRead == LOW && lastSensorState == HIGH) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[INFO] Vibration stabilized."));
      lastDebounceTime = millis();
    }
  }
  lastSensorState = currentRead;

  // =================================================================
  // LOOP 2: NON-BLOCKING TF-LC02 LIDAR PROCESSING (20Hz)
  // =================================================================
  // Trigger a poll request every 50ms without using a freeze delay
  if (!waitingForLidar && (millis() - lastLidarPollTime >= lidarInterval)) {
    lastLidarPollTime = millis();
    
    // Request data
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    lidarTimeoutStart = millis();
    waitingForLidar = true;
    lidarIdx = 0;
  }

  // Stream-parse incoming data on the fly if waiting for a frame response
  if (waitingForLidar) {
    while (LidarSerial.available() > 0) {
      uint8_t inByte = LidarSerial.read();

      // Dynamically catch your 0x55 0xAA header structure sequence
      if (lidarIdx == 0 && inByte == 0x55) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else if (lidarIdx == 1 && inByte == 0xAA) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else if (lidarIdx >= 2) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else {
        lidarIdx = 0; // Drop junk data if it shifts alignment mid-stream
      }

      // Check if we hit your complete 8-byte response frame footprint
      if (lidarIdx == 8) {
        waitingForLidar = false; // Successfully released the search window

        if (lidarBuffer[7] == 0xFA) { // Check Footer
          uint16_t dist = (lidarBuffer[4] << 8) | lidarBuffer[5]; // Exact working indices
          uint8_t status = lidarBuffer[6];

          Serial.print(F("[LIDAR] Dist: "));
          Serial.print(dist);
          Serial.print(F("mm | Status: "));

          if (status == 0x00) Serial.println(F("OK (Strong Signal)"));
          else if (status == 0x01) Serial.println(F("WEAK (Low Reflectivity)"));
          else if (status == 0x07) Serial.println(F("AMB (Too much Sunlight)"));
          else Serial.println(F("ERROR"));
        } else {
          Serial.println(F("[LIDAR] Frame Error: Corrupt Footer alignment."));
        }
        break;
      }
    }

    // Handle your exact 45ms window cutoff for timeouts non-blockingly
    if (waitingForLidar && (millis() - lidarTimeoutStart > 45)) {
      waitingForLidar = false;
      Serial.println(F("[LIDAR] TIMEOUT: No packet received."));
    }
  }

  // =================================================================
  // LOOP 3: NON-BLOCKING DHT22 CLIMATE REFRESH ENGINE (Every 2s)
  // =================================================================
  if (millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis(); 

    float humidity = dht.readHumidity();
    float temperature_C = dht.readTemperature();

    if (isnan(humidity) || isnan(temperature_C)) {
      Serial.println(F("[CLIMATE ERROR] Failed to parse DHT22 frame data."));
    } else {
      Serial.print(F("[CLIMATE] Humidity: "));
      Serial.print(humidity, 1);
      Serial.print(F("%  |  Temperature: "));
      Serial.print(temperature_C, 1);
      Serial.println(F("°C"));
    }
  }

  // Prevent internal hardware core controller watchdogs starvation
  delay(1); 
}
