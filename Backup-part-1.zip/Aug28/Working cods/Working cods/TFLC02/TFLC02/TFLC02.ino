#include <HardwareSerial.h>
 
// Pins for ESP32-C6
#define RX_PIN 7  // Lidar TX (Green)
#define TX_PIN 6  // Lidar RX (White)
 
HardwareSerial LidarSerial(1);
 
// Commands
const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};
 
void setup() {
  Serial.begin(115200);
  // C6 UART1 Init
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);
 
  Serial.println("=====================================");
  Serial.println("TF-LC02 RELIABILITY TEST");
  Serial.println("=====================================");
  delay(1000);
}
 
void loop() {
  // Request data
  LidarSerial.write(GET_DIST, sizeof(GET_DIST));
 
  unsigned long startTime = millis();
  bool received = false;
 
  // Listen for response
  while (millis() - startTime < 50) { 
    if (LidarSerial.available() >= 8) {
      if (LidarSerial.read() == 0x55 && LidarSerial.read() == 0xAA) {
        uint8_t buf[6];
        LidarSerial.readBytes(buf, 6);
 
        if (buf[5] == 0xFA) { // Check Footer
          uint16_t dist = (buf[2] << 8) | buf[3];
          uint8_t status = buf[4];
 
          // Log Data
          Serial.print("Dist: ");
          Serial.print(dist);
          Serial.print("mm | Status: ");
 
          if (status == 0x00) Serial.println("OK (Strong Signal)");
          else if (status == 0x01) Serial.println("WEAK (Low Reflectivity)");
          else if (status == 0x07) Serial.println("AMB (Too much Sunlight)");
          else Serial.println("ERROR");
 
          received = true;
          break;
        }
      }
    }
  }
 
  if (!received) Serial.println("TIMEOUT: No packet received.");
 
  delay(50); // Test at 20Hz (20 times per second)
}
