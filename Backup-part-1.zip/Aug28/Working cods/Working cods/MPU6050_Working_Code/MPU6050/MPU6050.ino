#include <MPU6050.h>
#include <Wire.h>
MPU6050 mpu;

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  mpu.initialize();
  Serial.println("MPU Initialized");
}

void loop() {
  int16_t ax, ay, az, gx, gy, gz;

  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  Serial.print("Accel ->");
  Serial.print("X:");
  Serial.print(ax);

  Serial.print(" | Y: ");
  Serial.print(ay);
\
  Serial.print(" | Z: ");
  Serial.print(az);
  Serial.print("\t");

  Serial.print(" || Gyro -> ");
  Serial.print("X:");
  Serial.print(gx);

  Serial.print(" | Y:");
  Serial.print(gy);

  Serial.print(" | Z: ");
  Serial.print(gz);
  Serial.print("\n");

  delay(500);
}