// Define the digital input pin for the SW-420 sensor
// GPIO 4 is standard and easily accessible on the ESP32-C6 DevKitC-1
const int VIBRATION_PIN = 15; 

// Track sensor states
int lastSensorState = LOW;
unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50; // Milliseconds to filter noise

void setup() {
  // Initialize Serial Monitor at 115200 baud rate for ESP32
  Serial.begin(115200);
  while(!Serial) {
    ; // Wait for serial port to connect (Needed for native USB)
  }
  
  // Configure the sensor pin as an input
  pinMode(VIBRATION_PIN, INPUT);
  
  Serial.println("ESP32-C6 SW-420 Vibration Sensor Initialized!");
}

void loop() {
  // Read the current logic level from the SW-420 sensor
  int currentRead = digitalRead(VIBRATION_PIN);

  // Check if the sensor state has flipped (Vibration detected)
  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println("[ALERT] Motion / Vibration Detected!");
      lastDebounceTime = millis();
    }
  } 
  else if (currentRead == LOW && lastSensorState == HIGH) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println("[INFO] Sensor stabilized.");
      lastDebounceTime = millis();
    }
  }

  // Update history state
  lastSensorState = currentRead;

  // Small delay to keep the core from watchdog starving
  delay(10); 
}
