// ============================================================================
// ESP32-C6 SMART SAFETY CAP - WiFi POC FIRMWARE (Option B)
//
// Reads DHT22 (temp/humidity), MPU6050 (motion), SW-420 (vibration),
// TF-LC02 LiDAR (distance), then POSTs a JSON reading to the dashboard
// server every REPORT_INTERVAL ms over WiFi.
//
// Dashboard JSON contract (one object per POST):
//   {"hat_id","worker","area","temperature","gyro_tilt","shock_g",
//    "gas_ppm","noise_db","battery"}
//
// gas_ppm / noise_db are sent as 0 (no sensor on this board yet).
// battery is sent as 100 (no fuel gauge yet).
//
// SETUP: edit the CONFIG block below for each board, then flash.
// ============================================================================

#include <WiFi.h>
#include <HTTPClient.h>
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DHTesp.h>
#include <math.h>

// =================================================================
// 0. CONFIG  --  CHANGE THESE PER BOARD / NETWORK
// =================================================================
const char* WIFI_SSID = "A6663900 4157";       // <-- set your WiFi name
const char* WIFI_PASS = "7>0624Pw";   // <-- set your WiFi password

// PC (server) LAN IP + port. Find it with `ipconfig` on the server PC.
const char* SERVER_URL = "http://192.168.1.50:3000/api/ingest";

// Per-cap identity. Give each board a UNIQUE hat_id.
const char* HAT_ID = "HAT-01";
const char* WORKER = "Worker-01";
const char* AREA   = "Cargo Area";   // must match a dashboard zone name

// How often to report (ms)
const unsigned long REPORT_INTERVAL = 2000;

// =================================================================
// 1. HARDWARE PIN DEFINITIONS
// =================================================================
const int VIBRATION_PIN = 15; // SW-420 Output -> GPIO 15
#define DHTPIN 5              // DHT22 Data -> GPIO 5

#define RX_PIN 7              // LiDAR TX -> GPIO 7 (Green Wire)
#define TX_PIN 6              // LiDAR RX -> GPIO 6 (White Wire)

#define I2C_SDA 19            // MPU6050 SDA
#define I2C_SCL 18            // MPU6050 SCL
#define MPU6050_I2C_ADDR 0x68

// =================================================================
// 2. INSTANCES
// =================================================================
DHTesp dht;
HardwareSerial LidarSerial(1);
MPU6050 mpu;

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// =================================================================
// 3. TIMING / STATE
// =================================================================
unsigned long lastReportTime = 0;

unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;
unsigned long lidarTimeoutStart = 0;
bool waitingForLidar = false;
uint8_t lidarBuffer[10];
int lidarIdx = 0;
uint16_t lastLidarDist = 0;   // most recent good distance (mm)

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;
int lastSensorState = LOW;
volatile bool vibrationLatched = false; // set when vibration seen, cleared each report

// Latest sensor snapshot (updated continuously, sent on report tick)
float g_temperature = 0.0;
float g_tilt = 0.0;
float g_shock = 0.0;

// =================================================================
// WiFi
// =================================================================
void connectWiFi() {
  Serial.print(F("[WiFi] Connecting to "));
  Serial.print(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < 15000) {
    delay(300);
    Serial.print(F("."));
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(F("\n[WiFi] Connected. IP: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("\n[WiFi] FAILED to connect (will retry in loop)."));
  }
}

// =================================================================
// Derived sensor math
// =================================================================
void readMotion() {
  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  // Acceleration magnitude in g (MPU6050 default range +/-2g -> 16384 LSB/g)
  float axg = (float)ax / 16384.0f;
  float ayg = (float)ay / 16384.0f;
  float azg = (float)az / 16384.0f;
  g_shock = sqrtf(axg * axg + ayg * ayg + azg * azg);

  // Tilt angle from vertical (degrees): angle between accel vector and Z axis
  float horiz = sqrtf((float)ax * ax + (float)ay * ay);
  g_tilt = atan2f(horiz, (float)az) * 180.0f / PI;
  if (g_tilt < 0) g_tilt = -g_tilt;
}

void readClimate() {
  float t = dht.getTemperature();
  if (dht.getStatus() == DHTesp::ERROR_NONE && !isnan(t)) {
    g_temperature = t;
  }
  // else keep last good value
}

// =================================================================
// POST reading to server
// =================================================================
void postReading() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println(F("[POST] Skipped - WiFi down"));
    return;
  }

  // If vibration was latched since last report, reflect it as a shock bump
  float shockToSend = g_shock;
  if (vibrationLatched && shockToSend < 2.6f) {
    shockToSend = 2.6f; // nudge into warning range so vibration is visible
  }

  char body[320];
  snprintf(body, sizeof(body),
    "{\"hat_id\":\"%s\",\"worker\":\"%s\",\"area\":\"%s\","
    "\"temperature\":%.1f,\"gyro_tilt\":%.1f,\"shock_g\":%.2f,"
    "\"gas_ppm\":0,\"noise_db\":0,\"battery\":100}",
    HAT_ID, WORKER, AREA, g_temperature, g_tilt, shockToSend);

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(2000);

  int code = http.POST((uint8_t*)body, strlen(body));
  if (code > 0) {
    Serial.print(F("[POST] "));
    Serial.print(code);
    Serial.print(F(" <- "));
    Serial.println(body);
  } else {
    Serial.print(F("[POST] ERROR "));
    Serial.println(http.errorToString(code));
  }
  http.end();

  vibrationLatched = false; // clear latch after each report
}

// =================================================================
// SETUP
// =================================================================
void setup() {
  Serial.begin(115200);
  unsigned long s = millis();
  while (!Serial && (millis() - s) < 2000) { delay(10); }

  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("\n============================================="));
  Serial.println(F("ESP32-C6 SMART CAP - WiFi POC FIRMWARE ONLINE"));
  Serial.println(F("============================================="));

  Serial.print(F("[+] I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) Serial.println(F(" OK.")); else { Serial.println(F(" FAILED!")); }
  Wire.setClock(100000);

  Serial.print(F("[+] MPU6050..."));
  mpu.initialize();
  delay(150);
  Serial.println(F(" INIT."));

  pinMode(VIBRATION_PIN, INPUT);
  dht.setup(DHTPIN, DHTesp::DHT22);
  Serial.println(F("[+] DHT22 profile loaded."));

  connectWiFi();

  lastReportTime = millis();
  Serial.println(F("[+] Monitoring active.\n"));
}

// =================================================================
// LOOP
// =================================================================
void loop() {
  unsigned long currentMillis = millis();

  // Keep WiFi alive
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastRetry = 0;
    if (currentMillis - lastRetry > 5000) {
      lastRetry = currentMillis;
      connectWiFi();
    }
  }

  // ---- Vibration (SW-420), edge detect with debounce ----
  int currentRead = digitalRead(VIBRATION_PIN);
  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((currentMillis - lastDebounceTime) > debounceDelay) {
      vibrationLatched = true;
      lastDebounceTime = currentMillis;
    }
  }
  lastSensorState = currentRead;

  // ---- LiDAR (non-blocking, 20Hz) ----
  if (!waitingForLidar && (currentMillis - lastLidarPollTime >= lidarInterval)) {
    lastLidarPollTime = currentMillis;
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    lidarTimeoutStart = currentMillis;
    waitingForLidar = true;
    lidarIdx = 0;
  }
  if (waitingForLidar) {
    while (LidarSerial.available() > 0) {
      uint8_t inByte = LidarSerial.read();
      if (lidarIdx == 0 && inByte == 0x55) lidarBuffer[lidarIdx++] = inByte;
      else if (lidarIdx == 1 && inByte == 0xAA) lidarBuffer[lidarIdx++] = inByte;
      else if (lidarIdx >= 2 && lidarIdx < 10) lidarBuffer[lidarIdx++] = inByte;
      else lidarIdx = 0;

      if (lidarIdx == 8) {
        waitingForLidar = false;
        if (lidarBuffer[0] == 0x55 && lidarBuffer[1] == 0xAA && lidarBuffer[7] == 0xFA) {
          lastLidarDist = (lidarBuffer[4] << 8) | lidarBuffer[5];
        }
        break;
      }
    }
    if (waitingForLidar && (currentMillis - lidarTimeoutStart > 45)) {
      waitingForLidar = false;
    }
  }

  // ---- Continuously refresh motion snapshot ----
  readMotion();

  // ---- Report tick: refresh climate + POST ----
  if (currentMillis - lastReportTime >= REPORT_INTERVAL) {
    lastReportTime = currentMillis;
    readClimate();
    postReading();
  }

  delay(1);
}
