// ============================================================================
// ESP32-C6 SMART SAFETY CAP - WiFi POC FIRMWARE (Option B)
//
// Reads DHT22 (temp/humidity), MPU6050 (motion), SW-420 (vibration),
// TF-LC02 LiDAR (distance), then POSTs a JSON reading to the dashboard
// server every REPORT_INTERVAL ms over WiFi.
//
// Dashboard JSON contract (one object per POST):
//   {"hat_id","worker","area","temperature","gyro_tilt","shock_g",
//    "gas_ppm","noise_db","battery","distance_mm"}
//
// gas_ppm / noise_db are sent as 0 (no sensor mapped yet).
// battery is sent as 100 (no fuel gauge yet).
//
// SETUP: edit the CONFIG block below for each board, then flash.
// ============================================================================
#include <WiFi.h>
#include <HTTPClient.h>
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DHTesp.h>
#include <DFRobot_AirQualitySensor.h>
#include <math.h>

// =================================================================
// 0. CONFIG  --  CHANGE THESE PER BOARD / NETWORK
// =================================================================
const char* WIFI_SSID = "A6663900 4157";       // <-- set your WiFi name
const char* WIFI_PASS = "7>0624Pw";   // <-- set your WiFi password

// PC (server) LAN IP + port. Find it with `ipconfig` on the server PC.
const char* SERVER_URL = "http://10.205.178.129:3000/api/ingest";

// Per-cap identity. Give each board a UNIQUE hat_id.
const char* HAT_ID = "HAT-08";
const char* WORKER = "Worker-3596659";
const char* AREA   = "Cargo Area";   // must match a dashboard zone name

// How often to report (ms)
const unsigned long REPORT_INTERVAL = 2000;

// Buzzer alert thresholds -- MUST match server THRESHOLDS in server/index.js
// warning = intermittent beep, critical = fast continuous beep
const float TEMP_WARN = 38.0,  TEMP_CRIT = 42.0;   // Celsius
const float SHOCK_WARN = 2.5,  SHOCK_CRIT = 3.5;   // g
const float TILT_WARN = 45.0,  TILT_CRIT = 65.0;   // degrees
const uint16_t PM25_WARN = 55, PM25_CRIT = 150;    // PM2.5 ug/m3 (AQI bands)
const uint16_t DIST_WARN = 305, DIST_CRIT = 150;    // PM2.5 ug/m3 (AQI bands)
// Set to true for an active buzzer (drive HIGH = sound).
// Set to false for a passive buzzer (needs a tone signal).
const bool BUZZER_ACTIVE_TYPE = true;

// I2C address of the air-quality (PM2.5) sensor (found via scan).
const uint8_t AQ_ADDR = 0x19;
// Run the one-time diagnostics (I2C scan + register dump) at boot.
const bool RUN_I2C_DIAG = true;

// =================================================================
// 1. HARDWARE PIN DEFINITIONS
// =================================================================
const int VIBRATION_PIN = 15; // SW-420 Output -> GPIO 15
// Buzzer + -> GPIO 10 (buzzer - -> GND).
// NOTE: do NOT use GPIO 4/5/8/9/15 on the ESP32-C6 -- they are strapping/boot
// pins and can sit HIGH during reset, making an active buzzer sound at boot.
const int BUZZER_PIN    = 10;
#define DHTPIN 5              // DHT22 Data -> GPIO 5

#define RX_PIN 7              // LiDAR TX -> GPIO 7 (Green Wire)
#define TX_PIN 6              // LiDAR RX -> GPIO 6 (White Wire)

#define I2C_SDA 19            // MPU6050 + PM2.5 SDA
#define I2C_SCL 18            // MPU6050 + PM2.5 SCL
#define MPU6050_I2C_ADDR 0x68

// =================================================================
// 2. INSTANCES
// =================================================================
DHTesp dht;
HardwareSerial LidarSerial(1);
MPU6050 mpu;
DFRobot_AirQualitySensor airSensor(&Wire, AQ_ADDR);  // DFRobot Gravity PM2.5 (I2C @ 0x19)
bool aqReady = false;   // set true once the sensor is detected at boot

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// LiDAR "invalid / out of range" sentinel value to ignore.
const uint16_t LIDAR_INVALID = 8888;

// =================================================================
// 3. TIMING / STATE
// =================================================================
unsigned long lastReportTime = 0;

unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;
unsigned long lidarTimeoutStart = 0;
bool waitingForLidar = false;
uint8_t lidarBuffer[10];
int lidarIdx = 0;
uint16_t lastLidarDist = 0;   // most recent GOOD distance (mm)

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;
int lastSensorState = LOW;
volatile bool vibrationLatched = false; // set when vibration seen, cleared each report

// Latest sensor snapshot (updated continuously, sent on report tick)
float g_temperature = 0.0;
float g_tilt = 0.0;
float g_shock = 0.0;

// Air-quality sensor: DFRobot Gravity PM2.5 (I2C @ AQ_ADDR). Values in ug/m3.
uint16_t g_pm25 = 0;   // PM2.5 concentration (ug/m3)
uint16_t g_pm1_0 = 0;  // PM1.0 concentration (ug/m3)
uint16_t g_pm10 = 0;   // PM10 concentration (ug/m3)

// Buzzer / alert state
// severity: 0 = normal, 1 = warning, 2 = critical
int g_severity = 0;
bool g_buzzerOn = false;
unsigned long lastBuzzerToggle = 0;

// =================================================================
// WiFi
// =================================================================
void connectWiFi() {
  Serial.print(F("[WiFi] Connecting to "));
  Serial.print(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < 15000) {
    delay(300);
    Serial.print(F("."));
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(F("\n[WiFi] Connected. IP: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("\n[WiFi] FAILED to connect (will retry in loop)."));
  }
}

// =================================================================
// I2C diagnostics (one-time, at boot)
// =================================================================
void i2cDiagnostics() {
  Serial.println(F("[I2C SCAN] scanning bus..."));
  int found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print(F("[I2C SCAN] device at 0x"));
      if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      found++;
    }
  }
  if (found == 0) { Serial.println(F("[I2C SCAN] NO devices found - check SDA/SCL wiring & power")); return; }
  Serial.print(F("[I2C SCAN] total devices: ")); Serial.println(found);

  // Dump first 32 registers of the AQ sensor to identify the chip.
  Serial.print(F("[AQ DUMP] 0x00-0x1F @0x"));
  Serial.print(AQ_ADDR, HEX); Serial.print(F(":"));
  for (uint8_t reg = 0x00; reg <= 0x1F; reg++) {
    Wire.beginTransmission(AQ_ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) == 0 && Wire.requestFrom((int)AQ_ADDR, 1) == 1) {
      uint8_t val = Wire.read();
      Serial.print(F(" "));
      if (val < 16) Serial.print('0');
      Serial.print(val, HEX);
    } else {
      Serial.print(F(" --"));
    }
  }
  Serial.println();
}

// =================================================================
// Derived sensor math
// =================================================================
void readMotion() {
  int16_t ax, ay, az, gx, gy, gz;
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  // Acceleration magnitude in g (MPU6050 default range +/-2g -> 16384 LSB/g)
  float axg = (float)ax / 16384.0f;
  float ayg = (float)ay / 16384.0f;
  float azg = (float)az / 16384.0f;
  g_shock = sqrtf(axg * axg + ayg * ayg + azg * azg);

  // Tilt angle from vertical (degrees): angle between accel vector and Z axis
  float horiz = sqrtf((float)ax * ax + (float)ay * ay);
  g_tilt = atan2f(horiz, (float)az) * 180.0f / PI;
  if (g_tilt < 0) g_tilt = -g_tilt;
}

void readClimate() {
  float t = dht.getTemperature();
  if (dht.getStatus() == DHTesp::ERROR_NONE && !isnan(t)) {
    g_temperature = t;
  }
  // else keep last good value
}

// Read the DFRobot Gravity PM2.5 air-quality sensor (I2C @ AQ_ADDR).
// Returns PM1.0 / PM2.5 / PM10 concentration in ug/m3. Keeps last good values
// if the sensor isn't ready or a read fails.
void readAirQuality() {
  if (!aqReady) return;
  uint16_t pm25 = airSensor.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
  uint16_t pm10 = airSensor.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
  uint16_t pm1  = airSensor.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
  // Library returns 0 on a failed read; only accept plausible frames.
  if (pm25 != 0 || pm10 != 0 || pm1 != 0) {
    g_pm25 = pm25;
    g_pm10 = pm10;
    g_pm1_0 = pm1;
  }
}

// =================================================================
// Buzzer / alert logic
// =================================================================
int computeSeverity(float shockToCheck) {
  int sev = 0;
  if (g_temperature > TEMP_CRIT || shockToCheck > SHOCK_CRIT || g_tilt > TILT_CRIT
      || g_pm25 > PM25_CRIT) {
    sev = 2;
  } else if (g_temperature > TEMP_WARN || shockToCheck > SHOCK_WARN || g_tilt > TILT_WARN
             || g_pm25 > PM25_WARN) {
    sev = 1;
  }
  return sev;
}

void buzzerOutput(bool on) {
  if (BUZZER_ACTIVE_TYPE) {
    digitalWrite(BUZZER_PIN, on ? HIGH : LOW);
  } else {
    if (on) tone(BUZZER_PIN, 2500); else noTone(BUZZER_PIN);
  }
  g_buzzerOn = on;
}

// Non-blocking buzzer driver -- call every loop.
//   normal   -> silent
//   warning  -> slow intermittent beep (on 150ms / off 850ms)
//   critical -> fast urgent beep (on 120ms / off 120ms)
void updateBuzzer() {
  unsigned long now = millis();

  if (g_severity == 0) {
    if (g_buzzerOn) buzzerOutput(false);
    return;
  }

  unsigned long onTime  = (g_severity == 2) ? 120 : 150;
  unsigned long offTime = (g_severity == 2) ? 120 : 850;

  unsigned long interval = g_buzzerOn ? onTime : offTime;
  if (now - lastBuzzerToggle >= interval) {
    lastBuzzerToggle = now;
    buzzerOutput(!g_buzzerOn);
  }
}

// =================================================================
// POST reading to server
// =================================================================
void postReading() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println(F("[POST] Skipped - WiFi down"));
    return;
  }

  // If vibration was latched since last report, reflect it as a shock bump
  float shockToSend = g_shock;
  if (vibrationLatched && shockToSend < 2.6f) {
    shockToSend = 2.6f; // nudge into warning range so vibration is visible
  }

  // Keep severity (and buzzer) in sync with the exact value we report
  g_severity = computeSeverity(shockToSend);

  char body[400];
  snprintf(body, sizeof(body),
    "{\"hat_id\":\"%s\",\"worker\":\"%s\",\"area\":\"%s\","
    "\"temperature\":%.1f,\"gyro_tilt\":%.1f,\"shock_g\":%.2f,"
    "\"gas_ppm\":0,\"noise_db\":0,\"battery\":100,\"distance_mm\":%u,"
    "\"pm25\":%u,\"pm1_0\":%u,\"pm10\":%u}",
    HAT_ID, WORKER, AREA, g_temperature, g_tilt, shockToSend, lastLidarDist,
    g_pm25, g_pm1_0, g_pm10);

  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(2000);

  int code = http.POST((uint8_t*)body, strlen(body));
  if (code > 0) {
    Serial.print(F("[POST] "));
    Serial.print(code);
    Serial.print(F(" <- "));
    Serial.println(body);
  } else {
    Serial.print(F("[POST] ERROR "));
    Serial.println(http.errorToString(code));
  }
  http.end();

  vibrationLatched = false; // clear latch after each report
}

// =================================================================
// SETUP
// =================================================================
void setup() {
  // Silence the buzzer FIRST so it can't be left sounding from a boot transient.
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  g_buzzerOn = false;

  Serial.begin(115200);
  unsigned long s = millis();
  while (!Serial && (millis() - s) < 2000) { delay(10); }

  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("\n============================================="));
  Serial.println(F("ESP32-C6 SMART CAP - WiFi POC FIRMWARE ONLINE"));
  Serial.println(F("============================================="));

  Serial.print(F("[+] I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) Serial.println(F(" OK.")); else { Serial.println(F(" FAILED!")); }
  Wire.setClock(100000);

  Serial.print(F("[+] MPU6050..."));
  mpu.initialize();
  delay(150);
  Serial.println(F(" INIT."));

  if (RUN_I2C_DIAG) i2cDiagnostics();

  Serial.print(F("[+] Air Quality (DFRobot PM2.5)..."));
  {
    // Retry a few times; the module needs a moment after power-up.
    for (int i = 0; i < 5 && !aqReady; i++) {
      if (airSensor.begin()) aqReady = true; else delay(300);
    }
    if (aqReady) {
      uint8_t ver = airSensor.gainVersion();
      Serial.print(F(" OK (fw v")); Serial.print(ver); Serial.println(F(")."));
    } else {
      Serial.println(F(" NOT FOUND (check wiring @0x19)."));
    }
  }

  pinMode(VIBRATION_PIN, INPUT);
  dht.setup(DHTPIN, DHTesp::DHT22);
  Serial.println(F("[+] DHT22 profile loaded."));

  // Buzzer pin already forced LOW at the very top of setup().
  // Quick startup chirp so you know the buzzer works.
  buzzerOutput(true);  delay(120);  buzzerOutput(false);
  Serial.println(F("[+] Buzzer ready."));

  connectWiFi();

  lastReportTime = millis();
  Serial.println(F("[+] Monitoring active.\n"));
}

// =================================================================
// LOOP
// =================================================================
void loop() {
  unsigned long currentMillis = millis();

  // Keep WiFi alive
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastRetry = 0;
    if (currentMillis - lastRetry > 5000) {
      lastRetry = currentMillis;
      connectWiFi();
    }
  }

  // ---- Vibration (SW-420), edge detect with debounce ----
  int currentRead = digitalRead(VIBRATION_PIN);
  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((currentMillis - lastDebounceTime) > debounceDelay) {
      vibrationLatched = true;
      lastDebounceTime = currentMillis;
    }
  }
  lastSensorState = currentRead;

  // ---- LiDAR (non-blocking, 20Hz) ----
  if (!waitingForLidar && (currentMillis - lastLidarPollTime >= lidarInterval)) {
    lastLidarPollTime = currentMillis;
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    lidarTimeoutStart = currentMillis;
    waitingForLidar = true;
    lidarIdx = 0;
  }
  if (waitingForLidar) {
    while (LidarSerial.available() > 0) {
      uint8_t inByte = LidarSerial.read();
      if (lidarIdx == 0 && inByte == 0x55) lidarBuffer[lidarIdx++] = inByte;
      else if (lidarIdx == 1 && inByte == 0xAA) lidarBuffer[lidarIdx++] = inByte;
      else if (lidarIdx >= 2 && lidarIdx < 10) lidarBuffer[lidarIdx++] = inByte;
      else lidarIdx = 0;

      if (lidarIdx == 8) {
        waitingForLidar = false;
        if (lidarBuffer[0] == 0x55 && lidarBuffer[1] == 0xAA && lidarBuffer[7] == 0xFA) {
          uint16_t dist = (lidarBuffer[4] << 8) | lidarBuffer[5];
          // Ignore the sensor's "invalid / out of range" sentinel (8888) and
          // any frame with a non-zero status byte at index 6.
          if (dist != LIDAR_INVALID && lidarBuffer[6] == 0x00) {
            lastLidarDist = dist;
          }
        }
        break;
      }
    }
    if (waitingForLidar && (currentMillis - lidarTimeoutStart > 45)) {
      waitingForLidar = false;
    }
  }

  // ---- Continuously refresh motion snapshot ----
  readMotion();

  // ---- Live severity: react to boundary crossings immediately (not just every 2s) ----
  {
    float liveShock = g_shock;
    if (vibrationLatched && liveShock < 2.6f) liveShock = 2.6f;
    g_severity = computeSeverity(liveShock);
  }

  // ---- Drive the buzzer every loop (non-blocking) ----
  updateBuzzer();

  // ---- Report tick: refresh climate + POST ----
  if (currentMillis - lastReportTime >= REPORT_INTERVAL) {
    lastReportTime = currentMillis;
    readClimate();
    readAirQuality();
    Serial.print(F("[AQ] PM1.0=")); Serial.print(g_pm1_0);
    Serial.print(F("  PM2.5=")); Serial.print(g_pm25);
    Serial.print(F("  PM10=")); Serial.println(g_pm10);
    postReading();
  }

  delay(1);
}
