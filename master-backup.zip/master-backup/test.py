import serial
import sys

PORT = "COM3"
BAUD = 115200

print(f"Opening {PORT}... (Ensure Arduino Serial Monitor is CLOSED!)")
try:
    ser = serial.Serial(PORT, BAUD, timeout=1)
    print("Connected! Listening for raw lines...\n" + "="*40)
    
    # Read the first 20 lines that arrive
    for i in range(20):
        raw_bytes = ser.readline()
        print(f"Line {i+1} Raw Bytes: {raw_bytes}")
        try:
            print(f"Line {i+1} Decoded  : {raw_bytes.decode('utf-8').strip()}")
        except:
            print(f"Line {i+1} Decoded  : [Failed to decode utf-8]")
        print("-" * 40)
        
    ser.close()
    print("Test finished.")
except Exception as e:
    print(f"Error: {e}")
