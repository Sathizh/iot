// ============================================================================
// ESP32-C6 HARDWARE PINOUT MAPPING REFERENCE
// ============================================================================
//
// 1. DISCRETE SENSORS
//    - SW-420 Vibration Sensor Out : GPIO 15
//    - DHT22 Climate Sensor Data   : GPIO 5
//
// 2. TF-LC02 LIDAR (UART1)
//    - LiDAR TX (Green Wire)       : GPIO 7  ---> ESP32-C6 RX Pin
//    - LiDAR RX (White Wire)       : GPIO 6  ---> ESP32-C6 TX Pin
//
// 3. SHARED HARDWARE I2C BUS (Wire)
//    - Both Sensors Share These Two Physical Pins:
//      * I2C SDA Line              : GPIO 19 ---> MPU6050 SDA & DFRobot SDA
//      * I2C SCL Line              : GPIO 18 ---> MPU6050 SCL & DFRobot SCL
//
//    - Shared I2C Device Addresses:
//      * MPU6050 Gyro/Accel        : 0x68 (Standard Default)
//      * DFRobot PM2.5 Air Quality : 0x19 (Standard Default)
//
// ============================================================================

#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include "DHT.h"
#include <DFRobot_AirQualitySensor.h>

// =================================================================
// 1. HARDWARE PIN DEFINITIONS
// =================================================================
const int VIBRATION_PIN = 15; // SW-420 Output -> GPIO 15
#define DHTPIN 5              // DHT22 Data Layout -> GPIO 5

#define RX_PIN 7              // LiDAR TX -> GPIO 7 (Green)
#define TX_PIN 6              // LiDAR RX -> GPIO 6 (White)

// Shared Hardware I2C Pins for BOTH MPU6050 and DFRobot Air Quality Sensor
#define I2C_SDA 19
#define I2C_SCL 18

// DFRobot PM2.5 Default I2C Address
#define PM25_I2C_ADDRESS 0x19

// =================================================================
// 2. INSTANCE & PROTOCOL DECLARATIONS
// =================================================================
#define DHTTYPE DHT22   
DHT dht(DHTPIN, DHTTYPE);
HardwareSerial LidarSerial(1);

// Both hardware objects point to the standard 'Wire' instance
MPU6050 mpu; 
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// =================================================================
// 3. NON-BLOCKING TIMING VARIABLES
// =================================================================
unsigned long lastDHTReadTime = 0;
const unsigned long dhtInterval = 2000;    // Sample DHT22 every 2 seconds

unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;    // Poll LiDAR every 50ms (20Hz)
unsigned long lidarTimeoutStart = 0;
bool waitingForLidar = false;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;    // Filter noise on vibration sensor

unsigned long lastMPUReadTime = 0;
const unsigned long mpuInterval = 500;     // Sample MPU6050 every 500ms

unsigned long lastAirReadTime = 0;
const unsigned long airInterval = 2000;    // Sample Air Quality every 2 seconds

// =================================================================
// 4. SENSOR PARSING STATE VARIABLES
// =================================================================
int lastSensorState = LOW;
uint8_t lidarBuffer[8];
int lidarIdx = 0;

void setup() {
  // Initialize Main Hardware Serial
  Serial.begin(115200);
  while (!Serial) { delay(10); }
  
  // Initialize Working UART1 Layout
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("============================================="));
  Serial.println(F("MASTER MERGE: SHARED HARDWARE I2C BUS"));
  Serial.println(F("Vibration:   GPIO 15 | DHT22: GPIO 5"));
  Serial.println(F("LiDAR RX:    GPIO 7  | LiDAR TX: GPIO 6"));
  Serial.println(F("I2C Sensors (MPU & Air): SDA 19 | SCL 18"));
  Serial.println(F("============================================="));

  // 1. Core I2C Initialization (Single bus initialization for both devices)
  Serial.print(F("Initializing Shared I2C Bus on GPIO 19 and GPIO 18..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(F(" SUCCESS."));
  } else {
    Serial.println(F(" FAILED! System halted."));
    while(1);
  }

  // 2. Initialize MPU6050
  Serial.print(F("Connecting to MPU6050..."));
  mpu.initialize();
  if (mpu.testConnection()) {
    Serial.println(F(" FOUND."));
  } else {
    Serial.println(F(" FAILED! Check connections."));
  }

  // 3. Initialize DFRobot PM2.5 Sensor
  Serial.println(F("Waiting 3 seconds for Air Quality Sensor to warm up..."));
  delay(3000); 
  
  Serial.print(F("Connecting to DFRobot PM2.5 Sensor..."));
  while (!particle.begin()) {
    Serial.println(F(" NOT FOUND! Retrying in 1s..."));
    delay(1000);
  }
  Serial.println(F(" FOUND."));

  // 4. Initialize Remaining Sensors
  pinMode(VIBRATION_PIN, INPUT);
  dht.begin();
  
  Serial.println(F("System Online! Monitoring active..."));
  delay(1000);
}

void loop() {
  // =================================================================
  // LOOP 1: REAL-TIME SW-420 VIBRATION TRACKING (Instantaneous)
  // =================================================================
  int currentRead = digitalRead(VIBRATION_PIN);

  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[ALERT] Motion / Vibration Detected!"));
      lastDebounceTime = millis();
    }
  } 
  else if (currentRead == LOW && lastSensorState == HIGH) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[INFO] Vibration stabilized."));
      lastDebounceTime = millis();
    }
  }
  lastSensorState = currentRead;

  // =================================================================
  // LOOP 2: NON-BLOCKING TF-LC02 LIDAR PROCESSING (20Hz)
  // =================================================================
  if (!waitingForLidar && (millis() - lastLidarPollTime >= lidarInterval)) {
    lastLidarPollTime = millis();
    
    // Request data
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    lidarTimeoutStart = millis();
    waitingForLidar = true;
    lidarIdx = 0;
  }

  if (waitingForLidar) {
    while (LidarSerial.available() > 0) {
      uint8_t inByte = LidarSerial.read();

      if (lidarIdx == 0 && inByte == 0x55) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else if (lidarIdx == 1 && inByte == 0xAA) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else if (lidarIdx >= 2) {
        lidarBuffer[lidarIdx++] = inByte;
      } 
      else {
        lidarIdx = 0; 
      }

      if (lidarIdx == 8) {
        waitingForLidar = false; 

        if (lidarBuffer[7] == 0xFA) { 
          uint16_t dist = (lidarBuffer[4] << 8) | lidarBuffer[5]; 
          uint8_t status = lidarBuffer[6];

          Serial.print(F("[LIDAR] Dist: "));
          Serial.print(dist);
          Serial.print(F("mm | Status: "));

          if (status == 0x00) Serial.println(F("OK (Strong Signal)"));
          else if (status == 0x01) Serial.println(F("WEAK (Low Reflectivity)"));
          else if (status == 0x07) Serial.println(F("AMB (Too much Sunlight)"));
          else Serial.println(F("ERROR"));
        } else {
          Serial.println(F("[LIDAR] Frame Error: Corrupt Footer alignment."));
        }
        break;
      }
    }

    if (waitingForLidar && (millis() - lidarTimeoutStart > 45)) {
      waitingForLidar = false;
      Serial.println(F("[LIDAR] TIMEOUT: No packet received."));
    }
  }

  // =================================================================
  // LOOP 3: NON-BLOCKING DHT22 CLIMATE REFRESH ENGINE (Every 2s)
  // =================================================================
  if (millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis(); 

    float humidity = dht.readHumidity();
    float temperature_C = dht.readTemperature();

    if (isnan(humidity) || isnan(temperature_C)) {
      Serial.println(F("[CLIMATE ERROR] Failed to parse DHT22 frame data."));
    } else {
      Serial.print(F("[CLIMATE] Humidity: "));
      Serial.print(humidity, 1);
      Serial.print(F("%  |  Temperature: "));
      Serial.print(temperature_C, 1);
      Serial.println(F("°C"));
    }
  }

  // =================================================================
  // LOOP 4: NON-BLOCKING MPU6050 IMU ENGINE (Every 500ms)
  // =================================================================
  if (millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();

    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    Serial.print(F("[IMU] Accel -> X:")); Serial.print(ax);
    Serial.print(F(" | Y: ")); Serial.print(ay);
    Serial.print(F(" | Z: ")); Serial.print(az);
    Serial.print(F("\t || Gyro -> X:")); Serial.print(gx);
    Serial.print(F(" | Y:")); Serial.print(gy);
    Serial.print(F(" | Z: ")); Serial.println(gz);
  }

    // =================================================================
  // LOOP 5: NON-BLOCKING DFRobot AIR QUALITY ENGINE (With Bus Recovery)
  // =================================================================
  if (currentMillis - lastAirReadTime >= airInterval) {
    lastAirReadTime = currentMillis;

    // Force a tiny recovery pause to clear any leftover MPU6050 I2C bus noise
    delay(5); 

    uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

    // Filter out both the 30000+ codes and the specific 29225 (0x7229) frame-shift bug
    if (pm2_5 > 25000 || pm2_5 == 29225 || pm2_5 == 20520) { 
      Serial.println(F("[AIR QUALITY] Warning: I2C frame collision detected. Recovering bus..."));
      
      // Reset the I2C clock rate to keep communication stable
      Wire.setClock(100000); 
    } else {
      Serial.print(F("[AIR QUALITY] PM1.0: ")); Serial.print(pm1_0);
      Serial.print(F(" ug/m3 | PM2.5: ")); Serial.print(pm2_5);
      Serial.print(F(" ug/m3 | PM10: ")); Serial.print(pm10);
      Serial.println(F(" ug/m3"));
    }
  }

  delay(1); 
}
