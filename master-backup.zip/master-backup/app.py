import serial
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
import sys
import traceback

# --- Serial Port Configuration ---
PORT = "COM3"   # Ensure this matches your ESP32-C6 port
BAUD = 115200

try:
    # Small timeout ensures it doesn't block the UI loop indefinitely
    ser = serial.Serial(PORT, BAUD, timeout=0.05)
    print(f"[{PORT}] Successfully connected to ESP32-C6 stream.")
except Exception as e:
    print(f"Fatal: Could not open serial port {PORT}: {e}")
    sys.exit(1)

# --- Matplotlib Window Setup ---
fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection='3d')

# Lock the viewer camera angle so the grid stays completely frozen
# Elevation = 30, Azimuth = -60 (Standard clear isometric perspective)
ax.view_init(elev=30, azim=-60)

# Define dimensions of our solid plate (Width, Thickness, Length)
w, t, l = 1.0, 0.15, 1.0  

# Reference vertices for a solid 3D box centered at (0,0,0)
base_vertices = np.array([
    [-w, -t, -l], [ w, -t, -l], [ w,  t, -l], [-w,  t, -l],  # Bottom Face: Index 0,1,2,3
    [-w, -t,  l], [ w, -t,  l], [ w,  t,  l], [-w,  t,  l]   # Top Face:    Index 4,5,6,7
])

# Explicit linear sequences for the 6 faces to guarantee no syntax drops
face_bottom = [0, 1, 2, 3]
face_top    = [4, 5, 6, 7]
face_front  = [0, 1, 5, 4]
face_back   = [2, 3, 7, 6]
face_left   = [3, 0, 4, 7]
face_right  = [1, 2, 6, 5]

faces_idx = [face_bottom, face_top, face_front, face_back, face_left, face_right]

# Generate placeholder polygons for initial drawing setup
initial_polygons = [base_vertices[face] for face in faces_idx]

# Create the solid 3D Object exactly ONCE on the canvas (Top Face = Orange, Sides = Cyan)
poly_collection = Poly3DCollection(
    initial_polygons, 
    facecolors=['cyan', 'orange', 'cyan', 'cyan', 'cyan', 'cyan'], 
    edgecolors='black', 
    linewidths=1.2, 
    alpha=0.85
)
ax.add_collection3d(poly_collection)

# Freeze the 3D scene grid space completely so it never jumps or rescales
ax.set_xlim(-2, 2)
ax.set_ylim(-2, 2)
ax.set_zlim(-2, 2)

# Fix axis labeling
ax.set_xlabel('X Axis (Pitch)')
ax.set_ylabel('Y Axis (Roll)')
ax.set_zlabel('Z Axis (Yaw)')

# Maintain spatial tracking state globally
state = {"roll": 0.0, "pitch": 0.0, "yaw": 0.0}

def update_data(frame):
    """
    Core runtime frame loop. Mutates the existing 3D polygon structure
    without clearing the plot area, forcing a fixed-view simulation.
    """
    global state
    data_received = False
    
    try:
        # Clear backlog if python frame rate falls behind incoming serial streams
        if ser.in_waiting > 100:
            ser.reset_input_buffer()
            
        if ser.in_waiting > 0:
            raw_line = ser.readline()
            
            # Robust decoding check
            try:
                line = raw_line.decode("utf-8", errors="ignore").strip()
            except Exception as decode_err:
                print(f"[LOG ERROR] String decoding failed for bytes {raw_line}: {decode_err}", file=sys.stderr)
                return poly_collection,

            data = line.split(",")

            if len(data) == 3:
                # Robust parsing check for individual elements
                try:
                    state["roll"] = float(data[0])
                    state["pitch"] = float(data[1])
                    state["yaw"] = float(data[2])
                    data_received = True
                except ValueError as val_err:
                    print(f"[LOG WARNING] Received non-numeric split string: '{line}' ({val_err})", file=sys.stderr)
                    return poly_collection,
            else:
                if len(line) > 0:
                    print(f"[LOG WARNING] Struct misfit. Expected 3 values, got {len(data)} from line: '{line}'", file=sys.stderr)
                    
    except Exception as stream_err:
        print("[LOG FATAL] Serial read drop out:", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        return poly_collection,

    # --- FORCED ROBUST TERMINAL LOGGING ---
    if data_received:
        print(f"📥 MPU6050 DATA -> Roll: {state['roll']:6.1f}° | Pitch: {state['pitch']:6.1f}° | Yaw: {state['yaw']:6.1f}°")
    else:
        print("⏳ Waiting for valid data package on COM3...", end="\r")
    sys.stdout.flush()

    # Convert orientation angles to radians
    r = np.radians(state["roll"])
    p = np.radians(state["pitch"])
    y = np.radians(state["yaw"])

    # Safe element-by-element assignment of transformation matrices
    Rx = np.eye(3)
    Rx[1, 1] = np.cos(r)
    Rx[1, 2] = -np.sin(r)
    Rx[2, 1] = np.sin(r)
    Rx[2, 2] = np.cos(r)
    
    Ry = np.eye(3)
    Ry[0, 0] = np.cos(p)
    Ry[0, 2] = np.sin(p)
    Ry[2, 0] = -np.sin(p)
    Ry[2, 2] = np.cos(p)
    
    Rz = np.eye(3)
    Rz[0, 0] = np.cos(y)
    Rz[0, 1] = -np.sin(y)
    Rz[1, 0] = np.sin(y)
    Rz[1, 1] = np.cos(y)

    # Combine rotations (Tait-Bryan convention)
    R = Rz @ Ry @ Rx
    rotated_vertices = base_vertices @ R.T

    # Generate new coordinate configurations for the 6 faces
    new_polygons = [rotated_vertices[face] for face in faces_idx]
    
    # DIRECTLY MUTATE DRAWING OBJECT: Updates the plate geometry without changing the environment
    poly_collection.set_verts(new_polygons)
    
    # Update title metrics dynamically without resetting the 3D space configuration
    ax.set_title(
        f"MPU6050 Fixed-View Simulation\n"
        f"Roll: {state['roll']:.1f}° | Pitch: {state['pitch']:.1f}° | Yaw: {state['yaw']:.1f}°", 
        pad=15
    )

    return poly_collection,

# Run animation frame cycles using blitting optimization for speed
ani = FuncAnimation(fig, update_data, cache_frame_data=False, interval=15, blit=False)
plt.show()

# Gracefully release system serial lock on execution finish
try:
    ser.close()
    print("\n[PORT] Serial stream safely disconnected.")
except:
    pass
