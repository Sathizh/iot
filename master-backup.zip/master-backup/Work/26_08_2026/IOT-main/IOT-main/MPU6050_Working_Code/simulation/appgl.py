import math
import serial
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *

# --- CONFIGURATION ---
PORT = "COM11"  # Change to your ESP32-C6 port
BAUD = 115200


def draw_flat_board():
  # Define dimensions of the rectangular plate
  dx, dy, dz = 2.0, 0.08, 1.2

  vertices = [
      [dx, dy, -dz],
      [dx, -dy, -dz],
      [-dx, -dy, -dz],
      [-dx, dy, -dz],
      [dx, dy, dz],
      [dx, -dy, dz],
      [-dx, -dy, dz],
      [-dx, dy, dz],
  ]

  surfaces = [
      (0, 1, 2, 3),  # Back
      (3, 2, 6, 7),  # Left
      (7, 6, 5, 4),  # Front
      (4, 5, 1, 0),  # Right
      (1, 5, 6, 2),  # Bottom
      (4, 0, 3, 7),  # Top
  ]

  # Draw flat plate faces (Cyan)
  glBegin(GL_QUADS)
  glColor3f(0.0, 0.8, 0.9)
  for surface in surfaces:
    for vertex in surface:
      glVertex3fv(vertices[vertex])
  glEnd()

  # Draw front direction pointer (Red Accent)
  glBegin(GL_TRIANGLES)
  glColor3f(1.0, 0.2, 0.2)
  glVertex3f(0.0, 0.1, dz + 0.5)
  glVertex3f(-0.3, 0.1, dz)
  glVertex3f(0.3, 0.1, dz)
  glEnd()


def main():
  pygame.init()
  display = (900, 700)
  pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
  pygame.display.set_caption("ESP32-C6 MPU6050 3D Orientation")

  gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)
  glTranslatef(0.0, 0.0, -7)

  glEnable(GL_DEPTH_TEST)

  ser = serial.Serial(PORT, BAUD, timeout=1)
  print(f"Connected to {PORT}...")

  roll, pitch, yaw = 0.0, 0.0, 0.0

  clock = pygame.time.Clock()

  while True:
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        pygame.quit()
        return

    if ser.in_waiting > 0:
      try:
        line = ser.readline().decode("utf-8").strip()
        parts = line.split(",")
        if len(parts) == 3:
          roll = float(parts[0])
          pitch = float(parts[1])
          yaw = float(parts[2])
      except Exception:
        pass

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    glPushMatrix()

    # Apply rotations from MPU6050
    glRotatef(pitch, 1, 0, 0)  # Pitch
    glRotatef(yaw, 0, 1, 0)  # Yaw
    glRotatef(roll, 0, 0, 1)  # Roll

    draw_flat_board()

    glPopMatrix()

    pygame.display.flip()
    clock.tick(60)


if __name__ == "__main__":
  main()