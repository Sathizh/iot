# MPU6050 Real-Time 3D Telemetry Visualizer

A complete hardware-to-software project that reads real-time orientation data (Roll, Pitch, Yaw) from an MPU6050 sensor connected to an ESP32-C6 DevKit, and visualizes it in a high-performance Python 3D dashboard with customizable color palettes and live zero-calibration.

---

## 🛠️ Hardware Connections (Pinout)

Make sure your ESP32-C6 and MPU6050 are wired according to the following I2C mapping:

| ESP32-C6 Pin | MPU6050 Pin | Description |
| :--- | :--- | :--- |
| **5V / VIN** | **VCC** | Power Supply (5V recommended) |
| **GND** | **GND** | Ground |
| **GPIO 20** | **SDA** | I2C Data Line |
| **GPIO 21** | **SCL** | I2C Clock Line |
| **GND** | **AD0** | *Optional:* Set I2C address to `0x68` |

---

## 📥 Installation & Setup Instructions

### 1. Arduino IDE Setup (ESP32-C6 Firmware)
1. Open **Arduino IDE**.
2. Go to **File > Preferences**, and paste this URL into **Additional Boards Manager URLs**:
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. Go to **Tools > Board > Boards Manager**, search for `esp32`, and install **esp32 by Espressif Systems**.
4. Select your board: **Tools > Board > esp32 > ESP32C6 Dev Module**.
5. Ensure **USB CDC On Boot** is set to **Enabled** under the Tools menu.
6. Open Library Manager (`Ctrl + Shift + I`), search for **MPU6050** by Electronic Cats, and install it.
7. Upload your firmware code to the ESP32-C6.

### 2. Python Environment Setup
1. Open your terminal in the project folder.
2. Install the required Python packages:
   ```bash
   pip install pyserial matplotlib numpy-stl

   # 📥 Installation & Setup Instructions (Continued)

### 2. Python Environment Setup (Cont.)
3. To use a custom low-poly 3D aircraft model, place your file in the project folder and rename it to `plane.stl`. If no file is found, the app uses its built-in procedural delta wing automatically.

---

## 🚀 Running the Project

1. Plug your ESP32-C6 into your computer via USB.
2. Run the Python dashboard application:
   ```bash
   python dashboard_final.py