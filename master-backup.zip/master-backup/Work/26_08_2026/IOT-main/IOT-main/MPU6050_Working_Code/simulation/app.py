import serial
from vpython import arrow, box, color, radians, rate, scene, vector

# --- CONFIGURATION ---
PORT = "COM11"  # Adjust to your ESP32-C6 COM port
BAUD = 115200

# Open Serial connection
ser = serial.Serial(PORT, BAUD, timeout=1)

# Set up 3D Scene Window
scene.title = "ESP32-C6 Real-Time 3D Flat Surface Tracking"
scene.width = 900
scene.height = 700
scene.background = vector(0.08, 0.08, 0.12)  # Dark background theme

# Create a flat rectangular surface board in 3D space
flat_board = box(length=5, height=0.15, width=3.5, color=color.cyan)

# Create an arrow indicator showing front direction
direction_arrow = arrow(
    pos=vector(0, 0, 0), axis=vector(0, 0, 2), color=color.red, shaftwidth=0.1
)

print(f"Reading orientation data stream from ESP32-C6 on {PORT}...")

while True:
  try:
    if ser.in_waiting > 0:
      line = ser.readline().decode("utf-8").strip()
      parts = line.split(",")

      if len(parts) == 3:
        roll_deg = float(parts[0])
        pitch_deg = float(parts[1])
        yaw_deg = float(parts[2])

        # Convert degrees to radians
        r = radians(roll_deg)
        p = radians(pitch_deg)
        y = radians(yaw_deg)

        # Reset orientation vectors to defaults
        flat_board.axis = vector(1, 0, 0)
        flat_board.up = vector(0, 1, 0)

        direction_arrow.axis = vector(0, 0, 2)
        direction_arrow.up = vector(0, 1, 0)

        # Apply real-time rotations (Roll, Pitch, Yaw)
        flat_board.rotate(angle=r, axis=vector(1, 0, 0))  # Roll
        flat_board.rotate(angle=p, axis=vector(0, 0, 1))  # Pitch
        flat_board.rotate(angle=y, axis=vector(0, 1, 0))  # Yaw

        direction_arrow.rotate(angle=r, axis=vector(1, 0, 0))
        direction_arrow.rotate(angle=p, axis=vector(0, 0, 1))
        direction_arrow.rotate(angle=y, axis=vector(0, 1, 0))

    rate(50)  # Keep 50 FPS rendering cycle

  except Exception as e:
    print(f"Serial communication error: {e}")
    break