import math
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
import serial
import serial.tools.list_ports

# --- GLOBAL TELEMETRY & APP STATE VARIABLES ---
ser = None
is_connected = False
is_app_running = True
update_job = None

# Sensor values
raw_roll, raw_pitch, raw_yaw = 0.0, 0.0, 0.0
zero_roll, zero_pitch, zero_yaw = 0.0, 0.0, 0.0


# --- SERIAL THREAD ---
def read_serial():
  global ser, is_connected, raw_roll, raw_pitch, raw_yaw, is_app_running
  while is_connected and is_app_running:
    try:
      if ser and ser.in_waiting > 0:
        line = ser.readline().decode("utf-8", errors="ignore").strip()
        parts = line.split(",")
        if len(parts) == 3:
          raw_roll = float(parts[0])
          raw_pitch = float(parts[1])
          raw_yaw = float(parts[2])
    except Exception:
      pass
    time.sleep(0.005)  # 200Hz polling rate for low latency


# --- LIGHTWEIGHT DELTA-WING 3D GEOMETRY ---
def create_lightweight_model():
  """Constructs a clean, low-poly flying wing like the original video.

  Total faces: ~10 (Lightning fast rendering).
  """
  # Body Vertices (Nose, Left Wingtip, Right Wingtip, Tail Center, Cockpit top)
  v_body = np.array([
      [0.0, 7.0, 0.0],  # 0: Nose
      [-6.0, -5.0, 0.0],  # 1: Left Wingtip
      [6.0, -5.0, 0.0],  # 2: Right Wingtip
      [0.0, -4.0, -0.5],  # 3: Tail Bottom
      [0.0, 1.0, 1.2],  # 4: Canopy Top
  ])

  # Faces forming the main airframe
  faces_body = [
      [v_body[0], v_body[1], v_body[4]],  # Upper Left
      [v_body[0], v_body[4], v_body[2]],  # Upper Right
      [v_body[1], v_body[3], v_body[4]],  # Aft Left
      [v_body[2], v_body[4], v_body[3]],  # Aft Right
      [v_body[0], v_body[2], v_body[1]],  # Bottom Flat Surface
  ]

  # Red Elevon Control Flaps (Matching Video)
  v_el_l = np.array([
      [-5.8, -5.0, 0.0],
      [-2.5, -5.0, 0.0],
      [-2.5, -6.8, -0.2],
      [-5.8, -6.8, -0.2],
  ])

  v_el_r = np.array([[2.5, -5.0, 0.0], [5.8, -5.0, 0.0], [5.8, -6.8, -0.2], [
      2.5,
      -6.8,
      -0.2,
  ]])

  faces_elevons = [
      [v_el_l[0], v_el_l[1], v_el_l[2], v_el_l[3]],
      [v_el_r[0], v_el_r[1], v_el_r[2], v_el_r[3]],
  ]

  return faces_body, faces_elevons


FACES_BODY, FACES_ELEVONS = create_lightweight_model()

# --- GUI LAYOUT SETUP ---
root = tk.Tk()
root.title("MPU6050 Low-Poly 3D Telemetry (High FPS)")
root.geometry("1200x750")
root.configure(bg="#1e1e1e")

style = ttk.Style()
style.theme_use("clam")
style.configure(".", background="#1e1e1e", foreground="white")
style.configure("TLabel", background="#1e1e1e", foreground="white")

# --- LEFT CONTROL PANEL ---
left_panel = tk.Frame(root, bg="#252526", width=240, padx=12, pady=12)
left_panel.pack(side=tk.LEFT, fill=tk.Y)

tk.Label(
    left_panel,
    text="TARGET PORT / COM",
    bg="#252526",
    fg="#aaaaaa",
    font=("Consolas", 10, "bold"),
).pack(anchor="w", pady=(0, 5))

port_combobox = ttk.Combobox(left_panel, width=20)
port_combobox.pack(pady=5)


def refresh_ports():
  ports = [p.device for p in serial.tools.list_ports.comports()]
  port_combobox["values"] = ports
  if ports:
    port_combobox.current(0)


refresh_ports()


def toggle_connect():
  global ser, is_connected
  if not is_connected:
    selected_port = port_combobox.get()
    try:
      ser = serial.Serial(selected_port, 115200, timeout=1)
      is_connected = True
      btn_connect.config(text="DISCONNECT", bg="#a83232")
      t = threading.Thread(target=read_serial, daemon=True)
      t.start()
    except Exception as e:
      print(f"Error opening port: {e}")
  else:
    is_connected = False
    if ser:
      ser.close()
    btn_connect.config(text="CONNECT", bg="#0e639c")


btn_connect = tk.Button(
    left_panel,
    text="CONNECT",
    bg="#0e639c",
    fg="white",
    font=("Consolas", 10, "bold"),
    command=toggle_connect,
)
btn_connect.pack(fill=tk.X, pady=10)

tk.Button(
    left_panel,
    text="REFRESH PORTS",
    bg="#333333",
    fg="white",
    command=refresh_ports,
).pack(fill=tk.X, pady=3)


def calibrate_zero_position():
  global zero_roll, zero_pitch, zero_yaw
  zero_roll = raw_roll
  zero_pitch = raw_pitch
  zero_yaw = raw_yaw


tk.Button(
    left_panel,
    text="CALIBRATE / ZERO SENSOR",
    bg="#2e7d32",
    fg="white",
    font=("Consolas", 10, "bold"),
    command=calibrate_zero_position,
).pack(fill=tk.X, pady=10)

# --- RIGHT TELEMETRY PANEL ---
right_panel = tk.Frame(root, bg="#252526", width=220, padx=12, pady=12)
right_panel.pack(side=tk.RIGHT, fill=tk.Y)

tk.Label(
    right_panel,
    text="--- TELEMETRY ---",
    bg="#252526",
    fg="#aaaaaa",
    font=("Consolas", 10, "bold"),
).pack(anchor="w", pady=(0, 10))

lbl_yaw = tk.Label(
    right_panel,
    text="Yaw:   0.00°",
    bg="#252526",
    fg="#4ec9b0",
    font=("Consolas", 12),
)
lbl_yaw.pack(anchor="w", pady=5)

lbl_roll = tk.Label(
    right_panel,
    text="Roll:  0.00°",
    bg="#252526",
    fg="#4ec9b0",
    font=("Consolas", 12),
)
lbl_roll.pack(anchor="w", pady=5)

lbl_pitch = tk.Label(
    right_panel,
    text="Pitch: 0.00°",
    bg="#252526",
    fg="#4ec9b0",
    font=("Consolas", 12),
)
lbl_pitch.pack(anchor="w", pady=5)

# --- CENTER 3D DISPLAY CANVAS ---
fig = plt.figure(facecolor="#1e1e1e")
ax = fig.add_subplot(111, projection="3d", facecolor="#1e1e1e")

canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)


def render_scene(cal_roll, cal_pitch, cal_yaw):
  ax.clear()

  # Bounding area and styling
  ax.set_xlim([-10, 10])
  ax.set_ylim([-10, 10])
  ax.set_zlim([-10, 10])
  ax.grid(True, color="#333333")
  ax.xaxis.pane.fill = False
  ax.yaxis.pane.fill = False
  ax.zaxis.pane.fill = False
  ax.xaxis.pane.set_edgecolor("#222222")
  ax.yaxis.pane.set_edgecolor("#222222")
  ax.zaxis.pane.set_edgecolor("#222222")
  ax.tick_params(colors="gray", labelsize=8)

  # Convert degrees to radians
  r = math.radians(cal_roll)
  p = math.radians(cal_pitch)
  y_rad = math.radians(cal_yaw)

  # Rotation Matrix
  Rx = np.array(
      [[1, 0, 0], [0, math.cos(r), -math.sin(r)], [0, math.sin(r), math.cos(r)]]
  )
  Ry = np.array([[
      math.cos(p),
      0,
      math.sin(p),
  ], [0, 1, 0], [-math.sin(p), 0, math.cos(p)]])
  Rz = np.array([[
      math.cos(y_rad),
      -math.sin(y_rad),
      0,
  ], [math.sin(y_rad), math.cos(y_rad), 0], [0, 0, 1]])

  R = Rz @ Ry @ Rx

  # Rotate airframe faces
  rotated_body = [ (R @ np.array(face).T).T for face in FACES_BODY ]
  rotated_elevons = [ (R @ np.array(face).T).T for face in FACES_ELEVONS ]

  # Render Airframe (Cyan / Teal)
  poly_body = Poly3DCollection(
      rotated_body,
      facecolors="#5da5a4",
      edgecolors="#1e1e1e",
      linewidths=0.5,
      alpha=0.9,
  )
  ax.add_collection3d(poly_body)

  # Render Flaps (Red Accent)
  poly_el = Poly3DCollection(
      rotated_elevons,
      facecolors="#d9534f",
      edgecolors="#1e1e1e",
      linewidths=0.5,
      alpha=0.95,
  )
  ax.add_collection3d(poly_el)

  # Camera perspective matching video angle
  ax.view_init(elev=20, azim=-60)


def update_ui():
  global update_job, is_app_running

  if not is_app_running:
    return

  calibrated_roll = raw_roll - zero_roll
  calibrated_pitch = raw_pitch - zero_pitch
  calibrated_yaw = raw_yaw - zero_yaw

  lbl_roll.config(text=f"Roll:  {calibrated_roll:6.2f}°")
  lbl_pitch.config(text=f"Pitch: {calibrated_pitch:6.2f}°")
  lbl_yaw.config(text=f"Yaw:   {calibrated_yaw:6.2f}°")

  render_scene(calibrated_roll, calibrated_pitch, calibrated_yaw)
  canvas.draw()

  # Refresh at ~50 FPS
  update_job = root.after(20, update_ui)


# --- PROPER EXIT HANDLER ---
def on_closing():
  global is_app_running, is_connected, ser, update_job
  is_app_running = False
  is_connected = False

  if update_job:
    root.after_cancel(update_job)

  if ser and ser.is_open:
    ser.close()

  root.quit()
  root.destroy()
  sys.exit(0)


root.protocol("WM_DELETE_WINDOW", on_closing)
root.after(50, update_ui)
root.mainloop()