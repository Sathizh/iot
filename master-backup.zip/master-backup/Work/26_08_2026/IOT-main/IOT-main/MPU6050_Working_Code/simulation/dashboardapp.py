import math
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import serial
import serial.tools.list_ports

# --- GLOBAL VARIABLES ---
ser = None
is_connected = False
roll, pitch, yaw = 0.0, 0.0, 0.0


# --- SERIAL THREAD ---
def read_serial():
  global ser, is_connected, roll, pitch, yaw
  while is_connected:
    try:
      if ser and ser.in_waiting > 0:
        line = ser.readline().decode('utf-8', errors='ignore').strip()
        parts = line.split(',')
        if len(parts) == 3:
          roll = float(parts[0])
          pitch = float(parts[1])
          yaw = float(parts[2])
    except Exception:
      pass
    time.sleep(0.01)


# --- GUI INITIALIZATION ---
root = tk.Tk()
root.title('MPU6050 3D Ground Control Telemetry')
root.geometry('1200x700')
root.configure(bg='#1e1e1e')

# Style config
style = ttk.Style()
style.theme_use('clam')
style.configure('.', background='#1e1e1e', foreground='white')
style.configure('TLabel', background='#1e1e1e', foreground='white')
style.configure('TButton', background='#333', foreground='white', borderwidth=1)

# --- LEFT PANEL (CONTROLS) ---
left_panel = tk.Frame(root, bg='#252526', width=220, padx=10, pady=10)
left_panel.pack(side=tk.LEFT, fill=tk.Y)

tk.Label(
    left_panel,
    text='TARGET PORT / COM',
    bg='#252526',
    fg='#aaaaaa',
    font=('Consolas', 10, 'bold'),
).pack(anchor='w', pady=(0, 5))

port_combobox = ttk.Combobox(left_panel, width=18)
port_combobox.pack(pady=5)


def refresh_ports():
  ports = [p.device for p in serial.tools.list_ports.comports()]
  port_combobox['values'] = ports
  if ports:
    port_combobox.current(0)


refresh_ports()


def toggle_connect():
  global ser, is_connected
  if not is_connected:
    selected_port = port_combobox.get()
    try:
      ser = serial.Serial(selected_port, 115200, timeout=1)
      is_connected = True
      btn_connect.config(text='DISCONNECT', bg='#a83232')
      t = threading.Thread(target=read_serial, daemon=True)
      t.start()
    except Exception as e:
      print(f'Error connecting: {e}')
  else:
    is_connected = False
    if ser:
      ser.close()
    btn_connect.config(text='CONNECT', bg='#0e639c')


btn_connect = tk.Button(
    left_panel,
    text='CONNECT',
    bg='#0e639c',
    fg='white',
    font=('Consolas', 10, 'bold'),
    command=toggle_connect,
)
btn_connect.pack(fill=tk.X, pady=10)

tk.Button(
    left_panel,
    text='REFRESH PORTS',
    bg='#333333',
    fg='white',
    command=refresh_ports,
).pack(fill=tk.X, pady=2)


def reset_yaw():
  global yaw
  yaw = 0.0


tk.Button(
    left_panel,
    text='ZERO YAW / GYRO',
    bg='#333333',
    fg='white',
    command=reset_yaw,
).pack(fill=tk.X, pady=2)

# --- RIGHT PANEL (TELEMETRY) ---
right_panel = tk.Frame(root, bg='#252526', width=220, padx=10, pady=10)
right_panel.pack(side=tk.RIGHT, fill=tk.Y)

tk.Label(
    right_panel,
    text='--- TELEMETRY ---',
    bg='#252526',
    fg='#aaaaaa',
    font=('Consolas', 10, 'bold'),
).pack(anchor='w', pady=(0, 10))

lbl_yaw = tk.Label(
    right_panel,
    text='Yaw:   0.00°',
    bg='#252526',
    fg='#4ec9b0',
    font=('Consolas', 12),
)
lbl_yaw.pack(anchor='w', pady=5)

lbl_roll = tk.Label(
    right_panel,
    text='Roll:  0.00°',
    bg='#252526',
    fg='#4ec9b0',
    font=('Consolas', 12),
)
lbl_roll.pack(anchor='w', pady=5)

lbl_pitch = tk.Label(
    right_panel,
    text='Pitch: 0.00°',
    bg='#252526',
    fg='#4ec9b0',
    font=('Consolas', 12),
)
lbl_pitch.pack(anchor='w', pady=5)

# --- CENTER PANEL (MATPLOTLIB 3D CANVAS) ---
fig = plt.figure(facecolor='#1e1e1e')
ax = fig.add_subplot(111, projection='3d', facecolor='#1e1e1e')

canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)


def draw_3d_model(r_deg, p_deg, y_deg):
  ax.clear()

  # Set limits & dark theme grid
  ax.set_xlim([-10, 10])
  ax.set_ylim([-10, 10])
  ax.set_zlim([-10, 10])
  ax.grid(True, color='#444444')
  ax.xaxis.pane.fill = False
  ax.yaxis.pane.fill = False
  ax.zaxis.pane.fill = False
  ax.xaxis.pane.set_edgecolor('#333333')
  ax.yaxis.pane.set_edgecolor('#333333')
  ax.zaxis.pane.set_edgecolor('#333333')
  ax.tick_params(colors='gray', labelsize=8)

  # Model geometry (Flat Aircraft-style board)
  # Body
  x = np.array([0, -6, 6, 0])
  y = np.array([8, -6, -6, 8])
  z = np.array([0, 0, 0, 0])

  # Convert angles to radians
  r = math.radians(r_deg)
  p = math.radians(p_deg)
  y_rad = math.radians(y_deg)

  # Rotation matrices
  Rx = np.array(
      [[1, 0, 0], [0, math.cos(r), -math.sin(r)], [0, math.sin(r), math.cos(r)]]
  )
  Ry = np.array([[
      math.cos(p),
      0,
      math.sin(p),
  ], [0, 1, 0], [-math.sin(p), 0, math.cos(p)]])
  Rz = np.array([[
      math.cos(y_rad),
      -math.sin(y_rad),
      0,
  ], [math.sin(y_rad), math.cos(y_rad), 0], [0, 0, 1]])

  R = Rz @ Ry @ Rx

  # Transform points
  pts = np.vstack((x, y, z))
  rotated_pts = R @ pts

  # Plot body plane surface
  ax.plot_trisurf(
      rotated_pts[0, :],
      rotated_pts[1, :],
      rotated_pts[2, :],
      color='#5da5a4',
      alpha=0.85,
  )

  # Elevons (Red control surfaces like in video)
  elevon_l = np.array([[-6, -4, -4, -6], [-6, -6, -8, -8], [0, 0, 0, 0]])
  elevon_r = np.array([[4, 6, 6, 4], [-6, -6, -8, -8], [0, 0, 0, 0]])

  rot_el_l = R @ elevon_l
  rot_el_r = R @ elevon_r

  ax.plot_trisurf(
      rot_el_l[0, :], rot_el_l[1, :], rot_el_l[2, :], color='#d9534f', alpha=0.9
  )
  ax.plot_trisurf(
      rot_el_r[0, :], rot_el_r[1, :], rot_el_r[2, :], color='#d9534f', alpha=0.9
  )

  # Camera perspective matching video angle
  ax.view_init(elev=20, azim=-60)


def update_gui():
  lbl_roll.config(text=f'Roll:  {roll:6.2f}°')
  lbl_pitch.config(text=f'Pitch: {pitch:6.2f}°')
  lbl_yaw.config(text=f'Yaw:   {yaw:6.2f}°')

  draw_3d_model(roll, pitch, yaw)
  canvas.draw()

  root.after(40, update_gui)  # ~25 FPS refresh rate


root.after(100, update_gui)
root.mainloop()