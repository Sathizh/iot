import math
import os
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
import serial
import serial.tools.list_ports

# Try importing numpy-stl for custom 3D model support
try:
  from stl import mesh

  HAS_STL = True
except ImportError:
  HAS_STL = False

# --- GLOBAL VARIABLES ---
ser = None
is_connected = False
is_app_running = True
update_job = None

raw_roll, raw_pitch, raw_yaw = 0.0, 0.0, 0.0
zero_roll, zero_pitch, zero_yaw = 0.0, 0.0, 0.0

stl_mesh_vectors = None
STL_FILENAME = "./assets/plane2.stl"


# --- AUTO-TRANSFORM & SCALE STL MODEL ---
def prepare_stl_model(filename):
  """Loads STL, rotates it flat horizontally, and auto-scales it."""
  if not (HAS_STL and os.path.exists(filename)):
    return None

  try:
    loaded_mesh = mesh.Mesh.from_file(filename)
    vecs = loaded_mesh.vectors.reshape(-1, 3)

    # Rotate mesh if vertically standing
    min_b = vecs.min(axis=0)
    max_b = vecs.max(axis=0)
    dims = max_b - min_b

    # If height (Z or Y) is longer than length, rotate 90 deg around X-axis
    if dims[2] > dims[1] or dims[2] > dims[0]:
      rx = math.radians(-90)
      Rx = np.array([
          [1, 0, 0],
          [0, math.cos(rx), -math.sin(rx)],
          [0, math.sin(rx), math.cos(rx)],
      ])
      vecs = (Rx @ vecs.T).T

    # Center at origin (0, 0, 0)
    center = (vecs.min(axis=0) + vecs.max(axis=0)) / 2.0
    vecs -= center

    # Auto scale to fit [-7, 7] bounding box for low-latency rendering
    max_dim = np.max(vecs.max(axis=0) - vecs.min(axis=0))
    if max_dim > 0:
      vecs *= 14.0 / max_dim

    print(f"Successfully loaded and optimized STL: {filename}")
    return vecs.reshape(-1, 3, 3)
  except Exception as e:
    print(f"Error processing STL: {e}")
    return None


stl_mesh_vectors = prepare_stl_model(STL_FILENAME)


# --- SERIAL THREAD ---
def read_serial():
  global ser, is_connected, raw_roll, raw_pitch, raw_yaw, is_app_running
  while is_connected and is_app_running:
    try:
      if ser and ser.in_waiting > 0:
        line = ser.readline().decode("utf-8", errors="ignore").strip()
        parts = line.split(",")
        if len(parts) == 3:
          raw_roll = float(parts[0])
          raw_pitch = float(parts[1])
          raw_yaw = float(parts[2])
    except Exception:
      pass
    time.sleep(0.005)


# --- FALLBACK LIGHTWEIGHT PROCEDURAL DELTA WING ---
def create_fallback_wing():
  v_body = np.array([
      [0.0, 6.0, 0.0],
      [-5.5, -4.0, 0.0],
      [5.5, -4.0, 0.0],
      [0.0, -3.0, -0.4],
      [0.0, 0.5, 1.0],
  ])
  faces = [
      [v_body[0], v_body[1], v_body[4]],
      [v_body[0], v_body[4], v_body[2]],
      [v_body[1], v_body[3], v_body[4]],
      [v_body[2], v_body[4], v_body[3]],
      [v_body[0], v_body[2], v_body[1]],
  ]
  el_l = np.array([
      [-5.3, -4.0, 0.0],
      [-2.0, -4.0, 0.0],
      [-2.0, -5.5, -0.2],
      [-5.3, -5.5, -0.2],
  ])
  el_r = np.array([
      [2.0, -4.0, 0.0],
      [5.3, -4.0, 0.0],
      [5.3, -5.5, -0.2],
      [2.0, -5.5, -0.2],
  ])
  elevons = [
      [el_l[0], el_l[1], el_l[2], el_l[3]],
      [el_r[0], el_r[1], el_r[2], el_r[3]],
  ]
  return faces, elevons


FALLBACK_FACES, FALLBACK_ELEVONS = create_fallback_wing()

# --- GUI LAYOUT SETUP ---
root = tk.Tk()
root.title("MPU6050 3D Ground Control Telemetry")
root.geometry("1200x750")
root.configure(bg="#1e1e1e")

style = ttk.Style()
style.theme_use("clam")
style.configure(".", background="#1e1e1e", foreground="white")
style.configure("TLabel", background="#1e1e1e", foreground="white")

# --- LEFT CONTROL PANEL ---
left_panel = tk.Frame(root, bg="#252526", width=240, padx=12, pady=12)
left_panel.pack(side=tk.LEFT, fill=tk.Y)

tk.Label(
    left_panel,
    text="TARGET PORT / COM",
    bg="#252526",
    fg="#aaaaaa",
    font=("Consolas", 10, "bold"),
).pack(anchor="w", pady=(0, 5))

port_combobox = ttk.Combobox(left_panel, width=20)
port_combobox.pack(pady=5)


def refresh_ports():
  ports = [p.device for p in serial.tools.list_ports.comports()]
  port_combobox["values"] = ports
  if ports:
    port_combobox.current(0)


refresh_ports()


def toggle_connect():
  global ser, is_connected
  if not is_connected:
    selected_port = port_combobox.get()
    try:
      ser = serial.Serial(selected_port, 115200, timeout=1)
      is_connected = True
      btn_connect.config(text="DISCONNECT", bg="#a83232")
      t = threading.Thread(target=read_serial, daemon=True)
      t.start()
    except Exception as e:
      print(f"Error opening port: {e}")
  else:
    is_connected = False
    if ser:
      ser.close()
    btn_connect.config(text="CONNECT", bg="#0e639c")


btn_connect = tk.Button(
    left_panel,
    text="CONNECT",
    bg="#0e639c",
    fg="white",
    font=("Consolas", 10, "bold"),
    command=toggle_connect,
)
btn_connect.pack(fill=tk.X, pady=10)

tk.Button(
    left_panel,
    text="REFRESH PORTS",
    bg="#333333",
    fg="white",
    command=refresh_ports,
).pack(fill=tk.X, pady=3)


def calibrate_zero_position():
  global zero_roll, zero_pitch, zero_yaw
  zero_roll = raw_roll
  zero_pitch = raw_pitch
  zero_yaw = raw_yaw


tk.Button(
    left_panel,
    text="CALIBRATE / ZERO SENSOR",
    bg="#2e7d32",
    fg="white",
    font=("Consolas", 10, "bold"),
    command=calibrate_zero_position,
).pack(fill=tk.X, pady=10)

# --- RIGHT TELEMETRY PANEL ---
right_panel = tk.Frame(root, bg="#252526", width=220, padx=12, pady=12)
right_panel.pack(side=tk.RIGHT, fill=tk.Y)

tk.Label(
    right_panel,
    text="--- TELEMETRY ---",
    bg="#252526",
    fg="#aaaaaa",
    font=("Consolas", 10, "bold"),
).pack(anchor="w", pady=(0, 10))

lbl_yaw = tk.Label(
    right_panel,
    text="Yaw:   0.00°",
    bg="#252526",
    fg="#4ec9b0",
    font=("Consolas", 12),
)
lbl_yaw.pack(anchor="w", pady=5)

lbl_roll = tk.Label(
    right_panel,
    text="Roll:  0.00°",
    bg="#252526",
    fg="#4ec9b0",
    font=("Consolas", 12),
)
lbl_roll.pack(anchor="w", pady=5)

lbl_pitch = tk.Label(
    right_panel,
    text="Pitch: 0.00°",
    bg="#252526",
    fg="#4ec9b0",
    font=("Consolas", 12),
)
lbl_pitch.pack(anchor="w", pady=5)

# --- CENTER 3D CANVAS ---
fig = plt.figure(facecolor="#1e1e1e")
ax = fig.add_subplot(111, projection="3d", facecolor="#1e1e1e")

canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)


def render_scene(cal_roll, cal_pitch, cal_yaw):
  ax.clear()

  ax.set_xlim([-10, 10])
  ax.set_ylim([-10, 10])
  ax.set_zlim([-10, 10])
  ax.grid(True, color="#333333")
  ax.xaxis.pane.fill = False
  ax.yaxis.pane.fill = False
  ax.zaxis.pane.fill = False
  ax.xaxis.pane.set_edgecolor("#222222")
  ax.yaxis.pane.set_edgecolor("#222222")
  ax.zaxis.pane.set_edgecolor("#222222")
  ax.tick_params(colors="gray", labelsize=8)

  # *** BOTH ROLL AND PITCH ARE NEGATED (-) TO FIX INVERTED MOVEMENT ***
  r = math.radians(-cal_roll)
  p = math.radians(-cal_pitch)
  y_rad = math.radians(cal_yaw)

  # 3D Rotation Matrix
  Rx = np.array(
      [[1, 0, 0], [0, math.cos(r), -math.sin(r)], [0, math.sin(r), math.cos(r)]]
  )
  Ry = np.array([[
      math.cos(p),
      0,
      math.sin(p),
  ], [0, 1, 0], [-math.sin(p), 0, math.cos(p)]])
  Rz = np.array([[
      math.cos(y_rad),
      -math.sin(y_rad),
      0,
  ], [math.sin(y_rad), math.cos(y_rad), 0], [0, 0, 1]])

  R = Rz @ Ry @ Rx

  if stl_mesh_vectors is not None:
    # Render loaded light STL
    vecs = stl_mesh_vectors.reshape(-1, 3)
    rotated_vectors = (R @ vecs.T).T.reshape(-1, 3, 3)

    poly3d = Poly3DCollection(
        rotated_vectors,
        facecolors="#5da5a4",
        edgecolors="#222222",
        linewidths=0.2,
        alpha=0.9,
    )
    ax.add_collection3d(poly3d)
  else:
    # Render procedural flying wing
    rot_body = [(R @ np.array(f).T).T for f in FALLBACK_FACES]
    rot_el = [(R @ np.array(f).T).T for f in FALLBACK_ELEVONS]

    poly_body = Poly3DCollection(
        rot_body,
        facecolors="#5da5a4",
        edgecolors="#1e1e1e",
        linewidths=0.5,
        alpha=0.9,
    )
    poly_el = Poly3DCollection(
        rot_el,
        facecolors="#d9534f",
        edgecolors="#1e1e1e",
        linewidths=0.5,
        alpha=0.95,
    )
    ax.add_collection3d(poly_body)
    ax.add_collection3d(poly_el)

  ax.view_init(elev=20, azim=-60)


def update_ui():
  global update_job, is_app_running

  if not is_app_running:
    return

  calibrated_roll = raw_roll - zero_roll
  calibrated_pitch = raw_pitch - zero_pitch
  calibrated_yaw = raw_yaw - zero_yaw

  lbl_roll.config(text=f"Roll:  {calibrated_roll:6.2f}°")
  lbl_pitch.config(text=f"Pitch: {calibrated_pitch:6.2f}°")
  lbl_yaw.config(text=f"Yaw:   {calibrated_yaw:6.2f}°")

  render_scene(calibrated_roll, calibrated_pitch, calibrated_yaw)
  canvas.draw()

  update_job = root.after(20, update_ui)  # ~50 FPS update rate


def on_closing():
  global is_app_running, is_connected, ser, update_job
  is_app_running = False
  is_connected = False

  if update_job:
    root.after_cancel(update_job)

  if ser and ser.is_open:
    ser.close()

  root.quit()
  root.destroy()
  sys.exit(0)


root.protocol("WM_DELETE_WINDOW", on_closing)
root.after(50, update_ui)
root.mainloop()