#include <Wire.h>
///waking up gyro from sleep mode
#define MPU6050_ADDR 0x68

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 4000);

  // Initialize I2C on GPIO 20 (SDA) and GPIO 21 (SCL)
  Wire.begin(20, 21);
  Wire.setClock(100000); // 100kHz standard I2C speed

  // Wake up MPU6050 (Clear Sleep Bit in Power Management 1 Register 0x6B)
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x6B); // Power Management 1 register
  Wire.write(0);    // Set to 0 to wake up sensor
  byte error = Wire.endTransmission();

  if (error == 0) {
    Serial.println("MPU6050 Woken Up Successfully!");
  } else {
    Serial.printf("Failed to wake up sensor. I2C Error code: %d\n", error);
  }
}

void loop() {
  // Request 14 bytes starting from ACCEL_XOUT_H (0x3B)
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x3B);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)MPU6050_ADDR, (size_t)14, true);

  if (Wire.available() >= 14) {
    // Read raw Accelerometer values
    int16_t ax = (Wire.read() << 8) | Wire.read();
    int16_t ay = (Wire.read() << 8) | Wire.read();
    int16_t az = (Wire.read() << 8) | Wire.read();

    // Read Temperature (skip or use)
    int16_t temp = (Wire.read() << 8) | Wire.read();

    // Read raw Gyroscope values
    int16_t gx = (Wire.read() << 8) | Wire.read();
    int16_t gy = (Wire.read() << 8) | Wire.read();
    int16_t gz = (Wire.read() << 8) | Wire.read();

    // Calculate basic Roll and Pitch
    float accel_roll = atan2((float)ay, (float)az) * 180.0 / M_PI;
    float accel_pitch = atan2(-(float)ax, sqrt((float)ay * ay + (float)az * az)) * 180.0 / M_PI;

    // Send formatted string to Python app
    Serial.print(accel_roll);
    Serial.print(",");
    Serial.print(accel_pitch);
    Serial.print(",");
    Serial.println(0.0);
  } else {
    Serial.println("Error: Sensor data not available on Wire bus");
  }

  delay(20); // 50 Hz loop
}