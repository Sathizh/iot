const int irSensorPin = 2; // IR Sensor OUT pin
const int buzzerPin = 1;   // Buzzer Signal pin

void setup() {
  pinMode(irSensorPin, INPUT);
  pinMode(buzzerPin, OUTPUT);
  digitalWrite(buzzerPin, LOW); 
}

void loop() {
  // Check if IR sensor detects an obstacle (LOW)
  if (digitalRead(irSensorPin) == LOW) {
    
    // --- Start of Rhythmic Pattern ---
    
    // Beep 1
    digitalWrite(buzzerPin, HIGH); // For Passive, use: tone(buzzerPin, 1000);
    delay(150);                     // Duration of the beep
    
    // Silence 1
    digitalWrite(buzzerPin, LOW);  // For Passive, use: noTone(buzzerPin);
    delay(150);                     // Duration of the pause
    
    // Beep 2
    digitalWrite(buzzerPin, HIGH); // For Passive, use: tone(buzzerPin, 1000);
    delay(150);
    
    // Silence 2
    digitalWrite(buzzerPin, LOW);  // For Passive, use: noTone(buzzerPin);
    delay(500);                     // Longer pause before repeating the rhythm
    
    // --- End of Rhythmic Pattern ---
    
  } else {
    // No obstacle: Keep buzzer silent
    digitalWrite(buzzerPin, LOW);  // For Passive, use: noTone(buzzerPin);
  }
  
  delay(20); // Small stability delay
}
