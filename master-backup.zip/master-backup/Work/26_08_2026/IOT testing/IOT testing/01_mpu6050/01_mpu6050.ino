/*
 * =================================================================
 * STEP 1: MPU6050 ONLY
 * =================================================================
 * Purpose: Verify the shared hardware I2C bus + MPU6050 in isolation.
 * If this fails, the problem is wiring / I2C / power, NOT code merging.
 *
 * WIRING (same as your master code, LiDAR excluded):
 *   I2C SDA -> GPIO 19
 *   I2C SCL -> GPIO 18
 *   MPU6050 VCC -> 3.3V, GND -> GND
 *
 * WHAT TO LOOK FOR:
 *   - "MPU6050 ... FOUND." on boot.
 *   - Accel/Gyro values that change when you move the board.
 *   - If values are frozen at 0 or -1, it's a wiring/pull-up issue.
 * =================================================================
 */
#include <Wire.h>
#include <MPU6050.h>

#define I2C_SDA 19
#define I2C_SCL 18

MPU6050 mpu;

unsigned long lastMPUReadTime = 0;
const unsigned long mpuInterval = 500;

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }

  Serial.println(F("============================================="));
  Serial.println(F("STEP 1: MPU6050 ISOLATION TEST"));
  Serial.println(F("I2C: SDA 19 | SCL 18"));
  Serial.println(F("============================================="));

  Serial.print(F("Initializing I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(F(" SUCCESS."));
  } else {
    Serial.println(F(" FAILED! System halted."));
    while (1) { delay(100); }
  }
  // Keep I2C clock conservative for reliability on long/shared wires.
  Wire.setClock(100000);

  Serial.print(F("Connecting to MPU6050..."));
  mpu.initialize();
  if (mpu.testConnection()) {
    Serial.println(F(" FOUND."));
  } else {
    Serial.println(F(" FAILED! Check wiring, power (3.3V), and pull-ups."));
  }

  Serial.println(F("System Online! Monitoring MPU6050..."));
}

void loop() {
  if (millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();

    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    Serial.print(F("[IMU] Accel -> X:")); Serial.print(ax);
    Serial.print(F(" | Y: ")); Serial.print(ay);
    Serial.print(F(" | Z: ")); Serial.print(az);
    Serial.print(F("\t || Gyro -> X:")); Serial.print(gx);
    Serial.print(F(" | Y:")); Serial.print(gy);
    Serial.print(F(" | Z: ")); Serial.println(gz);
  }
  delay(1);
}
