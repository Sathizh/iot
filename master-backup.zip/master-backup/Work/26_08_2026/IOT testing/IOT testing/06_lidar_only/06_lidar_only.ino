/*
 * =================================================================
 * STEP 6: TF-LC02 LiDAR ONLY (WAKE + ROBUST PARSER)
 * =================================================================
 * Purpose: Prove the LiDAR works in isolation on UART1. This is your
 * problem child, so we test it alone with a hardened parser + a wake
 * sequence before merging.
 *
 * WIRING (same as master):
 *   LiDAR TX (Green) -> GPIO 7  (ESP RX_PIN)
 *   LiDAR RX (White) -> GPIO 6  (ESP TX_PIN)
 *   LiDAR VCC -> 5V, GND -> GND
 *
 * WHY IT SOMETIMES DIES WHEN MERGED:
 *   In the master sketch the LiDAR parser breaks out of its while-loop
 *   after ONE frame, but the blocking I2C reads (MPU + PM2.5) and DHT22
 *   read can hold the CPU long enough that the small UART FIFO overflows
 *   and frames get corrupted -> "Frame Error" / no output. The final
 *   merge fixes this with a self-syncing byte-by-byte state machine that
 *   never blocks and resyncs on the 0x55 0xAA header automatically.
 *
 * WAKE: Some TF-LC02 units power up idle. We send the measurement
 * command repeatedly; there is no true sleep on this unit, but sending
 * the command "kicks" it. If your unit supports a start/stop frame,
 * add it here.
 * =================================================================
 */
#include <HardwareSerial.h>

#define RX_PIN 7   // LiDAR TX -> here
#define TX_PIN 6   // LiDAR RX -> here

HardwareSerial LidarSerial(1);

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// Self-syncing parser state
uint8_t lidarBuf[8];
int lidarIdx = 0;

unsigned long lastPoll = 0;
const unsigned long pollInterval = 50; // 20 Hz

void feedLidarByte(uint8_t b) {
  // State machine that resyncs on header automatically.
  if (lidarIdx == 0) {
    if (b == 0x55) lidarBuf[lidarIdx++] = b;
  } else if (lidarIdx == 1) {
    if (b == 0xAA) lidarBuf[lidarIdx++] = b;
    else lidarIdx = (b == 0x55) ? 1 : 0; // handle back-to-back 0x55
  } else {
    lidarBuf[lidarIdx++] = b;
    if (lidarIdx == 8) {
      if (lidarBuf[7] == 0xFA) {
        uint16_t dist = (lidarBuf[4] << 8) | lidarBuf[5];
        uint8_t status = lidarBuf[6];
        Serial.print(F("[LIDAR] Dist: ")); Serial.print(dist);
        Serial.print(F("mm | Status: "));
        if (status == 0x00) Serial.println(F("OK"));
        else if (status == 0x01) Serial.println(F("WEAK"));
        else if (status == 0x07) Serial.println(F("AMBIENT"));
        else Serial.println(F("ERROR"));
      } else {
        Serial.println(F("[LIDAR] Frame footer mismatch, resyncing."));
      }
      lidarIdx = 0;
    }
  }
}

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("STEP 6: TF-LC02 LiDAR ISOLATION TEST"));
  Serial.println(F("RX_PIN 7 (<-LiDAR TX) | TX_PIN 6 (->LiDAR RX)"));

  // Wake / kick: flush and send a few commands
  delay(200);
  while (LidarSerial.available()) LidarSerial.read();
  for (int i = 0; i < 3; i++) {
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    delay(60);
  }
  Serial.println(F("LiDAR polling started..."));
}

void loop() {
  if (millis() - lastPoll >= pollInterval) {
    lastPoll = millis();
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
  }

  // Drain everything available every loop so the FIFO never overflows.
  while (LidarSerial.available() > 0) {
    feedLidarByte((uint8_t)LidarSerial.read());
  }

  delay(1);
}
