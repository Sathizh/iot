# IOT Testing — Incremental Sensor Bring-Up

This folder lets you flash and verify each sensor **one at a time**, then
combine them all into a single working sketch. Follow the steps in order.
If a step fails, you have isolated the problem before adding more sensors.

Board assumed: **ESP32-class board** (uses `HardwareSerial(1)` + custom I2C pins).

---

## 1. Required Libraries

Install these via **Arduino IDE → Tools → Manage Libraries** (or PlatformIO).
These are the exact libraries used by your existing/master code.

| Library | Used for | Install name (Library Manager) |
|---|---|---|
| `Wire` | I2C bus | Built-in (comes with the ESP32 core) |
| `HardwareSerial` | LiDAR UART1 | Built-in (comes with the ESP32 core) |
| `MPU6050` | MPU6050 IMU | **"MPU6050" by Electronic Cats** (Jeff Rowberg's I2Cdevlib port) |
| `DHT sensor library` | DHT22 climate | **"DHT sensor library" by Adafruit** |
| `Adafruit Unified Sensor` | Dependency of DHT library | **"Adafruit Unified Sensor"** |
| `DFRobot_AirQualitySensor` | PM2.5 air quality | **"DFRobot_AirQualitySensor"** (or from DFRobot GitHub) |

### Board support (one-time)
- Install the **ESP32 board package**:
  - Arduino IDE → File → Preferences → *Additional Boards Manager URLs*:
    `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
  - Then Tools → Board → Boards Manager → install **esp32 by Espressif Systems**.
- Select your specific ESP32 board and the correct COM port.

### If a library is missing from Library Manager
- `MPU6050`: https://github.com/ElectronicCats/mpu6050
- `DFRobot_AirQualitySensor`: https://github.com/DFRobot/DFRobot_AirQualitySensor
  (Download ZIP → Arduino IDE → Sketch → Include Library → Add .ZIP Library)

---

## 2. Wiring (kept identical to your master code)

| Sensor | Signal | ESP32 GPIO | Power |
|---|---|---|---|
| SW-420 Vibration | DOUT | GPIO 15 | 3.3V / 5V |
| DHT22 | DATA (10k pull-up) | GPIO 5 | 3.3V / 5V |
| TF-LC02 LiDAR | TX (Green) → | GPIO 7 (RX_PIN) | 5V |
| TF-LC02 LiDAR | RX (White) ← | GPIO 6 (TX_PIN) | 5V |
| MPU6050 | SDA | GPIO 19 | 3.3V |
| MPU6050 | SCL | GPIO 18 | 3.3V |
| PM2.5 (DFRobot) | SDA | GPIO 19 | **5V** |
| PM2.5 (DFRobot) | SCL | GPIO 18 | **5V** |

I2C addresses: **MPU6050 = 0x68**, **PM2.5 = 0x19** (no clash — safe to share the bus).

> Tip: If you have no external I2C pull-ups, keep wires short. The test
> sketches set `Wire.setClock(100000)` (100 kHz) for extra reliability.

---

## 3. Bring-Up Order (flash one folder at a time)

Open the `.ino` in each folder, flash it, open Serial Monitor at **115200 baud**.

| Step | Folder | What it verifies |
|---|---|---|
| 1 | `01_mpu6050/` | MPU6050 alone on I2C |
| 2 | `02_pm25/` | PM2.5 alone on I2C |
| 3 | `03_mpu_pm25/` | Both I2C devices together (+ I2C bus scan) |
| 4 | `04_add_dht22/` | Adds DHT22 climate |
| 5 | `05_add_vibration/` | Adds SW-420 vibration (full stack minus LiDAR) |
| 6 | `06_lidar_only/` | LiDAR alone with hardened parser + wake burst |
| 7 | `final/` | Everything combined (see variants below) |

Only move to the next step once the current one prints valid data.

### `final/` variants — pick based on how debugging goes

Each `.ino` in `final/` is a standalone sketch. Flash the one you need.
(In Arduino IDE, keep only one `.ino` open per sketch folder, or copy the
chosen file into its own folder before compiling — the IDE compiles all
`.ino` files in a folder together, which would collide. See note below.)

| File | Contents | Use when |
|---|---|---|
| `final01_TEST.ino` | ALL sensors + full debug instrumentation | Default. Runtime toggles, health counters, I2C rescan, loop-time watchdog, LiDAR frame stats, free-heap. |
| `final02_LIDAR_plus_I2C.ino` | LiDAR + MPU + PM2.5 (no DHT/vib) | Bisect: is the blocking **I2C** the thing hurting LiDAR? |
| `final03_LIDAR_plus_DHT.ino` | LiDAR + DHT22 | Bisect: is the blocking **DHT read (~25ms)** hurting LiDAR? |
| `final04_DUALCORE.ino` | LiDAR on Core 1, all others on Core 0 | The bulletproof fix — parallel tasks so blocking reads can never starve the LiDAR FIFO. Use as the production build if single-loop still glitches. |

> **IMPORTANT — Arduino sketch folder rule:** the Arduino IDE compiles *every*
> `.ino` in a folder into one program. Having multiple `final*.ino` files in
> the same folder will cause "redefinition" errors. Before compiling a variant,
> either move it into its own folder (e.g. `final/final04_DUALCORE/final04_DUALCORE.ino`)
> or temporarily rename the others to `.txt`. PlatformIO users: put each in its
> own `src` env.

### Recommended debug path for the intermittent LiDAR issue
1. `06_lidar_only` → confirm LiDAR is fine alone.
2. `final02_LIDAR_plus_I2C` → watch `[STATS] footerErr`. If it climbs, I2C timing was the cause (now mitigated by FIFO drain).
3. `final03_LIDAR_plus_DHT` → watch footerErr vs the `readUs` print. Confirms DHT timing impact.
4. `final01_TEST` → run the whole stack with counters. Watch `[WARN] slow loop` and `loopMax`. If loops stay under ~8ms and footerErr stays ~0, you're good.
5. If single-core still glitches under load, switch to `final04_DUALCORE` as the production build.

---

## 4. Why LiDAR / MPU Died When Merged (and how it's fixed)

Root cause: in the original merged code, the LiDAR parser `break`s out
after reading **one** frame per loop. Meanwhile the **blocking** I2C reads
(MPU6050 `getMotion6`, PM2.5 `gainParticleConcentration_ugm3`) and the
**blocking** DHT22 read hold the CPU long enough that the small UART FIFO
overflows. The next LiDAR frame arrives corrupted → "Frame Error" or no
output at all. It looked random because timing lined up differently each boot.

Fixes applied in `06_lidar_only` and `final`:
1. **Self-syncing, non-blocking parser** — a byte-by-byte state machine that
   automatically resyncs on the `0x55 0xAA` header and never blocks.
2. **Drain the whole FIFO every loop** (`while (available())`), so blocking
   I2C/DHT calls can't cause overflow.
3. **`Wire.setClock(100000)`** for reliable shared-bus I2C.
4. **Bounded PM2.5 init retries** so a missing sensor can't hang boot forever.
5. **LiDAR wake/kick burst** at startup (flush + send the command a few times).

---

## 5. Sensor Wake / Sleep Notes

- **MPU6050**: powers up in sleep mode by default; `mpu.initialize()` clears
  the sleep bit and wakes it. No extra step needed. If you ever see frozen
  values, re-run `initialize()`.
- **PM2.5 (DFRobot)**: needs a warm-up window; sketches wait 3s before `begin()`.
- **TF-LC02 LiDAR**: no true sleep on this unit — sending the measurement
  command "kicks" it. The wake burst in setup covers boards that come up idle.
- **SW-420 / DHT22**: no sleep state; always active.

---

## 6. Debug Mechanisms in `final01_TEST.ino`

These give you evidence instead of guessing:

| Mechanism | What it tells you |
|---|---|
| Reset reason on boot | Distinguishes brown-out / watchdog reboots from clean starts. |
| I2C scan (boot + every 10s) | Shows if MPU (0x68/0x69) or PM2.5 (0x19) drops off the bus mid-run. |
| Health counters (ok/fail per sensor, printed every 5s) | Quantifies how often each sensor returns garbage. |
| Loop-time watchdog (`[WARN] slow loop`) | Flags iterations >8ms — the exact condition that starves the LiDAR FIFO. |
| LiDAR frame stats (good / footerErr / stale) | Pinpoints LiDAR corruption vs total silence. |
| Free-heap print | Detects memory leaks/fragmentation over long runs. |
| Runtime toggles (`v/m/a/d/l` in Serial) | Turn any sensor on/off live to bisect interactions without reflashing. |

Serial commands: `h` help, `v/m/a/d/l` toggle Vib/Mpu/Air/Dht/Lidar, `s` scan now, `r` reset counters.

## 7. Troubleshooting Quick Reference

- **No I2C devices in scan (step 3/final):** check SDA/SCL swap, power rails
  (MPU 3.3V, PM2.5 5V), and grounds are common.
- **MPU values all 0 or -1:** wiring/pull-up issue, or wrong address (should be 0x68).
- **PM2.5 "NOT FOUND":** almost always 5V power, not 3.3V.
- **LiDAR TIMEOUT / Frame Error:** confirm TX↔RX are crossed
  (LiDAR TX→GPIO7, LiDAR RX→GPIO6), 5V power, and use the `06_lidar_only` sketch.
- **DHT22 "read failed":** add/verify the 10k pull-up on the DATA line.
