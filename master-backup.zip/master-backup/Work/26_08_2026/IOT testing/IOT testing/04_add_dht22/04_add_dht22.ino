/*
 * =================================================================
 * STEP 4: MPU6050 + PM2.5 + DHT22
 * =================================================================
 * Adds the DHT22 climate sensor. DHT22 uses a bit-banged single-wire
 * protocol and dht.read* calls can block ~25ms. That is fine here but
 * matters once LiDAR is added (see step 6 notes).
 *
 * WIRING (same as master):
 *   DHT22 DATA -> GPIO 5 (VCC 3.3V/5V, GND, 10k pull-up on DATA)
 *   I2C SDA -> GPIO 19 | SCL -> GPIO 18
 * =================================================================
 */
#include <Wire.h>
#include <MPU6050.h>
#include <DFRobot_AirQualitySensor.h>
#include "DHT.h"

#define I2C_SDA 19
#define I2C_SCL 18
#define PM25_I2C_ADDRESS 0x19
#define DHTPIN 5
#define DHTTYPE DHT22

MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);
DHT dht(DHTPIN, DHTTYPE);

unsigned long lastMPUReadTime = 0;
const unsigned long mpuInterval = 500;
unsigned long lastAirReadTime = 0;
const unsigned long airInterval = 2000;
unsigned long lastDHTReadTime = 0;
const unsigned long dhtInterval = 2000;

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }

  Serial.println(F("STEP 4: MPU + PM2.5 + DHT22"));

  if (!Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(F("I2C FAILED! Halted."));
    while (1) { delay(100); }
  }
  Wire.setClock(100000);

  mpu.initialize();
  Serial.print(F("MPU6050: "));
  Serial.println(mpu.testConnection() ? F("FOUND") : F("FAILED"));

  Serial.println(F("Warming up PM2.5 (3s)..."));
  delay(3000);
  uint8_t retries = 0;
  Serial.print(F("PM2.5: "));
  while (!particle.begin()) {
    delay(1000);
    if (++retries >= 10) { Serial.print(F("FAILED ")); break; }
  }
  if (retries < 10) Serial.println(F("FOUND"));
  else Serial.println();

  dht.begin();
  Serial.println(F("System Online!"));
}

void loop() {
  if (millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();
    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
    Serial.print(F("[IMU] AX:")); Serial.print(ax);
    Serial.print(F(" AY:")); Serial.print(ay);
    Serial.print(F(" AZ:")); Serial.print(az);
    Serial.print(F(" | GX:")); Serial.print(gx);
    Serial.print(F(" GY:")); Serial.print(gy);
    Serial.print(F(" GZ:")); Serial.println(gz);
  }

  if (millis() - lastAirReadTime >= airInterval) {
    lastAirReadTime = millis();
    uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
    Serial.print(F("[AIR] PM1.0:")); Serial.print(pm1_0);
    Serial.print(F(" PM2.5:")); Serial.print(pm2_5);
    Serial.print(F(" PM10:")); Serial.print(pm10);
    Serial.println(F(" ug/m3"));
  }

  if (millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis();
    float h = dht.readHumidity();
    float t = dht.readTemperature();
    if (isnan(h) || isnan(t)) {
      Serial.println(F("[CLIMATE ERROR] DHT22 read failed."));
    } else {
      Serial.print(F("[CLIMATE] Hum:")); Serial.print(h, 1);
      Serial.print(F("% Temp:")); Serial.print(t, 1);
      Serial.println(F("C"));
    }
  }

  delay(1);
}
