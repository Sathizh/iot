/*
 * =================================================================
 * final03_LIDAR_plus_DHT — LiDAR + DHT22 only
 * =================================================================
 * PURPOSE: The DHT22 read is BLOCKING (~25ms). That single call can
 * stall the loop long enough to overflow the LiDAR FIFO on a naive
 * parser. This test proves whether DHT timing hurts LiDAR.
 *
 * If footerErr climbs only right after each [CLIMATE] line, the DHT
 * read timing is the culprit -> the FIFO-drain parser handles it, but
 * you can also move DHT to its own core/task if needed.
 * =================================================================
 */
#include <HardwareSerial.h>
#include <DHT.h>

#define RX_PIN 7
#define TX_PIN 6
#define DHTPIN 5
#define DHTTYPE DHT22

HardwareSerial LidarSerial(1);
DHT dht(DHTPIN, DHTTYPE);
const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

unsigned long lastLidarPollTime = 0; const unsigned long lidarInterval = 50;
unsigned long lastDHTReadTime = 0;   const unsigned long dhtInterval = 2000;
unsigned long lastStatsTime = 0;     const unsigned long statsInterval = 5000;

uint8_t lidarBuf[8]; int lidarIdx = 0;
uint32_t lidarGood = 0, lidarFooterErr = 0;

void feedLidarByte(uint8_t b) {
  if (lidarIdx == 0) { if (b == 0x55) lidarBuf[lidarIdx++] = b; }
  else if (lidarIdx == 1) { if (b == 0xAA) lidarBuf[lidarIdx++] = b; else lidarIdx = (b==0x55)?1:0; }
  else {
    lidarBuf[lidarIdx++] = b;
    if (lidarIdx == 8) {
      if (lidarBuf[7] == 0xFA) { uint16_t d=(lidarBuf[4]<<8)|lidarBuf[5]; lidarGood++;
        Serial.print(F("[LIDAR] Dist:")); Serial.print(d); Serial.println(F("mm")); }
      else lidarFooterErr++;
      lidarIdx = 0;
    }
  }
}

void setup() {
  Serial.begin(115200); while (!Serial) { delay(10); }
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);
  dht.begin();
  Serial.println(F("final03: LiDAR + DHT22"));
  while (LidarSerial.available()) LidarSerial.read();
  for (int i=0;i<3;i++){ LidarSerial.write(GET_DIST,sizeof(GET_DIST)); delay(60); }
}

void loop() {
  if (millis() - lastLidarPollTime >= lidarInterval) { lastLidarPollTime = millis(); LidarSerial.write(GET_DIST,sizeof(GET_DIST)); }
  while (LidarSerial.available() > 0) feedLidarByte((uint8_t)LidarSerial.read());

  if (millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis();
    unsigned long t0 = micros();
    float h = dht.readHumidity(), t = dht.readTemperature();
    unsigned long dur = micros() - t0;
    if (isnan(h) || isnan(t)) Serial.println(F("[CLIMATE ERROR]"));
    else { Serial.print(F("[CLIMATE] T:")); Serial.print(t,1); Serial.print(F(" (readUs=")); Serial.print(dur); Serial.println(F(")")); }
  }
  if (millis() - lastStatsTime >= statsInterval) {
    lastStatsTime = millis();
    Serial.print(F("[STATS] good=")); Serial.print(lidarGood);
    Serial.print(F(" footerErr=")); Serial.println(lidarFooterErr);
  }
  delay(1);
}
