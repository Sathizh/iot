/*
 * =================================================================
 * final02_LIDAR_plus_I2C — LiDAR + MPU6050 + PM2.5 (NO DHT/VIB)
 * =================================================================
 * PURPOSE: Isolate the most suspicious interaction — the blocking I2C
 * reads vs the LiDAR UART FIFO. If LiDAR works alone (06_lidar_only)
 * but fails here, the blocking I2C calls are the cause and the FIFO
 * drain + non-blocking parser is the fix (already applied below).
 *
 * Watch [STATS] footerErr / stale. They should stay ~0.
 * =================================================================
 */
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DFRobot_AirQualitySensor.h>

#define RX_PIN 7
#define TX_PIN 6
#define I2C_SDA 19
#define I2C_SCL 18
#define PM25_I2C_ADDRESS 0x19

HardwareSerial LidarSerial(1);
MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);
const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

unsigned long lastLidarPollTime = 0; const unsigned long lidarInterval = 50;
unsigned long lastMPUReadTime = 0;   const unsigned long mpuInterval = 500;
unsigned long lastAirReadTime = 0;   const unsigned long airInterval = 2000;
unsigned long lastStatsTime = 0;     const unsigned long statsInterval = 5000;

uint8_t lidarBuf[8]; int lidarIdx = 0;
uint32_t lidarGood = 0, lidarFooterErr = 0;

void feedLidarByte(uint8_t b) {
  if (lidarIdx == 0) { if (b == 0x55) lidarBuf[lidarIdx++] = b; }
  else if (lidarIdx == 1) { if (b == 0xAA) lidarBuf[lidarIdx++] = b; else lidarIdx = (b==0x55)?1:0; }
  else {
    lidarBuf[lidarIdx++] = b;
    if (lidarIdx == 8) {
      if (lidarBuf[7] == 0xFA) {
        uint16_t dist = (lidarBuf[4] << 8) | lidarBuf[5];
        lidarGood++;
        Serial.print(F("[LIDAR] Dist:")); Serial.print(dist); Serial.println(F("mm"));
      } else { lidarFooterErr++; }
      lidarIdx = 0;
    }
  }
}

void setup() {
  Serial.begin(115200); while (!Serial) { delay(10); }
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);
  Serial.println(F("final02: LiDAR + MPU + PM2.5"));

  if (!Wire.begin(I2C_SDA, I2C_SCL)) { Serial.println(F("I2C FAIL")); while(1){delay(100);} }
  Wire.setClock(100000);
  mpu.initialize();
  Serial.println(mpu.testConnection() ? F("MPU FOUND") : F("MPU FAILED"));
  delay(3000);
  uint8_t r=0; while (!particle.begin()) { delay(1000); if(++r>=10) break; }
  Serial.println(r<10 ? F("PM2.5 FOUND") : F("PM2.5 FAILED"));

  while (LidarSerial.available()) LidarSerial.read();
  for (int i=0;i<3;i++){ LidarSerial.write(GET_DIST,sizeof(GET_DIST)); delay(60); }
  Serial.println(F("Online"));
}

void loop() {
  if (millis() - lastLidarPollTime >= lidarInterval) { lastLidarPollTime = millis(); LidarSerial.write(GET_DIST,sizeof(GET_DIST)); }
  while (LidarSerial.available() > 0) feedLidarByte((uint8_t)LidarSerial.read());

  if (millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();
    int16_t ax,ay,az,gx,gy,gz; mpu.getMotion6(&ax,&ay,&az,&gx,&gy,&gz);
    Serial.print(F("[IMU] AX:")); Serial.print(ax); Serial.print(F(" AZ:")); Serial.println(az);
  }
  if (millis() - lastAirReadTime >= airInterval) {
    lastAirReadTime = millis();
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    Serial.print(F("[AIR] PM2.5:")); Serial.println(pm2_5);
  }
  if (millis() - lastStatsTime >= statsInterval) {
    lastStatsTime = millis();
    Serial.print(F("[STATS] good=")); Serial.print(lidarGood);
    Serial.print(F(" footerErr=")); Serial.println(lidarFooterErr);
  }
  delay(1);
}
