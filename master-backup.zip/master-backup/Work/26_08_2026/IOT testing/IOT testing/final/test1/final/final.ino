// /*
//  * =================================================================
//  * FINAL: ALL SENSORS IN ONE SKETCH
//  *   SW-420 Vibration + TF-LC02 LiDAR + DHT22 + MPU6050 + PM2.5
//  * =================================================================
//  * This is the combined build. It keeps the SAME wiring as your master
//  * code and fixes the reasons LiDAR/MPU intermittently died when merged.
//  *
//  * WIRING:
//  *   SW-420 DOUT -> GPIO 15
//  *   DHT22 DATA  -> GPIO 5   (10k pull-up on DATA line)
//  *   LiDAR TX(Green) -> GPIO 7  |  LiDAR RX(White) -> GPIO 6
//  *   I2C SDA -> GPIO 20 | I2C SCL -> GPIO 21
//  *   MPU6050 @ 0x68 (3.3V) | PM2.5 @ 0x19 (5V)
//  *
//  * KEY FIXES vs the original merged code:
//  *   1. LiDAR parser is a self-syncing, NON-BLOCKING state machine that
//  *      drains the whole UART FIFO every loop. It never "break"s after one
//  *      frame, so blocking I2C/DHT reads can't cause FIFO overflow/corruption.
//  *   2. Wire.setClock(100000) for reliable shared-bus I2C.
//  *   3. I2C scan on boot so you can confirm both 0x68 and 0x19 respond.
//  *   4. PM2.5 init retries are bounded so a missing sensor can't hang boot.
//  *   5. LiDAR "wake/kick" burst at startup.
//  * =================================================================
//  */
// #include <HardwareSerial.h>
// #include <Wire.h>
// #include <MPU6050.h>
// #include <DHT.h>
// #include <DFRobot_AirQualitySensor.h>

// // ---------------- PIN DEFINITIONS ----------------
// const int VIBRATION_PIN = 15;
// #define DHTPIN 5
// #define RX_PIN 7   // LiDAR TX -> here
// #define TX_PIN 6   // LiDAR RX -> here
// #define I2C_SDA 20 // Updated SDA pin
// #define I2C_SCL 21 // Updated SCL pin
// #define PM25_I2C_ADDRESS 0x19
// #define DHTTYPE DHT22

// // ---------------- INSTANCES ----------------
// DHT dht(DHTPIN, DHTTYPE);
// HardwareSerial LidarSerial(1);
// MPU6050 mpu;
// DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

// const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// // ---------------- TIMERS ----------------
// unsigned long lastDHTReadTime = 0;
// const unsigned long dhtInterval = 2000;
// unsigned long lastLidarPollTime = 0;
// const unsigned long lidarInterval = 50;
// unsigned long lastMPUReadTime = 0;
// const unsigned long mpuInterval = 500;
// unsigned long lastAirReadTime = 0;
// const unsigned long airInterval = 2000;
// unsigned long lastDebounceTime = 0;
// const unsigned long debounceDelay = 50;

// // ---------------- STATE ----------------
// int lastSensorState = LOW;
// uint8_t lidarBuf[8];
// int lidarIdx = 0;

// // ---------------- LIDAR PARSER (self-syncing, non-blocking) --------
// void feedLidarByte(uint8_t b) {
//   if (lidarIdx == 0) {
//     if (b == 0x55) lidarBuf[lidarIdx++] = b;
//   } else if (lidarIdx == 1) {
//     if (b == 0xAA) lidarBuf[lidarIdx++] = b;
//     else lidarIdx = (b == 0x55) ? 1 : 0;
//   } else {
//     lidarBuf[lidarIdx++] = b;
//     if (lidarIdx == 8) {
//       if (lidarBuf[7] == 0xFA) {
//         uint16_t dist = (lidarBuf[4] << 8) | lidarBuf[5];
//         uint8_t status = lidarBuf[6];
//         Serial.print(F("[LIDAR] Dist: ")); Serial.print(dist);
//         Serial.print(F("mm | Status: "));
//         if (status == 0x00) Serial.println(F("OK (Strong Signal)"));
//         else if (status == 0x01) Serial.println(F("WEAK (Low Reflectivity)"));
//         else if (status == 0x07) Serial.println(F("AMB (Too much Sunlight)"));
//         else Serial.println(F("ERROR"));
//       } else {
//         Serial.println(F("[LIDAR] Frame footer mismatch, resyncing."));
//       }
//       lidarIdx = 0;
//     }
//   }
// }

// void i2cScan() {
//   Serial.println(F("[I2C SCAN] Scanning..."));
//   byte count = 0;
//   for (byte addr = 1; addr < 127; addr++) {
//     Wire.beginTransmission(addr);
//     if (Wire.endTransmission() == 0) {
//       Serial.print(F("  Found 0x"));
//       if (addr < 16) Serial.print('0');
//       Serial.println(addr, HEX);
//       count++;
//     }
//   }
//   Serial.print(F("[I2C SCAN] Devices: ")); Serial.println(count);
// }

// void setup() {
//   Serial.begin(115200);
//   while (!Serial) { delay(10); }

//   LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

//   Serial.println(F("============================================="));
//   Serial.println(F("FINAL: ALL SENSORS MERGED"));
//   Serial.println(F("Vibration:15 | DHT22:5 | LiDAR RX:7 TX:6"));
//   Serial.println(F("I2C SDA:20 SCL:21 (MPU 0x68, PM2.5 0x19)"));
//   Serial.println(F("============================================="));

//   Serial.print(F("Initializing shared I2C bus..."));
//   if (Wire.begin(I2C_SDA, I2C_SCL)) Serial.println(F(" SUCCESS."));
//   else { Serial.println(F(" FAILED! Halted.")); while (1) { delay(100); } }
//   Wire.setClock(100000);

//   i2cScan();

//   // MPU6050 Initialization
//   Serial.print(F("Connecting to MPU6050..."));
//   mpu.initialize();
//   if (mpu.testConnection()) {
//     Serial.println(F(" FOUND."));
//     // Wake up MPU6050 (clear sleep mode bit)
//     mpu.setSleepEnabled(false);
//     Serial.println(F("MPU6050 is now awake."));
//   } else {
//     Serial.println(F(" FAILED! Check wiring."));
//   }

//   Serial.println(F("Warming up PM2.5 (3s)..."));
//   delay(3000);
//   Serial.print(F("Connecting to PM2.5..."));
//   uint8_t retries = 0;
//   while (!particle.begin()) {
//     Serial.println(F(" NOT FOUND! Retry 1s..."));
//     delay(1000);
//     if (++retries >= 10) { Serial.println(F("Giving up (check 5V).")); break; }
//   }
//   if (retries < 10) Serial.println(F(" FOUND."));

//   pinMode(VIBRATION_PIN, INPUT);
//   dht.begin();

//   // LiDAR wake/kick
//   while (LidarSerial.available()) LidarSerial.read();
//   for (int i = 0; i < 3; i++) { LidarSerial.write(GET_DIST, sizeof(GET_DIST)); delay(60); }

//   Serial.println(F("System Online! Monitoring active..."));
// }

// void loop() {
//   // LOOP 1: Vibration (non-blocking)
//   int currentRead = digitalRead(VIBRATION_PIN);
//   if (currentRead == HIGH && lastSensorState == LOW) {
//     if ((millis() - lastDebounceTime) > debounceDelay) {
//       Serial.println(F("[ALERT] Motion / Vibration Detected!"));
//       lastDebounceTime = millis();
//     }
//   } else if (currentRead == LOW && lastSensorState == HIGH) {
//     if ((millis() - lastDebounceTime) > debounceDelay) {
//       Serial.println(F("[INFO] Vibration stabilized."));
//       lastDebounceTime = millis();
//     }
//   }
//   lastSensorState = currentRead;

//   // LOOP 2: LiDAR poll + drain FIFO fully (fixes intermittent failure)
//   if (millis() - lastLidarPollTime >= lidarInterval) {
//     lastLidarPollTime = millis();
//     LidarSerial.write(GET_DIST, sizeof(GET_DIST));
//   }
//   while (LidarSerial.available() > 0) {
//     feedLidarByte((uint8_t)LidarSerial.read());
//   }

//   // LOOP 3: DHT22
//   if (millis() - lastDHTReadTime >= dhtInterval) {
//     lastDHTReadTime = millis();
//     float humidity = dht.readHumidity();
//     float temperature_C = dht.readTemperature();
//     if (isnan(humidity) || isnan(temperature_C)) {
//       Serial.println(F("[CLIMATE ERROR] Failed to parse DHT22 frame data."));
//     } else {
//       Serial.print(F("[CLIMATE] Humidity: ")); Serial.print(humidity, 1);
//       Serial.print(F("%  |  Temperature: ")); Serial.print(temperature_C, 1);
//       Serial.println(F("C"));
//     }
//   }

//   // LOOP 4: MPU6050
//   if (millis() - lastMPUReadTime >= mpuInterval) {
//     lastMPUReadTime = millis();
//     int16_t ax, ay, az, gx, gy, gz;
//     mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
//     Serial.print(F("[IMU] Accel -> X:")); Serial.print(ax);
//     Serial.print(F(" | Y: ")); Serial.print(ay);
//     Serial.print(F(" | Z: ")); Serial.print(az);
//     Serial.print(F("\t || Gyro -> X:")); Serial.print(gx);
//     Serial.print(F(" | Y:")); Serial.print(gy);
//     Serial.print(F(" | Z: ")); Serial.println(gz);
//   }

//   // LOOP 5: PM2.5
//   if (millis() - lastAirReadTime >= airInterval) {
//     lastAirReadTime = millis();
//     uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
//     uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
//     uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
//     Serial.print(F("[AIR QUALITY] PM1.0: ")); Serial.print(pm1_0);
//     Serial.print(F(" ug/m3 | PM2.5: ")); Serial.print(pm2_5);
//     Serial.print(F(" ug/m3 | PM10: ")); Serial.print(pm10);
//     Serial.println(F(" ug/m3"));
//   }

//   delay(1);
// }



/*
 * =================================================================
 * FINAL: ALL SENSORS IN ONE SKETCH
 *   SW-420 Vibration + TF-LC02 LiDAR + DHT22 + MPU6050 + PM2.5
 * =================================================================
 * This is the combined build. It keeps the SAME wiring as your master
 * code and fixes the reasons LiDAR/MPU intermittently died when merged.
 *
 * WIRING:
 *   SW-420 DOUT -> GPIO 15
 *   DHT22 DATA  -> GPIO 5   (10k pull-up on DATA line)
 *   LiDAR TX(Green) -> GPIO 7  |  LiDAR RX(White) -> GPIO 6
 *   I2C SDA -> GPIO 20 | I2C SCL -> GPIO 21
 *   MPU6050 @ 0x68 (3.3V) | PM2.5 @ 0x19 (5V)
 *
 * KEY FIXES vs the original merged code:
 *   1. LiDAR parser is a self-syncing, NON-BLOCKING state machine that
 *      drains the whole UART FIFO every loop. It never "break"s after one
 *      frame, so blocking I2C/DHT reads can't cause FIFO overflow/corruption.
 *   2. Wire.setClock(100000) for reliable shared-bus I2C.
 *   3. I2C scan on boot so you can confirm both 0x68 and 0x19 respond.
 *   4. PM2.5 init retries are bounded so a missing sensor can't hang boot.
 *   5. LiDAR "wake/kick" burst at startup.
 * =================================================================
 */
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DHT.h>
#include <DFRobot_AirQualitySensor.h>

// ---------------- PIN DEFINITIONS ----------------
const int VIBRATION_PIN = 15;
#define DHTPIN 5
#define RX_PIN 7   // LiDAR TX -> here
#define TX_PIN 6   // LiDAR RX -> here
#define I2C_SDA 20 // Updated SDA pin
#define I2C_SCL 21 // Updated SCL pin
#define PM25_I2C_ADDRESS 0x19
#define DHTTYPE DHT22

// ---------------- INSTANCES ----------------
DHT dht(DHTPIN, DHTTYPE);
HardwareSerial LidarSerial(1);
MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// ---------------- TIMERS ----------------
unsigned long lastDHTReadTime = 0;
const unsigned long dhtInterval = 2000;
unsigned long lastLidarPollTime = 0;
const unsigned long lidarInterval = 50;
unsigned long lastMPUReadTime = 0;
const unsigned long mpuInterval = 500;
unsigned long lastAirReadTime = 0;
const unsigned long airInterval = 2000;
unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;

// ---------------- STATE ----------------
int lastSensorState = LOW;
uint8_t lidarBuf[8];
int lidarIdx = 0;

// ---------------- LIDAR PARSER (self-syncing, non-blocking) --------
void feedLidarByte(uint8_t b) {
  if (lidarIdx == 0) {
    if (b == 0x55) lidarBuf[lidarIdx++] = b;
  } else if (lidarIdx == 1) {
    if (b == 0xAA) lidarBuf[lidarIdx++] = b;
    else lidarIdx = (b == 0x55) ? 1 : 0;
  } else {
    lidarBuf[lidarIdx++] = b;
    if (lidarIdx == 8) {
      if (lidarBuf[7] == 0xFA) {
        uint16_t dist = (lidarBuf[4] << 8) | lidarBuf[5];
        uint8_t status = lidarBuf[6];
        Serial.print(F("[LIDAR] Dist: ")); Serial.print(dist);
        Serial.print(F("mm | Status: "));
        if (status == 0x00) Serial.println(F("OK (Strong Signal)"));
        else if (status == 0x01) Serial.println(F("WEAK (Low Reflectivity)"));
        else if (status == 0x07) Serial.println(F("AMB (Too much Sunlight)"));
        else Serial.println(F("ERROR"));
      } else {
        Serial.println(F("[LIDAR] Frame footer mismatch, resyncing."));
      }
      lidarIdx = 0;
    }
  }
}

void i2cScan() {
  Serial.println(F("[I2C SCAN] Scanning..."));
  byte count = 0;
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print(F("  Found 0x"));
      if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      count++;
    }
  }
  Serial.print(F("[I2C SCAN] Devices: ")); Serial.println(count);
}

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }

  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("============================================="));
  Serial.println(F("FINAL: ALL SENSORS MERGED"));
  Serial.println(F("Vibration:15 | DHT22:5 | LiDAR RX:7 TX:6"));
  Serial.println(F("I2C SDA:20 SCL:21 (MPU 0x68, PM2.5 0x19)"));
  Serial.println(F("============================================="));

  Serial.print(F("Initializing shared I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) Serial.println(F(" SUCCESS."));
  else { Serial.println(F(" FAILED! Halted.")); while (1) { delay(100); } }
  Wire.setClock(100000);

  i2cScan();

  // MPU6050 Initialization
  Serial.print(F("Connecting to MPU6050..."));
  mpu.initialize();
  if (mpu.testConnection()) {
    Serial.println(F(" FOUND."));
    // Wake up MPU6050 (clear sleep mode bit)
    mpu.setSleepEnabled(false);
    Serial.println(F("MPU6050 is now awake."));
  } else {
    Serial.println(F(" FAILED! Check wiring."));
  }

  Serial.println(F("Warming up PM2.5 (3s)..."));
  delay(3000);
  Serial.print(F("Connecting to PM2.5..."));
  uint8_t retries = 0;
  while (!particle.begin()) {
    Serial.println(F(" NOT FOUND! Retry 1s..."));
    delay(1000);
    if (++retries >= 10) { Serial.println(F("Giving up (check 5V).")); break; }
  }
  if (retries < 10) Serial.println(F(" FOUND."));

  pinMode(VIBRATION_PIN, INPUT);
  dht.begin();

  // LiDAR wake/kick
  while (LidarSerial.available()) LidarSerial.read();
  for (int i = 0; i < 3; i++) { LidarSerial.write(GET_DIST, sizeof(GET_DIST)); delay(60); }

  Serial.println(F("System Online! Monitoring active..."));
}

void loop() {
  // LOOP 1: Vibration (non-blocking)
  int currentRead = digitalRead(VIBRATION_PIN);
  if (currentRead == HIGH && lastSensorState == LOW) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[ALERT] Motion / Vibration Detected!"));
      lastDebounceTime = millis();
    }
  } else if (currentRead == LOW && lastSensorState == HIGH) {
    if ((millis() - lastDebounceTime) > debounceDelay) {
      Serial.println(F("[INFO] Vibration stabilized."));
      lastDebounceTime = millis();
    }
  }
  lastSensorState = currentRead;

  // LOOP 2: LiDAR poll + drain FIFO fully (fixes intermittent failure)
  if (millis() - lastLidarPollTime >= lidarInterval) {
    lastLidarPollTime = millis();
    LidarSerial.write(GET_DIST, sizeof(GET_DIST));
  }
  while (LidarSerial.available() > 0) {
    feedLidarByte((uint8_t)LidarSerial.read());
  }

  // LOOP 3: DHT22
  if (millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis();
    float humidity = dht.readHumidity();
    float temperature_C = dht.readTemperature();
    if (isnan(humidity) || isnan(temperature_C)) {
      Serial.println(F("[CLIMATE ERROR] Failed to parse DHT22 frame data."));
    } else {
      Serial.print(F("[CLIMATE] Humidity: ")); Serial.print(humidity, 1);
      Serial.print(F("%  |  Temperature: ")); Serial.print(temperature_C, 1);
      Serial.println(F("C"));
    }
  }

  // LOOP 4: MPU6050
  if (millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();
    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
    Serial.print(F("[IMU] Accel -> X:")); Serial.print(ax);
    Serial.print(F(" | Y: ")); Serial.print(ay);
    Serial.print(F(" | Z: ")); Serial.print(az);
    Serial.print(F("\t || Gyro -> X:")); Serial.print(gx);
    Serial.print(F(" | Y:")); Serial.print(gy);
    Serial.print(F(" | Z: ")); Serial.println(gz);
  }

  // LOOP 5: PM2.5
  if (millis() - lastAirReadTime >= airInterval) {
    lastAirReadTime = millis();
    uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
    Serial.print(F("[AIR QUALITY] PM1.0: ")); Serial.print(pm1_0);
    Serial.print(F(" ug/m3 | PM2.5: ")); Serial.print(pm2_5);
    Serial.print(F(" ug/m3 | PM10: ")); Serial.print(pm10);
    Serial.println(F(" ug/m3"));
  }

  delay(1);
}
