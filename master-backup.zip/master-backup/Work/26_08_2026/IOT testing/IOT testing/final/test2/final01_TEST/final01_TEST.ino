/*
 * =================================================================
 * final01_TEST — ALL SENSORS + FULL DEBUG INSTRUMENTATION
 * =================================================================
 * Same wiring as master. This is the "everything on, maximum
 * visibility" build. Use it to catch the intermittent LiDAR/MPU
 * problems with concrete evidence instead of guessing.
 *
 * DEBUG MECHANISMS INCLUDED:
 *   [A] Boot banner with reset reason (detect brown-out / watchdog).
 *   [B] I2C bus scan every 10s (detect a device dropping off the bus).
 *   [C] Per-sensor health counters + OK/FAIL rate printed every 5s.
 *   [D] Loop time watchdog: warns if any loop iteration exceeds a
 *       threshold (that is exactly what starves the LiDAR FIFO).
 *   [E] LiDAR frame stats: good frames, footer errors, timeouts.
 *   [F] Free-heap print (detect memory leaks / fragmentation).
 *   [G] Toggle any sensor on/off at runtime via Serial (see help).
 *
 * SERIAL COMMANDS (type in Serial Monitor, newline ending):
 *   h            -> help
 *   v / m / a / d / l  -> toggle Vibration / Mpu / Air / Dht / Lidar
 *   s            -> force an I2C scan now
 *   r            -> reset all health counters
 * =================================================================
 */
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include <DHT.h>
#include <DFRobot_AirQualitySensor.h>

const int VIBRATION_PIN = 15;
#define DHTPIN 5
#define RX_PIN 7
#define TX_PIN 6
#define I2C_SDA 19
#define I2C_SCL 18
#define PM25_I2C_ADDRESS 0x19
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
HardwareSerial LidarSerial(1);
MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

// ---- enable flags (runtime-toggleable) ----
bool enVib = true, enMpu = true, enAir = true, enDht = true, enLidar = true;

// ---- timers ----
unsigned long lastDHTReadTime = 0;   const unsigned long dhtInterval = 2000;
unsigned long lastLidarPollTime = 0; const unsigned long lidarInterval = 50;
unsigned long lastMPUReadTime = 0;   const unsigned long mpuInterval = 500;
unsigned long lastAirReadTime = 0;   const unsigned long airInterval = 2000;
unsigned long lastDebounceTime = 0;  const unsigned long debounceDelay = 50;
unsigned long lastScanTime = 0;      const unsigned long scanInterval = 10000;
unsigned long lastStatsTime = 0;     const unsigned long statsInterval = 5000;

// ---- LiDAR parser + stats ----
int lastSensorState = LOW;
uint8_t lidarBuf[8];
int lidarIdx = 0;
unsigned long lidarLastGood = 0;
uint32_t lidarGood = 0, lidarFooterErr = 0, lidarStale = 0;

// ---- health counters ----
uint32_t mpuOK = 0, mpuFail = 0;
uint32_t airOK = 0, airFail = 0;
uint32_t dhtOK = 0, dhtFail = 0;

// ---- loop-time watchdog ----
const unsigned long LOOP_WARN_US = 8000; // 8 ms; longer risks FIFO overflow
unsigned long loopMaxUs = 0;

void printResetReason() {
  Serial.print(F("[BOOT] Reset reason code: "));
#if defined(ESP32)
  Serial.println((int)esp_reset_reason());
#else
  Serial.println(F("n/a"));
#endif
}

void i2cScan(const char* who) {
  Serial.print(F("[I2C SCAN] (")); Serial.print(who); Serial.println(F(")"));
  byte count = 0;
  bool sawMpu = false, sawAir = false;
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print(F("  0x")); if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      if (addr == 0x68 || addr == 0x69) sawMpu = true;
      if (addr == PM25_I2C_ADDRESS) sawAir = true;
      count++;
    }
  }
  Serial.print(F("  total=")); Serial.print(count);
  Serial.print(F(" MPU=")); Serial.print(sawMpu ? F("Y") : F("N"));
  Serial.print(F(" AIR=")); Serial.println(sawAir ? F("Y") : F("N"));
}

void feedLidarByte(uint8_t b) {
  if (lidarIdx == 0) {
    if (b == 0x55) lidarBuf[lidarIdx++] = b;
  } else if (lidarIdx == 1) {
    if (b == 0xAA) lidarBuf[lidarIdx++] = b;
    else lidarIdx = (b == 0x55) ? 1 : 0;
  } else {
    lidarBuf[lidarIdx++] = b;
    if (lidarIdx == 8) {
      if (lidarBuf[7] == 0xFA) {
        uint16_t dist = (lidarBuf[4] << 8) | lidarBuf[5];
        uint8_t status = lidarBuf[6];
        lidarGood++; lidarLastGood = millis();
        Serial.print(F("[LIDAR] Dist: ")); Serial.print(dist);
        Serial.print(F("mm | Status: "));
        if (status == 0x00) Serial.println(F("OK"));
        else if (status == 0x01) Serial.println(F("WEAK"));
        else if (status == 0x07) Serial.println(F("AMB"));
        else Serial.println(F("ERR"));
      } else {
        lidarFooterErr++;
        Serial.println(F("[LIDAR] footer mismatch (resync)"));
      }
      lidarIdx = 0;
    }
  }
}

void printHelp() {
  Serial.println(F("--- COMMANDS ---"));
  Serial.println(F("h help | v/m/a/d/l toggle Vib/Mpu/Air/Dht/Lidar"));
  Serial.println(F("s scan now | r reset counters"));
}

void handleSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    switch (c) {
      case 'h': printHelp(); break;
      case 'v': enVib = !enVib;   Serial.print(F("Vib=")); Serial.println(enVib); break;
      case 'm': enMpu = !enMpu;   Serial.print(F("Mpu=")); Serial.println(enMpu); break;
      case 'a': enAir = !enAir;   Serial.print(F("Air=")); Serial.println(enAir); break;
      case 'd': enDht = !enDht;   Serial.print(F("Dht=")); Serial.println(enDht); break;
      case 'l': enLidar = !enLidar; Serial.print(F("Lidar=")); Serial.println(enLidar); break;
      case 's': i2cScan("manual"); break;
      case 'r':
        mpuOK=mpuFail=airOK=airFail=dhtOK=dhtFail=0;
        lidarGood=lidarFooterErr=lidarStale=0; loopMaxUs=0;
        Serial.println(F("counters reset"));
        break;
      default: break;
    }
  }
}

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);

  Serial.println(F("============================================="));
  Serial.println(F("final01_TEST — ALL SENSORS + DEBUG"));
  Serial.println(F("============================================="));
  printResetReason();

  if (!Wire.begin(I2C_SDA, I2C_SCL)) { Serial.println(F("I2C FAIL, halt")); while(1){delay(100);} }
  Wire.setClock(100000);
  i2cScan("boot");

  mpu.initialize();
  Serial.print(F("MPU6050: ")); Serial.println(mpu.testConnection() ? F("FOUND") : F("FAILED"));

  Serial.println(F("Warming up PM2.5 (3s)..."));
  delay(3000);
  uint8_t retries = 0;
  while (!particle.begin()) { delay(1000); if (++retries >= 10) break; }
  Serial.print(F("PM2.5: ")); Serial.println(retries < 10 ? F("FOUND") : F("FAILED"));

  pinMode(VIBRATION_PIN, INPUT);
  dht.begin();

  while (LidarSerial.available()) LidarSerial.read();
  for (int i = 0; i < 3; i++) { LidarSerial.write(GET_DIST, sizeof(GET_DIST)); delay(60); }

  printHelp();
  Serial.println(F("System Online!"));
}

void loop() {
  unsigned long loopStart = micros();
  handleSerial();

  // Vibration
  if (enVib) {
    int currentRead = digitalRead(VIBRATION_PIN);
    if (currentRead == HIGH && lastSensorState == LOW) {
      if ((millis() - lastDebounceTime) > debounceDelay) {
        Serial.println(F("[ALERT] Vibration Detected!"));
        lastDebounceTime = millis();
      }
    } else if (currentRead == LOW && lastSensorState == HIGH) {
      if ((millis() - lastDebounceTime) > debounceDelay) {
        Serial.println(F("[INFO] Vibration stabilized."));
        lastDebounceTime = millis();
      }
    }
    lastSensorState = currentRead;
  }

  // LiDAR
  if (enLidar) {
    if (millis() - lastLidarPollTime >= lidarInterval) {
      lastLidarPollTime = millis();
      LidarSerial.write(GET_DIST, sizeof(GET_DIST));
    }
    while (LidarSerial.available() > 0) feedLidarByte((uint8_t)LidarSerial.read());
    if (lidarLastGood && millis() - lidarLastGood > 1000) {
      lidarStale++; lidarLastGood = millis();
      Serial.println(F("[LIDAR] STALE: no good frame >1s"));
    }
  }

  // DHT22
  if (enDht && millis() - lastDHTReadTime >= dhtInterval) {
    lastDHTReadTime = millis();
    float h = dht.readHumidity(), t = dht.readTemperature();
    if (isnan(h) || isnan(t)) { dhtFail++; Serial.println(F("[CLIMATE ERROR] DHT22 fail")); }
    else {
      dhtOK++;
      Serial.print(F("[CLIMATE] Hum:")); Serial.print(h,1);
      Serial.print(F("% Temp:")); Serial.print(t,1); Serial.println(F("C"));
    }
  }

  // MPU6050
  if (enMpu && millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();
    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
    if (ax == 0 && ay == 0 && az == 0) mpuFail++; else mpuOK++;
    Serial.print(F("[IMU] AX:")); Serial.print(ax);
    Serial.print(F(" AY:")); Serial.print(ay);
    Serial.print(F(" AZ:")); Serial.print(az);
    Serial.print(F(" | GX:")); Serial.print(gx);
    Serial.print(F(" GY:")); Serial.print(gy);
    Serial.print(F(" GZ:")); Serial.println(gz);
  }

  // PM2.5
  if (enAir && millis() - lastAirReadTime >= airInterval) {
    lastAirReadTime = millis();
    uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
    if (pm1_0 == 0 && pm2_5 == 0 && pm10 == 0) airFail++; else airOK++;
    Serial.print(F("[AIR] PM1.0:")); Serial.print(pm1_0);
    Serial.print(F(" PM2.5:")); Serial.print(pm2_5);
    Serial.print(F(" PM10:")); Serial.print(pm10); Serial.println(F(" ug/m3"));
  }

  // Periodic I2C rescan (detect a device dropping off)
  if (millis() - lastScanTime >= scanInterval) { lastScanTime = millis(); i2cScan("periodic"); }

  // Loop-time watchdog + health stats
  unsigned long loopUs = micros() - loopStart;
  if (loopUs > loopMaxUs) loopMaxUs = loopUs;
  if (loopUs > LOOP_WARN_US) {
    Serial.print(F("[WARN] slow loop ")); Serial.print(loopUs); Serial.println(F("us (FIFO risk)"));
  }
  if (millis() - lastStatsTime >= statsInterval) {
    lastStatsTime = millis();
    Serial.print(F("[STATS] LIDAR good=")); Serial.print(lidarGood);
    Serial.print(F(" footerErr=")); Serial.print(lidarFooterErr);
    Serial.print(F(" stale=")); Serial.print(lidarStale);
    Serial.print(F(" | MPU ok/fail=")); Serial.print(mpuOK); Serial.print('/'); Serial.print(mpuFail);
    Serial.print(F(" | AIR ok/fail=")); Serial.print(airOK); Serial.print('/'); Serial.print(airFail);
    Serial.print(F(" | DHT ok/fail=")); Serial.print(dhtOK); Serial.print('/'); Serial.print(dhtFail);
    Serial.print(F(" | loopMax=")); Serial.print(loopMaxUs); Serial.print(F("us"));
#if defined(ESP32)
    Serial.print(F(" | heap=")); Serial.print(ESP.getFreeHeap());
#endif
    Serial.println();
    loopMaxUs = 0;
  }

  delay(1);
}
