/*
 * =================================================================
 * final04_DUALCORE — ESP32 TWO-TASK ARCHITECTURE (MOST ROBUST FIX)
 * =================================================================
 * PURPOSE: The bulletproof solution. Run the timing-critical LiDAR on
 * its own FreeRTOS task pinned to Core 1, and all the blocking sensors
 * (MPU, PM2.5, DHT, vibration) on Core 0. That way a slow I2C/DHT read
 * can NEVER starve the LiDAR UART FIFO, because they run in parallel on
 * separate cores.
 *
 * Same wiring as master. ESP32 only (needs 2 cores + FreeRTOS).
 *
 * A mutex guards Serial so the two cores don't interleave prints.
 * =================================================================
 */
#include <HardwareSerial.h>
#include <Wire.h>
#include <MPU6050.h>
#include "DHT.h"
#include <DFRobot_AirQualitySensor.h>

const int VIBRATION_PIN = 15;
#define DHTPIN 5
#define RX_PIN 7
#define TX_PIN 6
#define I2C_SDA 19
#define I2C_SCL 18
#define PM25_I2C_ADDRESS 0x19
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
HardwareSerial LidarSerial(1);
MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);
const uint8_t GET_DIST[] = {0x55, 0xAA, 0x81, 0x00, 0xFA};

SemaphoreHandle_t serialMutex;

void logLine(const char* s) {
  if (xSemaphoreTake(serialMutex, portMAX_DELAY)) {
    Serial.println(s);
    xSemaphoreGive(serialMutex);
  }
}

// ---------------- LiDAR TASK (Core 1) ----------------
void lidarTask(void* pv) {
  uint8_t buf[8]; int idx = 0;
  unsigned long lastPoll = 0;
  for (;;) {
    if (millis() - lastPoll >= 50) { lastPoll = millis(); LidarSerial.write(GET_DIST, sizeof(GET_DIST)); }
    while (LidarSerial.available() > 0) {
      uint8_t b = LidarSerial.read();
      if (idx == 0) { if (b == 0x55) buf[idx++] = b; }
      else if (idx == 1) { if (b == 0xAA) buf[idx++] = b; else idx = (b==0x55)?1:0; }
      else {
        buf[idx++] = b;
        if (idx == 8) {
          if (buf[7] == 0xFA) {
            uint16_t dist = (buf[4] << 8) | buf[5];
            char msg[48];
            snprintf(msg, sizeof(msg), "[LIDAR] Dist: %umm | Status: 0x%02X", dist, buf[6]);
            logLine(msg);
          } else logLine("[LIDAR] footer mismatch (resync)");
          idx = 0;
        }
      }
    }
    vTaskDelay(1 / portTICK_PERIOD_MS);
  }
}

// ---------------- SENSOR TASK (Core 0) ----------------
void sensorTask(void* pv) {
  int lastSensorState = LOW; unsigned long lastDebounce = 0;
  unsigned long lastMPU = 0, lastAir = 0, lastDHT = 0;
  for (;;) {
    int cur = digitalRead(VIBRATION_PIN);
    if (cur == HIGH && lastSensorState == LOW && millis()-lastDebounce>50) { logLine("[ALERT] Vibration Detected!"); lastDebounce=millis(); }
    else if (cur == LOW && lastSensorState == HIGH && millis()-lastDebounce>50) { logLine("[INFO] Vibration stabilized."); lastDebounce=millis(); }
    lastSensorState = cur;

    if (millis() - lastMPU >= 500) {
      lastMPU = millis();
      int16_t ax,ay,az,gx,gy,gz; mpu.getMotion6(&ax,&ay,&az,&gx,&gy,&gz);
      char msg[80];
      snprintf(msg, sizeof(msg), "[IMU] AX:%d AY:%d AZ:%d | GX:%d GY:%d GZ:%d", ax,ay,az,gx,gy,gz);
      logLine(msg);
    }
    if (millis() - lastAir >= 2000) {
      lastAir = millis();
      uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
      char msg[40]; snprintf(msg, sizeof(msg), "[AIR] PM2.5: %u ug/m3", pm2_5); logLine(msg);
    }
    if (millis() - lastDHT >= 2000) {
      lastDHT = millis();
      float h = dht.readHumidity(), t = dht.readTemperature();
      char msg[48];
      if (isnan(h)||isnan(t)) logLine("[CLIMATE ERROR] DHT22 fail");
      else { snprintf(msg, sizeof(msg), "[CLIMATE] Hum:%.1f%% Temp:%.1fC", h, t); logLine(msg); }
    }
    vTaskDelay(1 / portTICK_PERIOD_MS);
  }
}

void setup() {
  Serial.begin(115200); while (!Serial) { delay(10); }
  LidarSerial.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);
  Serial.println(F("final04_DUALCORE: LiDAR@Core1, sensors@Core0"));

  serialMutex = xSemaphoreCreateMutex();

  if (!Wire.begin(I2C_SDA, I2C_SCL)) { Serial.println(F("I2C FAIL")); while(1){delay(100);} }
  Wire.setClock(100000);
  mpu.initialize();
  Serial.println(mpu.testConnection() ? F("MPU FOUND") : F("MPU FAILED"));
  delay(3000);
  uint8_t r=0; while (!particle.begin()) { delay(1000); if(++r>=10) break; }
  Serial.println(r<10 ? F("PM2.5 FOUND") : F("PM2.5 FAILED"));
  pinMode(VIBRATION_PIN, INPUT);
  dht.begin();

  while (LidarSerial.available()) LidarSerial.read();
  for (int i=0;i<3;i++){ LidarSerial.write(GET_DIST,sizeof(GET_DIST)); delay(60); }

  xTaskCreatePinnedToCore(lidarTask,  "lidar",  4096, NULL, 2, NULL, 1);
  xTaskCreatePinnedToCore(sensorTask, "sensor", 4096, NULL, 1, NULL, 0);
  Serial.println(F("Tasks started. Online!"));
}

void loop() {
  // Everything runs in tasks; keep loop idle.
  vTaskDelay(1000 / portTICK_PERIOD_MS);
}
