/*
 * =================================================================
 * STEP 2: DFRobot PM2.5 AIR QUALITY ONLY
 * =================================================================
 * Purpose: Verify the DFRobot PM2.5 sensor alone on the same I2C bus.
 *
 * WIRING (same as master code):
 *   I2C SDA -> GPIO 19
 *   I2C SCL -> GPIO 18
 *   PM2.5 VCC -> 5V (this sensor typically needs 5V), GND -> GND
 *   I2C address: 0x19
 *
 * WHAT TO LOOK FOR:
 *   - "PM2.5 Sensor ... FOUND." on boot.
 *   - PM values printed every 2s.
 *
 * NOTE ON I2C ADDRESS CLASH CHECK:
 *   MPU6050 default = 0x68, PM2.5 = 0x19. No clash, so both can share
 *   the bus. If either sensor was at the same address you'd get chaos.
 * =================================================================
 */
#include <Wire.h>
#include <DFRobot_AirQualitySensor.h>

#define I2C_SDA 19
#define I2C_SCL 18
#define PM25_I2C_ADDRESS 0x19

DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

unsigned long lastAirReadTime = 0;
const unsigned long airInterval = 2000;

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }

  Serial.println(F("============================================="));
  Serial.println(F("STEP 2: DFRobot PM2.5 ISOLATION TEST"));
  Serial.println(F("I2C: SDA 19 | SCL 18 | Addr 0x19"));
  Serial.println(F("============================================="));

  Serial.print(F("Initializing I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(F(" SUCCESS."));
  } else {
    Serial.println(F(" FAILED! System halted."));
    while (1) { delay(100); }
  }
  Wire.setClock(100000);

  Serial.println(F("Warming up sensor (3s)..."));
  delay(3000);

  Serial.print(F("Connecting to PM2.5 Sensor..."));
  uint8_t retries = 0;
  while (!particle.begin()) {
    Serial.println(F(" NOT FOUND! Retry in 1s..."));
    delay(1000);
    if (++retries >= 10) {
      Serial.println(F("Giving up after 10 tries. Check 5V power + wiring."));
      break;
    }
  }
  if (retries < 10) Serial.println(F(" FOUND."));

  Serial.println(F("System Online! Monitoring Air Quality..."));
}

void loop() {
  if (millis() - lastAirReadTime >= airInterval) {
    lastAirReadTime = millis();

    uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);

    Serial.print(F("[AIR QUALITY] PM1.0: ")); Serial.print(pm1_0);
    Serial.print(F(" ug/m3 | PM2.5: ")); Serial.print(pm2_5);
    Serial.print(F(" ug/m3 | PM10: ")); Serial.print(pm10);
    Serial.println(F(" ug/m3"));
  }
  delay(1);
}
