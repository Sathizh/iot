/*
 * =================================================================
 * STEP 3: MPU6050 + PM2.5 TOGETHER ON THE SHARED I2C BUS
 * =================================================================
 * Purpose: Confirm both I2C devices coexist. This is the most common
 * failure point: if begin() order or bus timing is wrong, one device
 * can hang the bus and starve the other.
 *
 * WIRING (same as master):
 *   I2C SDA -> GPIO 19 | I2C SCL -> GPIO 18
 *   MPU6050 @ 0x68 (3.3V) | PM2.5 @ 0x19 (5V)
 *
 * KEY FIXES vs the master code:
 *   - Wire.setClock(100000) for reliability on shared/long wires.
 *   - I2C bus scan on boot so you can SEE which addresses respond.
 *   - Non-blocking retry for PM2.5 that won't hang the whole sketch.
 * =================================================================
 */
#include <Wire.h>
#include <MPU6050.h>
#include <DFRobot_AirQualitySensor.h>

#define I2C_SDA 19
#define I2C_SCL 18
#define PM25_I2C_ADDRESS 0x19

MPU6050 mpu;
DFRobot_AirQualitySensor particle(&Wire, PM25_I2C_ADDRESS);

unsigned long lastMPUReadTime = 0;
const unsigned long mpuInterval = 500;
unsigned long lastAirReadTime = 0;
const unsigned long airInterval = 2000;

void i2cScan() {
  Serial.println(F("[I2C SCAN] Scanning bus..."));
  byte count = 0;
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print(F("  Found device at 0x"));
      if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      count++;
    }
  }
  if (count == 0) Serial.println(F("  No I2C devices found! Check wiring/pull-ups."));
  Serial.print(F("[I2C SCAN] Done. Devices: ")); Serial.println(count);
}

void setup() {
  Serial.begin(115200);
  while (!Serial) { delay(10); }

  Serial.println(F("============================================="));
  Serial.println(F("STEP 3: MPU6050 + PM2.5 SHARED I2C TEST"));
  Serial.println(F("I2C: SDA 19 | SCL 18"));
  Serial.println(F("============================================="));

  Serial.print(F("Initializing I2C bus..."));
  if (Wire.begin(I2C_SDA, I2C_SCL)) {
    Serial.println(F(" SUCCESS."));
  } else {
    Serial.println(F(" FAILED! System halted."));
    while (1) { delay(100); }
  }
  Wire.setClock(100000);

  i2cScan();

  Serial.print(F("Connecting to MPU6050..."));
  mpu.initialize();
  Serial.println(mpu.testConnection() ? F(" FOUND.") : F(" FAILED!"));

  Serial.println(F("Warming up PM2.5 (3s)..."));
  delay(3000);
  Serial.print(F("Connecting to PM2.5..."));
  uint8_t retries = 0;
  while (!particle.begin()) {
    Serial.println(F(" NOT FOUND! Retry in 1s..."));
    delay(1000);
    if (++retries >= 10) { Serial.println(F("Giving up. Check 5V power.")); break; }
  }
  if (retries < 10) Serial.println(F(" FOUND."));

  Serial.println(F("System Online!"));
}

void loop() {
  if (millis() - lastMPUReadTime >= mpuInterval) {
    lastMPUReadTime = millis();
    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
    Serial.print(F("[IMU] Accel X:")); Serial.print(ax);
    Serial.print(F(" Y:")); Serial.print(ay);
    Serial.print(F(" Z:")); Serial.print(az);
    Serial.print(F(" || Gyro X:")); Serial.print(gx);
    Serial.print(F(" Y:")); Serial.print(gy);
    Serial.print(F(" Z:")); Serial.println(gz);
  }

  if (millis() - lastAirReadTime >= airInterval) {
    lastAirReadTime = millis();
    uint16_t pm1_0 = particle.gainParticleConcentration_ugm3(PARTICLE_PM1_0_STANDARD);
    uint16_t pm2_5 = particle.gainParticleConcentration_ugm3(PARTICLE_PM2_5_STANDARD);
    uint16_t pm10  = particle.gainParticleConcentration_ugm3(PARTICLE_PM10_STANDARD);
    Serial.print(F("[AIR] PM1.0:")); Serial.print(pm1_0);
    Serial.print(F(" PM2.5:")); Serial.print(pm2_5);
    Serial.print(F(" PM10:")); Serial.print(pm10);
    Serial.println(F(" ug/m3"));
  }

  delay(1);
}
